/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-26
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.aggregation.constructs.expressions.Minus.java
 * Last modification: 2007-03-26
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.aggregation.constructs.expressions;

import org.sigoa.refimpl.genomes.tree.INodeFactory;
import org.sigoa.refimpl.genomes.tree.Node;

/**
 * This expression computes the opposite value of a sub-expression.
 * 
 * @author Thomas Weise
 */
public class Minus extends Expression {
  /** the serial version uid */
  private static final long serialVersionUID = 1;

  /**
   * Create a new minus with the given sub-expression
   * 
   * @param sub
   *          the sub-expressions
   */
  public Minus(final Node[] sub) {
    super(sub);
  }

  /**
   * Compute the value of this expression.
   * 
   * @param values
   *          the variables
   * @return the value of this expression
   */
  @Override
  public double compute(final double[] values) {
    if (this.size() > 0) {
      return -(((Expression) (this.get(0))).compute(values));
    }
    return 1.0d;
  }

  /**
   * Obtain the factory which deals with nodes of the same type as this
   * node.
   * 
   * @return the factory which deals with nodes of the same type as this
   *         node
   */
  @Override
  public INodeFactory getFactory() {
    return ExpressionFactory.ABS_FACTORY;
  }

  /**
   * Transform this node into its human readable representation.
   * 
   * @param sb
   *          the string builder to write to
   * @param indent
   *          the indent
   */
  @Override
  protected void toStringBuilder(final StringBuilder sb, final int indent) {
    if (this.size() > 0) {
      sb.append('(');
      sb.append('-');
      nodeToStringBuilder(this.get(0), sb, 0);
      sb.append(')');
    } else
      sb.append('1');
  }
}
