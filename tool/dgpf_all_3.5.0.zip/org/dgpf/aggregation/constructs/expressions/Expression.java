/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-26
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.aggregation.constructs.expressions.Expression.java
 * Last modification: 2007-03-26
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.aggregation.constructs.expressions;

import org.sigoa.refimpl.genomes.tree.Node;

/**
 * The basic expression class
 * 
 * @author Thomas Weise
 */
public abstract class Expression extends Node {
  /** the serial version uid */
  private static final long serialVersionUID = 1;

  /**
   * Create a new expression with the given sub-expressions
   * 
   * @param sub
   *          the sub-expressions
   */
  public Expression(final Node[] sub) {
    super(sub);
  }

  /**
   * Compute the value of this expression.
   * 
   * @param values
   *          the variables
   * @return the value of this expression
   */
  public abstract double compute(final double[] values);

}
