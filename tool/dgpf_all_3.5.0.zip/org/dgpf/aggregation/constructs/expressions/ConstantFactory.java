/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-27
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.aggregation.constructs.expressions.ConstantFactory.java
 * Last modification: 2007-03-27
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.aggregation.constructs.expressions;

import org.sigoa.refimpl.genomes.tree.INodeFactory;
import org.sigoa.refimpl.genomes.tree.Node;
import org.sigoa.spec.stoch.IRandomizer;

/**
 * The constant factory
 * 
 * @author Thomas Weise
 */
public class ConstantFactory extends ExpressionFactory {
  /** the serial version uid */
  private static final long serialVersionUID = 1;

  /**
   * The default values for constants.
   */
  private static final double[] DEFAULT_CONSTANTS = new double[] { 0.0d,
      0.5d, 1.0d, 2.0d, -1.0d, Math.PI, Math.E, -0.5d, -2.0d,
      Math.sqrt(2.0d) };

  /**
   * The minimum std deviation for mutation purposes.
   */
  private static final double MIN_DEV = ((((Double.MIN_VALUE + Double.MIN_VALUE)
      + (Double.MIN_VALUE + Double.MIN_VALUE) + (Double.MIN_VALUE + Double.MIN_VALUE)) + ((Double.MIN_VALUE + Double.MIN_VALUE)
      + (Double.MIN_VALUE + Double.MIN_VALUE) + (Double.MIN_VALUE + Double.MIN_VALUE))) + (((Double.MIN_VALUE + Double.MIN_VALUE)
      + (Double.MIN_VALUE + Double.MIN_VALUE) + (Double.MIN_VALUE + Double.MIN_VALUE)) + ((Double.MIN_VALUE + Double.MIN_VALUE)
      + (Double.MIN_VALUE + Double.MIN_VALUE) + (Double.MIN_VALUE + Double.MIN_VALUE))));

  /**
   * The globally shared default constant factory
   */
  public static final INodeFactory CONSTANT_FACTORY = new ConstantFactory(
      Constant.class);

  /**
   * Create a new node factory.
   * 
   * @param clazz
   *          the node clazz
   */
  protected ConstantFactory(final Class<? extends Constant> clazz) {
    super(clazz, 0, 0);
  }

  /**
   * Checks whether the given class of child nodes is allowed.
   * 
   * @param clazz
   *          the child node class we want to know about
   * @param pos
   *          the position where the child should be placed
   * @return <code>true</code> if and only if the node-typed managed by
   *         this factory allows children that are instances of
   *         <code>clazz</code>
   */
  @Override
  public boolean isChildAllowed(final Class<? extends Node> clazz,
      final int pos) {
    return false;
  }

  /**
   * read resolve the constant factory
   * 
   * @return the constant factory
   */
  @Override
  protected final Object readResolve() {
    return CONSTANT_FACTORY;
  }

  /**
   * This method performs one single mutation on the nodes values. It must
   * not change its children or any other the members of <code>Node</code>.
   * 
   * @param source
   *          The source node.
   * @param random
   *          The randomizer to be used.
   * @return The resulting node or the source node if no mutation was
   *         available.
   * @throws NullPointerException
   *           if <code>source==null||random==null</code>.
   */
  @Override
  public Node mutate(final Node source, final IRandomizer random) {
    return new Constant(mutateConstant(((Constant) source).m_val, random));
  }

  /**
   * Create a new node using the specified children.
   * 
   * @param children
   *          the children of the node to be, or <code>null</code> if no
   *          children are wanted
   * @param random
   *          the randomizer to be used for the node's creation
   * @return the new node
   */
  public Node create(final Node[] children, final IRandomizer random) {
    return new Constant(createConstant(random));
  }

  /**
   * Create a new constant value.
   * 
   * @param r
   *          The randomizer to be used.
   * @return The new constant value.
   */
  public static final double createConstant(final IRandomizer r) {
    double d, d2;
    int e;

    switch (r.nextInt(10)) {
    case 0: {
      d = 0.0d;
      for (e = r.nextInt(6); e >= 0; e--) {
        d = ((10.0d * d) + r.nextNormal(0.0d, 10.0d));
      }
      return d;
    }

    case 1: {
      do {
        do {
          d = createConstant(r);
        } while (d == 0.0d);
        do {
          d2 = createConstant(r);
        } while (d2 == 0.0d);

        d2 = (d * d2);
      } while (Double.isInfinite(d2) || Double.isNaN(d2));
      return d2;
    }

    case 2: {
      do {
        do {
          d = createConstant(r);
        } while (d == 0.0d);
        do {
          d2 = createConstant(r);
        } while (d2 == 0.0d);

        d2 = (d / d2);
      } while (Double.isInfinite(d2) || Double.isNaN(d2));
      return d2;
    }

    case 3: {
      do {
        do {
          d = createConstant(r);
        } while (d < 0.0d);
        do {
          d2 = createConstant(r);
        } while (d2 == 0.0d);

        d2 = Math.pow(d, d2);
      } while (Double.isInfinite(d2) || Double.isNaN(d2));
      return d2;
    }

    default: {
      d = r.nextDouble();
      return (DEFAULT_CONSTANTS[(int) (DEFAULT_CONSTANTS.length * d * d)]);
    }
    }
  }

  /**
   * Mutate a constant value.
   * 
   * @param orig
   *          The original value.
   * @param r
   *          The randomizer to be used.
   * @return The new constant value.
   */
  public static final double mutateConstant(final double orig,
      final IRandomizer r) {
    double d, e;

    do {
      switch (r.nextInt(100)) {
      case 0: {
        d = orig + createConstant(r);
        break;
      }

      case 1: {
        d = createConstant(r);
        break;
      }

      default: {
        e = Math.abs(orig);

        switch (r.nextInt(5)) {
        case 0: {
          e = Math.log(e + 1.0d);
          break;
        }
        case 1: {
          e = Math.pow(e, 0.1d);
          break;
        }
        case 2: {
          e = (0.1d * e);
          break;
        }
        case 3: {
          e = 1.0d;
          break;
        }
        default: {
          e = 1E-7;
          break;
        }
        }

        d = r.nextNormal(orig, Math.max(e, MIN_DEV));
      }
        break;
      }
    } while (d == orig);

    return d;
  }
}
