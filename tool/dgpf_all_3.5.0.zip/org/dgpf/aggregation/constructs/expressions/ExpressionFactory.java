/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-27
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.aggregation.constructs.expressions.ExpressionFactory.java
 * Last modification: 2007-03-27
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.aggregation.constructs.expressions;

import org.sigoa.refimpl.genomes.tree.INodeFactory;
import org.sigoa.refimpl.genomes.tree.Node;
import org.sigoa.refimpl.genomes.tree.NodeFactory;
import org.sigoa.spec.stoch.IRandomizer;

/**
 * The base class for expression factories
 * 
 * @author Thomas Weise
 */
public abstract class ExpressionFactory extends NodeFactory {

  /**
   * The globally shared default mul factory
   */
  public static final INodeFactory MUL_FACTORY = new ExpressionFactory(
      Mul.class, 2, 2) {
    private static final long serialVersionUID = 1;

    public Node create(final Node[] children, final IRandomizer random) {
      return new Mul(children);
    }

    @Override
    protected final Object readResolve() {
      return MUL_FACTORY;
    }
  };

  /**
   * The globally shared default add factory
   */
  public static final INodeFactory ADD_FACTORY = new ExpressionFactory(
      Add.class, 2, 2) {
    private static final long serialVersionUID = 1;

    public Node create(final Node[] children, final IRandomizer random) {
      return new Add(children);
    }

    @Override
    protected final Object readResolve() {
      return ADD_FACTORY;
    }
  };

  /**
   * The globally shared default abs factory
   */
  public static final INodeFactory ABS_FACTORY = new ExpressionFactory(
      Abs.class, 1, 1) {
    private static final long serialVersionUID = 1;

    public Node create(final Node[] children, final IRandomizer random) {
      return new Abs(children);
    }

    @Override
    protected final Object readResolve() {
      return ABS_FACTORY;
    }

    @Override
    public boolean isChildAllowed(final Class<? extends Node> clazz,
        final int pos) {
      return super.isChildAllowed(clazz, pos)
          && (Expression.class.isAssignableFrom(clazz))
          && (!(Abs.class.isAssignableFrom(clazz)));
    }
  };

  /**
   * The globally shared default minus factory
   */
  public static final INodeFactory MINUS_FACTORY = new ExpressionFactory(
      Minus.class, 1, 1) {
    private static final long serialVersionUID = 1;

    public Node create(final Node[] children, final IRandomizer random) {
      return new Minus(children);
    }

    @Override
    protected final Object readResolve() {
      return MINUS_FACTORY;
    }

    @Override
    public boolean isChildAllowed(final Class<? extends Node> clazz,
        final int pos) {
      return super.isChildAllowed(clazz, pos)
          && (Expression.class.isAssignableFrom(clazz))
          && (!(Minus.class.isAssignableFrom(clazz)));
    }
  };

  /**
   * The globally shared default mul factory
   */
  public static final INodeFactory SUB_FACTORY = new ExpressionFactory(
      Sub.class, 2, 2) {
    private static final long serialVersionUID = 1;

    public Node create(final Node[] children, final IRandomizer random) {
      return new Sub(children);
    }

    @Override
    protected final Object readResolve() {
      return SUB_FACTORY;
    }
  };

  /**
   * The globally shared default variable factory
   */
  public static final INodeFactory VARIABLE_FACTORY = new ExpressionFactory(
      Variable.class, 0, 0) {
    private static final long serialVersionUID = 1;

    public Node create(final Node[] children, final IRandomizer random) {
      return new Variable(random.nextInt());
    }

    @Override
    protected final Object readResolve() {
      return VARIABLE_FACTORY;
    }
  };

  /**
   * The globally shared default div factory
   */
  public static final INodeFactory DIV_FACTORY = new ExpressionFactory(
      Div.class, 2, 2) {
    private static final long serialVersionUID = 1;

    public Node create(final Node[] children, final IRandomizer random) {
      return new Div(children);
    }

    @Override
    protected final Object readResolve() {
      return DIV_FACTORY;
    }
  };

  /**
   * The globally shared default max factory
   */
  public static final INodeFactory MAX_FACTORY = new ExpressionFactory(
      Max.class, 2, 2) {
    private static final long serialVersionUID = 1;

    public Node create(final Node[] children, final IRandomizer random) {
      return new Max(children);
    }

    @Override
    protected final Object readResolve() {
      return MAX_FACTORY;
    }
  };

  /**
   * The globally shared default min factory
   */
  public static final INodeFactory MIN_FACTORY = new ExpressionFactory(
      Min.class, 2, 2) {
    private static final long serialVersionUID = 1;

    public Node create(final Node[] children, final IRandomizer random) {
      return new Min(children);
    }

    @Override
    protected final Object readResolve() {
      return MIN_FACTORY;
    }
  };

  /**
   * The globally shared default power factory
   */
  public static final INodeFactory POWER_FACTORY = new ExpressionFactory(
      Power.class, 2, 2) {
    private static final long serialVersionUID = 1;

    public Node create(final Node[] children, final IRandomizer random) {
      return new Power(children);
    }

    @Override
    protected final Object readResolve() {
      return POWER_FACTORY;
    }
  };

  /**
   * Create a new node factory.
   * 
   * @param clazz
   *          the node clazz
   * @param minChildren
   *          the minimum count of children
   * @param maxChildren
   *          the maximum count of children
   */
  protected ExpressionFactory(final Class<? extends Expression> clazz,
      final int minChildren, final int maxChildren) {
    super(clazz, minChildren, maxChildren);
  }

  /**
   * Checks whether the given class of child nodes is allowed.
   * 
   * @param clazz
   *          the child node class we want to know about
   * @param pos
   *          the position where the child should be placed
   * @return <code>true</code> if and only if the node-typed managed by
   *         this factory allows children that are instances of
   *         <code>clazz</code>
   */
  @Override
  public boolean isChildAllowed(final Class<? extends Node> clazz,
      final int pos) {
    return super.isChildAllowed(clazz, pos)
        && (Expression.class.isAssignableFrom(clazz));
  }
}
