/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-27
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.aggregation.constructs.ProgramFactory.java
 * Last modification: 2007-03-27
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.aggregation.constructs;

import org.sigoa.refimpl.genomes.tree.INodeFactory;
import org.sigoa.refimpl.genomes.tree.Node;
import org.sigoa.refimpl.genomes.tree.NodeFactory;
import org.sigoa.spec.stoch.IRandomizer;

/**
 * The program factory
 * 
 * @author Thomas Weise
 */
public class ProgramFactory extends NodeFactory {
  /** the serial version uid */
  private static final long serialVersionUID = 1;

  /**
   * The globally shared default program factory
   */
  public static final INodeFactory PROGRAM_FACTORY = new ProgramFactory(
      Program.class);

  /**
   * Create a new node factory.
   * 
   * @param clazz
   *          the node clazz
   */
  protected ProgramFactory(final Class<? extends Program> clazz) {
    super(clazz, 1, Integer.MAX_VALUE);
  }

  /**
   * Checks whether the given class of child nodes is allowed.
   * 
   * @param clazz
   *          the child node class we want to know about
   * @param pos
   *          the position where the child should be placed
   * @return <code>true</code> if and only if the node-typed managed by
   *         this factory allows children that are instances of
   *         <code>clazz</code>
   */
  @Override
  public boolean isChildAllowed(final Class<? extends Node> clazz,
      final int pos) {
    return Formula.class.isAssignableFrom(clazz);
  }

  /**
   * read resolve the constant factory
   * 
   * @return the constant factory
   */
  @Override
  protected final Object readResolve() {
    return PROGRAM_FACTORY;
  }

  /**
   * This method performs one single mutation on the nodes values. It must
   * not change its children or any other the members of <code>Node</code>.
   * 
   * @param source
   *          The source node.
   * @param random
   *          The randomizer to be used.
   * @return The resulting node or the source node if no mutation was
   *         available.
   * @throws NullPointerException
   *           if <code>source==null||random==null</code>.
   */
  @Override
  public Node mutate(final Node source, final IRandomizer random) {
    Program x;
    int[] s, r, s2, r2;
    int l, k;

    x = ((Program) copyNode(source));
    s = x.m_rec;
    r = x.m_send;
    l = s.length;

    main: for (;;) {
      switch (random.nextInt(4)) {
      case 0: {
        if (l > 1) {
          k = random.nextInt(l);
          s2 = new int[l - 1];
          r2 = new int[l - 1];
          System.arraycopy(s, 0, s2, 0, k);
          System.arraycopy(s, k + 1, s2, k, l - k - 1);
          break main;
        }
        break;
      }
      case 1: {
        s2 = new int[l + 1];
        r2 = new int[l + 1];
        k = random.nextInt(l + 1);
        System.arraycopy(s, 0, s2, 0, k);
        System.arraycopy(r, 0, r2, 0, k);
        if (l > k) {
          System.arraycopy(s, k, s2, k + 1, l - k);
          System.arraycopy(r, k, r2, k + 1, l - k);
        }
        s2[k] = random.nextInt();
        r2[k] = random.nextInt();
        break main;
      }

      case 2: {
        r2 = r;
        s2 = s.clone();
        s2[random.nextInt(l)] = random.nextInt();
        break main;
      }

      default: {
        s2 = s;
        r2 = r.clone();
        r2[random.nextInt(l)] = random.nextInt();
        break main;
      }
      }
    }

    x.m_rec = r2;
    x.m_send = s2;
    return x;
  }

  /**
   * Create a new node using the specified children.
   * 
   * @param children
   *          the children of the node to be, or <code>null</code> if no
   *          children are wanted
   * @param random
   *          the randomizer to be used for the node's creation
   * @return the new node
   */
  public Node create(final Node[] children, final IRandomizer random) {
    int l;
    int[] j, k;

    l = (1 + ((int) (random.nextExponential(1.0d))));
    j = new int[l];
    k = new int[l];
    for (--l; l >= 0; l--) {
      j[l] = random.nextInt();
      k[l] = random.nextInt();
    }

    return new Program(children, j, k);
  }

}
