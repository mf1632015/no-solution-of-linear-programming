/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-27
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.aggregation.constructs.Program.java
 * Last modification: 2007-03-27
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.aggregation.constructs;

import org.dgpf.aggregation.constructs.expressions.Variable;
import org.sfc.text.TextUtils;
import org.sigoa.refimpl.genomes.tree.INodeFactory;
import org.sigoa.refimpl.genomes.tree.Node;

/**
 * Program contain the information
 * 
 * @author Thomas Weise
 */
public class Program extends Node {
  /** the serial version uid */
  private static final long serialVersionUID = 1;

  /**
   * the variables to be sent
   */
  int[] m_send;

  /**
   * the variables to be received
   */
  int[] m_rec;

  /**
   * the valid flag
   */
  private boolean m_valid;

  /**
   * Create a new program
   * 
   * @param sub
   *          the sub-expressions
   * @param send
   *          the variables to send
   * @param rec
   *          the variables to receive
   */
  public Program(final Node[] sub, final int[] send, final int[] rec) {
    super(sub);
    this.m_send = send;
    this.m_rec = rec;
  }

  /**
   * Serializes the parameters of the constructor of this object.
   * 
   * @param sb
   *          the string builder
   * @param indent
   *          an optional parameter denoting the indentation
   */
  @Override
  protected void javaParametersToStringBuilder(final StringBuilder sb,
      final int indent) {
    super.javaParametersToStringBuilder(sb, indent);
    sb.append(',');
    sb.append(TextUtils.LINE_SEPARATOR);
    TextUtils.appendSpaces(sb, indent);
    sb.append("new "); //$NON-NLS-1$
    TextUtils.toStringBuilder(this.m_send, sb);
    sb.append(',');
    sb.append(TextUtils.LINE_SEPARATOR);
    TextUtils.appendSpaces(sb, indent);
    sb.append("new "); //$NON-NLS-1$
    TextUtils.toStringBuilder(this.m_rec, sb);
  }

  /**
   * Compute the value of this formula.
   * 
   * @param values
   *          the variables
   */
  public void compute(final double[] values) {
    int i, j;
    j = this.size();
    for (i = 0; i < j; i++) {
      ((Formula) (this.get(i))).compute(values);
    }
  }

  /**
   * exchange the data
   * 
   * @param src
   *          the source
   * @param tar
   *          the target
   */
  public void exchangeData(final double[] src, final double[] tar) {
    int[] s, r;
    int i, j, l, x, y;

    l = src.length;
    s = this.m_send;
    r = this.m_rec;
    j = s.length;
    for (i = 0; i < j; i++) {
      x = s[i];
      if (x > l)
        s[i] = (x %= l);
      else if (x < 0)
        s[i] = x = (((x % l) + l) % l);

      y = r[i];
      if (y > l)
        r[i] = (y %= l);
      else if (y < 0)
        r[i] = y = (((y % l) + l) % l);

      tar[y] = src[x];
    }
  }

  /**
   * Obtain the factory which deals with nodes of the same type as this
   * node.
   * 
   * @return the factory which deals with nodes of the same type as this
   *         node
   */
  @Override
  public INodeFactory getFactory() {
    return ProgramFactory.PROGRAM_FACTORY;
  }

  /**
   * Obtain the message size
   * 
   * @return the message size
   */
  public int getMessageSize() {
    return this.m_rec.length;
  }

  /**
   * Transform this node into its human readable representation.
   * 
   * @param sb
   *          the string builder to write to
   * @param indent
   *          the indent
   */
  @Override
  protected void toStringBuilder(final StringBuilder sb, final int indent) {
    sb.append("send   : "); //$NON-NLS-1$
    TextUtils.toStringBuilder(this.m_send, sb);
    sb.append(TextUtils.LINE_SEPARATOR);
    TextUtils.appendSpaces(sb, indent);
    sb.append("receive: "); //$NON-NLS-1$
    TextUtils.toStringBuilder(this.m_rec, sb);
    sb.append(TextUtils.LINE_SEPARATOR);
    TextUtils.appendSpaces(sb, indent + 2);
    this.childrenToStringBuilder(sb, indent);
  }

  /**
   * Check whether this node equals another object.
   * 
   * @param o
   *          the other object
   * @return <code>true</code> if the other object equals this node
   */
  @Override
  public boolean equals(final Object o) {
    Program x;
    int[] a, b;
    int i;

    if (super.equals(o)) {
      x = ((Program) o);
      a = x.m_rec;
      b = this.m_rec;
      i = a.length;
      if (i != b.length)
        return false;

      for (--i; i >= 0; i--)
        if (a[i] != b[i])
          return false;

      a = x.m_send;
      b = this.m_send;
      i = a.length;
      if (i != b.length)
        return false;

      for (--i; i >= 0; i--)
        if (a[i] != b[i])
          return false;

      return true;
    }
    return false;
  }

  /**
   * check if a node is valid
   * 
   * @param n
   *          the node
   * @return <code>true</code> if the node is valid, <code>false</code>
   *         otherwise
   */
  private static final boolean checkValid(final Node n) {
    int i;

    if (n instanceof Variable)
      return (((Variable) n).getIndex() == 0);

    for (i = (n.size() - 1); i >= 0; i--) {
      if (checkValid(n.get(i)))
        return true;
    }

    return false;
  }

  /**
   * Check whether this program is valid or not.
   * 
   * @return <code>true</code> if the program is valid,
   *         <code>false</code> otherwise
   */
  public boolean isValid() {
    if (this.m_valid)
      return true;
    return (this.m_valid = checkValid(this));
  }
}
