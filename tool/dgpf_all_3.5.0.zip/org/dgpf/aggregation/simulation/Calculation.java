/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-26
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.aggregation.simulation.Calculation.java
 * Last modification: 2007-03-26
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.aggregation.simulation;

import java.io.Serializable;
import java.util.Arrays;

import org.dgpf.aggregation.constructs.Program;
import org.sfc.math.Mathematics;
import org.sigoa.refimpl.simulation.Simulation;
import org.sigoa.refimpl.stoch.Randomizer;
import org.sigoa.refimpl.stoch.StatisticInfo;

/**
 * The calculation
 * 
 * @author Thomas Weise
 */
public class Calculation extends Simulation<Program> implements
    Serializable {
  /**
   * the serial version uid
   */
  private static final long serialVersionUID = 1;

  /**
   * the maximum of powers
   */
  private static final int POWER_CNT = 11;

  /**
   * the maximum of powers
   */
  private static final int POWER_SUB = (POWER_CNT >>> 1);

  /**
   * the minimum test count
   */
  public static final int MIN_TESTS = (POWER_CNT << 1);

  /**
   * the maximum weight
   */
  private static final int MAX_WEIGHT = 30;

  /**
   * the variables
   */
  private double[][] m_vars;

  /**
   * the variables
   */
  private double[][] m_vars2;

  /**
   * the variable count
   */
  private final int m_varCnt;

  /**
   * the virtual machine count
   */
  final int m_vmCnt;

  /**
   * the values
   */
  final double[][][] m_values;

  /**
   * the target values
   */
  private final double[][] m_targets;

  /**
   * the standard deviations
   */
  private final double[][] m_variances;

  /**
   * the index
   */
  int m_index;

  /**
   * the step index
   */
  int m_stepIdx;

  /**
   * the hits
   */
  int m_hits;

  /**
   * the hits
   */
  int m_hits2;

  /**
   * the hits
   */
  int m_hits3;

  /**
   * the sqrError
   */
  double m_sqrError;

  /**
   * the sqrError
   */
  double m_error;

  /**
   * the inter-value variance.
   */
  double m_var;

  /**
   * the step counter
   */
  private final int m_stepCnt;

  /**
   * the maximum data dissemination distance
   */
  private final int m_maxDist;

  /**
   * Create a new calculation.
   * 
   * @param params
   *          the parameters
   * @param compare
   *          the aggregation function to compare with
   */
  public Calculation(final CalculationParameters params,
      final IAggregationFunction compare) {
    super();
    int i, j;

    this.m_stepCnt = params.getStepsPerTest();
    this.m_varCnt = params.getVariableCount();
    this.m_vmCnt = params.getVMCount();
    this.m_vars = new double[this.m_vmCnt][this.m_varCnt];
    this.m_vars2 = new double[this.m_vmCnt][this.m_varCnt];

    i = params.getTestCount();
    j = this.m_stepCnt;
    this.m_values = new double[i][j][this.m_vmCnt];
    this.m_variances = new double[i][j];
    this.m_targets = new double[i][j];
    initializeValues(this.m_values, this.m_targets, this.m_variances,
        compare);

    j = 0;
    for (i = 1; i < this.m_vmCnt; i <<= 1) {
      j++;
    }

    this.m_maxDist = j;
  }

  /**
   * compute the step count
   * 
   * @param c
   *          the parameters
   * @return the step count
   */
  static final int getStepCnt(final CalculationParameters c) {
    int i;
    i = (c.getVMCount() + 2);
    return (i * i);
  }

  /**
   * Obtain the value of a variable
   * 
   * @param vm
   *          the vm
   * @param index
   *          the variable index
   * @return the variable value
   */
  public double getVariable(final int vm, final int index) {
    return this.m_vars[vm][Mathematics.modulo(index, this.m_varCnt)];
  }

  /**
   * Set the value of a variable
   * 
   * @param vm
   *          the vm
   * @param index
   *          the variable index
   * @param value
   *          the new value
   */
  public void setVariable(final int vm, final int index, final double value) {
    this.m_vars[vm][Mathematics.modulo(index, this.m_varCnt)] = value;
  }

  /**
   * Obtain the variable count.
   * 
   * @return the variable count
   */
  public int getVariableCount() {
    return this.m_varCnt;
  }

  /**
   * Obtain the virtual machine count
   * 
   * @return the virtual machine count
   */
  public int getVMCount() {
    return this.m_vmCnt;
  }

  /**
   * Perform the vm calculations
   * 
   * @param program
   *          the program
   */
  private final void step(final Program program) {
    int i, si, id, l;
    double[][] d1, d2;
    double[] z;

    d1 = this.m_vars;
    d2 = this.m_vars2;

    id = this.m_index;
    si = this.m_stepIdx;

    z = this.m_values[id][si];
    for (i = (z.length - 1); i >= 0; i--) {
      d1[i][0] = z[i];
    }

    l = d1[0].length;
    for (i = (this.m_vmCnt - 1); i >= 0; i--) {
      program.compute(d1[i]);
      System.arraycopy(d1[i], 0, d2[i], 0, l);
    }

    this
        .updateValues(d1, this.m_variances[id][si], this.m_targets[id][si]);

    this.exchangeData(program, d1, d2);
    this.m_vars2 = d1;
    this.m_vars = d2;

    this.m_stepIdx++;
  }

  /**
   * update the internal values
   * 
   * @param v
   *          the current values
   * @param t
   *          the destination
   * @param variance
   *          the inter-value variance
   */
  void updateValues(final double[][] v, final double variance,
      final double t) {
    double sum, sumSqr, sqrError, error, value, divT;
    int i, h, h2, h3;

    sum = 0;
    sumSqr = 0;
    sqrError = 0;
    h = this.m_hits;
    h2 = this.m_hits2;
    h3 = this.m_hits3;
    divT = (1.0d / variance);
    error = 0;

    for (i = (v.length - 1); i >= 0; i--) {
      value = v[i][1];
      sum += value;
      sumSqr += (value * value);
      value = (value - t);
      error += Math.abs(value);
      value *= value;
      sqrError += value;

      value /= divT;
      if (value < 0.3d) {
        h++;
        if (value < 0.2d) {
          h2++;
          if (value < 0.1d)
            h3++;
        }
      }
    }

    sumSqr -= ((sum * sum) / v.length);
    sumSqr *= divT;
    sqrError *= divT;
    error *= /* Math.sqrt( */divT/* ) */;

    this.m_sqrError += sqrError;
    this.m_error += error;
    this.m_var += sumSqr;
    this.m_hits = h;
    this.m_hits2 = h2;
    this.m_hits3 = h3;
  }

  /**
   * Exchange data between the vms
   * 
   * @param program
   *          the program
   * @param src
   *          the source data
   * @param dst
   *          the destination data
   */
  private final void exchangeData(final Program program,
      final double[][] src, final double[][] dst) {

    int i, m, e;

    m = this.m_vmCnt;

    e = (1 << (this.m_stepIdx % this.m_maxDist));

    for (i = (src.length - 1); i >= 0; i--) {
      program.exchangeData(src[i], dst[(i + e) % m]);
    }

    // int i, m, e;
    //
    // m = this.m_vmCnt;
    // e = ((this.m_stepIdx % (m - 1)) + 1);
    // for (i = (src.length - 1); i >= 0; i--) {
    // program.exchangeData(src[i], dst[(i + e) % m]);
    // }

  }

  /**
   * This method is called right before the simulation begins.
   * 
   * @param what
   *          The item to be simulated.
   * @throws NullPointerException
   *           if <code>what</code> is <code>null</code>.
   */
  @Override
  public void beginSimulation(final Program what) {
    double[][][] v;
    double[][] d1, d2;
    double[] z;
    int i;

    super.beginSimulation(what);
    d1 = this.m_vars;
    d2 = this.m_vars2;

    for (i = (d1.length - 1); i >= 0; i--) {
      Arrays.fill(d1[i], 0.0d);
      Arrays.fill(d2[i], 0.0d);
    }

    i = (this.m_index + 1);
    v = this.m_values;
    this.m_index = ((i >= v.length) ? 0 : i);

    z = this.m_values[this.m_index][0];
    for (i = (z.length - 1); i >= 0; i--) {
      Arrays.fill(d1[i], z[i]);
    }

    this.m_sqrError = 0.0d;
    this.m_error = 0.0d;
    this.m_var = 0.0d;
    this.m_stepIdx = 0;
    this.m_hits = 0;
    this.m_hits2 = 0;
    this.m_hits3 = 0;
  }

  /**
   * Obtain the test count
   * 
   * @return the test count
   */
  public int getTestCount() {
    return this.m_values.length;
  }

  /**
   * Obtain the count of changes per test
   * 
   * @return the count of changes per test
   */
  public int getChangesPerTest() {
    return this.m_values[0].length;
  }

  /**
   * initialize the given value array
   * 
   * @param values
   *          the value array
   * @param target
   *          the array to receive the target values
   * @param compare
   *          the aggregation function to compare with
   * @param variances
   *          the variances
   */
  private static final void initializeValues(final double[][][] values,
      final double[][] target, final double[][] variances,
      final IAggregationFunction compare) {

    Randomizer r;
    int i, j, k, chg;
    final int v2l;
    double avg, stddev, v, vol, ot, t, mit, mat;
    double[][] v1;
    double[] v2;
    StatisticInfo f;
    boolean sign;
    int power, z;

    r = new Randomizer();
    r.setDefaultSeed();

    v2l = (values[0][0].length - 1);
    f = new StatisticInfo();
    t = 0;
    for (i = (values.length - 1); i >= 0; i--) {
      sign = ((i & 1) != 0);
      power = ((i >>> 1) % POWER_CNT) - POWER_SUB;

      chg = (60 + r.nextInt(50));
      stddev = Math.pow(10, power);
      if (power >= 0)
        stddev = Math.rint(stddev);
      avg = ((r.nextDouble() + r.nextInt(10)) * stddev);
      stddev = (r.nextDouble() * 40 * stddev);
      vol = (Math.abs(avg) * 0.05);
      if (sign)
        avg = -avg;
      z = r.nextInt(3);

      do {
        mit = Double.POSITIVE_INFINITY;
        mat = Double.NEGATIVE_INFINITY;

        v1 = values[i];
        for (j = 0; j < v1.length; j++) {
          v2 = v1[j];
          f.clear();
          ot = t;
          if (j != 0) {
            mit = Math.min(mit, t);
            mat = Math.max(mat, t);
          }
          do {
            do {
              for (k = v2l; k >= 0; k--) {

                v = ((j > 0) ? (v1[j - 1][k]) : avg);
                if (j == 0) {
                  switch (z) {
                  case 0: {
                    v = r.nextNormal(avg, stddev);
                    break;
                  }
                  case 1: {
                    v = avg - stddev + (2 * stddev * r.nextDouble());
                    break;
                  }
                  default: {
                    v = (r.nextBoolean() ? 0 : avg);
                    break;
                  }
                  }
                } else {
                  v = (v1[j - 1][k]);
                  if (r.nextInt(chg) <= 0) {
                    if (z != 1)
                      v = r.nextNormal(v, stddev);
                    else
                      v = (v - stddev + (2 * stddev * r.nextDouble()));
                    vol++;
                  }
                }

                f.append(v2[k] = v);
              }

              t = compare.compute(values[i][j]);
            } while (Math.abs(t) <= 1e-120d);

            if (j == 0) {
              if (z == 2)
                stddev = f.getStdDev();
              v = 0;
            } else {

              if (ot == t) {
                if ((j % 7) == 0)
                  v = 1.0d;
                else
                  v = 0.0d;
              } else {
                v = Math.abs((ot - t) / ot);
                if (((j % 7) != 0) && (v > 0.01))
                  v = 1.0d;
              }
            }

          } while ((j != 0) && (v > 0.05));

          target[i][j] = t;

          variances[i][j] = f.getVariance();
        }

        if (mit == mat)
          v = 1.0d;
        else
          v = Math.abs((mat - mit) / mit);
      } while ((v > 0.5) || (v < 0.25));

    }
  }

  /**
   * Perform <code>steps</code> simulation steps. This method returns
   * <code>true</code> per default.
   * 
   * @param steps
   *          The count of simulation steps to be performed.
   * @return <code>true</code> if and only if further simulating would
   *         possible change the state of the simulation,
   *         <code>false</code> if the simulation has come to a final,
   *         terminal state which cannot change anymore.
   * @throws IllegalStateException
   *           If this simulation is not yet running.
   * @throws IllegalArgumentException
   *           if <code>steps <= 0</code>.
   */
  @Override
  public boolean simulate(final long steps) {
    Program p;
    p = this.getSimulated();
    for (int i = ((int) steps); i > 0; i--) {
      this.step(p);
    }
    return true;
  }

  /**
   * Obtain the square error
   * 
   * @return the square error
   */
  public double getSquareError() {
    return this.m_sqrError;
  }

  /**
   * Obtain the error
   * 
   * @return the error
   */
  public double getError() {
    return this.m_sqrError;
  }

  /**
   * Obtain the distortion value
   * 
   * @return the distortion value
   */
  public double getDistortion() {
    return this.m_var;
  }

  /**
   * Apply the weight to a value.
   * 
   * @param value
   *          the value
   * @param weight
   *          the weight
   * @return the value made worst according to the weight
   */
  public static final double applyWeight(final double value,
      final int weight) {
    double d;
    if (weight < MAX_WEIGHT)
      return value;
    d = Math.pow((weight - MAX_WEIGHT + 2), 0.33);
    if (value < 0)
      return (value / d);
    return (value * d);
  }

}
