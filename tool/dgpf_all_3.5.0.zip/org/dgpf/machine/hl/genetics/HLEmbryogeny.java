/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-07
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.machine.hl.genetics.HLEmbryogeny.java
 * Last modification: 2007-03-07
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.machine.hl.genetics;

import org.dgpf.machine.hl.compiler.Compiler;
import org.dgpf.machine.ll.vm.InstructionSet;
import org.dgpf.machine.ll.vm.VM;
import org.sigoa.refimpl.go.embryogeny.Embryogeny;

/**
 * The embryogeny for transforming high-level code to low-level code.
 * 
 * @param <V>
 *          the vm type
 * @author Thomas Weise
 */
public class HLEmbryogeny<V extends VM>
    extends
    Embryogeny<org.dgpf.machine.hl.Program, org.dgpf.machine.ll.vm.Program<V>> {

  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * the instruction set
   */
  private final InstructionSet<? super V> m_instr;

  /**
   * the lock
   */
  private final Object m_lock;

  /**
   * the compilers
   */
  private C m_cmp;

  /**
   * Create a new embryogeny.
   * 
   * @param instr
   *          the instruction set
   */
  public HLEmbryogeny(final InstructionSet<? super V> instr) {
    super();
    this.m_instr = instr;
    this.m_lock = new Object();
  }

  /**
   * This method is supposed to compute an instance of the phenotype from
   * an instance of the genotype. You should override it, since the default
   * method here just performs a typecast and returns the genotype.
   * 
   * @param genotype
   *          The genotype instance to breed a phenotype from.
   * @return The phenotype hatched from the genotype instance.
   * @throws NullPointerException
   *           if <code>genotype==null</code>.
   */
  @Override
  public org.dgpf.machine.ll.vm.Program<V> hatch(
      final org.dgpf.machine.hl.Program genotype) {
    C c;
    org.dgpf.machine.ll.vm.Program<V> p;

    if (genotype == null)
      throw new NullPointerException();

    synchronized (this.m_lock) {
      c = this.m_cmp;
      if (c != null)
        this.m_cmp = c.m_next;
    }
    if (c == null)
      c = new C(this.m_instr);

    genotype.compile(c);
    p = c.getProgram();

    c.clear();
    synchronized (this.m_lock) {
      c.m_next = this.m_cmp;
      this.m_cmp = c;
    }

    return p;
  }

  /**
   * /** Compute a genotype from a phenotype. This method can be used if
   * different optimizers optimize a phenotype using different genotypes
   * and want to exchange individuals. Here it is possible to return
   * <code>null</code> if regression cannot be performed.
   * 
   * @param phenotype
   *          the phenotype
   * @return the genotype regressed from the phenotype or <code>null</code>
   *         if regression was not possible
   * @throws NullPointerException
   *           if <code>phenotype==null</code>.
   */
  @Override
  public org.dgpf.machine.hl.Program regress(
      final org.dgpf.machine.ll.vm.Program<V> phenotype) {
    if (phenotype == null)
      throw new NullPointerException();
    return org.dgpf.machine.hl.Program.EMPTY_PROGRAM;
  }

  /**
   * the internal compiler class
   * 
   * @author Thomas Weise
   */
  private static final class C extends Compiler {
    /**
     * the next compiler
     */
    C m_next;

    /**
     * Create a new compiler.
     * 
     * @param is
     *          the instruction set
     */
    public C(final InstructionSet<? extends VM> is) {
      super(is);
    }
  }
}
