/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 *
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-02-27
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.machine.ll.vm.DefaultInstructionSet.java
 * Last modification: 2007-02-27
 *                by: Thomas Weise
 *
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.machine.ll.vm;

import org.dgpf.machine.ll.instructions.arith.Add;
import org.dgpf.machine.ll.instructions.arith.And;
import org.dgpf.machine.ll.instructions.arith.Compare;
import org.dgpf.machine.ll.instructions.arith.Div;
import org.dgpf.machine.ll.instructions.arith.Exchange;
import org.dgpf.machine.ll.instructions.arith.Mod;
import org.dgpf.machine.ll.instructions.arith.Move;
import org.dgpf.machine.ll.instructions.arith.Mul;
import org.dgpf.machine.ll.instructions.arith.Not;
import org.dgpf.machine.ll.instructions.arith.Or;
import org.dgpf.machine.ll.instructions.arith.Sub;
import org.dgpf.machine.ll.instructions.arith.Xor;
import org.dgpf.machine.ll.instructions.ctrl.Call;
import org.dgpf.machine.ll.instructions.ctrl.Jump;

/**
 * The default instruction set
 *
 * @author Thomas Weise
 */
public final class DefaultInstructionSet {

  /**
   * the default instruction set
   */
  public static final InstructionSet<VM> INSTRUCTION_SET;

  /**
   * The default add instruction
   */
  public static final Instruction<VM> ADD;

  /**
   * The default sub instruction
   */
  public static final Instruction<VM> SUB;

  /**
   * The default mul instruction
   */
  public static final Instruction<VM> MUL;

  /**
   * The default div instruction
   */
  public static final Instruction<VM> DIV;

  /**
   * The default mod instruction
   */
  public static final Instruction<VM> MOD;

  /**
   * The default and instruction
   */
  public static final Instruction<VM> AND;

  /**
   * The default or instruction
   */
  public static final Instruction<VM> OR;

  /**
   * The default xor instruction
   */
  public static final Instruction<VM> XOR;

  /**
   * The default not instruction
   */
  public static final Instruction<VM> NOT;

  /**
   * The default move instruction
   */
  public static final Instruction<VM> MOVE;

  /**
   * The default exchange instruction
   */
  public static final Instruction<VM> EXCHANGE;

  /**
   * The default compare instruction
   */
  public static final Instruction<VM> COMPARE;

  /**
   * The default jump instruction
   */
  public static final Instruction<VM> JUMP;

  /**
   * The default call instruction
   */
  public static final Instruction<VM> CALL;


  static {

    InstructionSetBuilder<VM> b = new InstructionSetBuilder<VM>(null) {
      @Override
      protected InstructionSet<VM> createInstructionSet(
          final Instruction<? super VM>[] instructions) {
        return new InstructionSet<VM>(instructions) {
          private static final long serialVersionUID = 1;

          private final Object readResolve() {
            return INSTRUCTION_SET;
          }

          private final Object writeReplace() {
            return INSTRUCTION_SET;
          }
        };
      }
    };

    ADD = new Add(b);
    SUB = new Sub(b);
    MUL = new Mul(b);
    DIV = new Div(b);
    MOD = new Mod(b);
    AND = new And(b);
    OR = new Or(b);
    XOR = new Xor(b);
    NOT = new Not(b);
    MOVE = new Move(b);
    EXCHANGE = new Exchange(b);
    COMPARE = new Compare(b);
    CALL = new Call(b);
    JUMP = new Jump(b);

    INSTRUCTION_SET = b.build();
  }

}
