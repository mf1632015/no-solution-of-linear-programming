/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 *
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-02-27
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.machine.ll.vm.VM.java
 * Last modification: 2007-02-27
 *                by: Thomas Weise
 *
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.machine.ll.vm;

import java.util.Arrays;

import org.sfc.math.Mathematics;
import org.sfc.text.TextUtils;

/**
 * The virtual machine.ll.
 * 
 * @author Thomas Weise
 */
public class VM extends Program<VM> implements IVMState {
  /**
   * the serial version uid
   */
  private static final long serialVersionUID = 1;

  /**
   * The globally shared vm factory.
   */
  public static final IVMFactory<VM> VM_FACTORY = new IVMFactory<VM>() {
    private static final long serialVersionUID = 0;

    public VM createVM(final VMHost h) {
      return new VM(h);
    }

    private final Object readResolve() {
      return VM_FACTORY;
    }

    private final Object writeReplace() {
      return VM_FACTORY;
    }
  };

  /**
   * the data text.
   */
  private static final char[] DATA = ("global mem  : ").toCharArray(); //$NON-NLS-1$

  /**
   * the interrupts text.
   */
  private static final char[] INTERRUPTS = (TextUtils.LINE_SEPARATOR + "# interrupts: ").toCharArray(); //$NON-NLS-1$

  /**
   * missed ints
   */
  private static final char[] MEM_ERRORS = (TextUtils.LINE_SEPARATOR + "# mem errors: ").toCharArray(); //$NON-NLS-1$

  /**
   * the missed interrupts
   */
  private static final char[] MISSED_INTS = (TextUtils.LINE_SEPARATOR + "# missed int: ").toCharArray(); //$NON-NLS-1$

  /**
   * passive steps
   */
  private static final char[] PASSIVE_STEPS = (TextUtils.LINE_SEPARATOR + "# pass. step: ").toCharArray(); //$NON-NLS-1$

  /**
   * steps
   */
  private static final char[] STEPS = (TextUtils.LINE_SEPARATOR + "# steps     : ").toCharArray(); //$NON-NLS-1$

  // /**
  // * stack pointer
  // */
  // private static final char[] STACK_PTR = (TextUtils.LINE_SEPARATOR +
  // "stack ptr : ").toCharArray(); //$NON-NLS-1$
  //
  // /**
  // * stack
  // */
  // private static final char[] STACK = (TextUtils.LINE_SEPARATOR + "stack
  // : ").toCharArray(); //$NON-NLS-1$

  /**
   * stack errors
   */
  private static final char[] STACK_ERRORS = (TextUtils.LINE_SEPARATOR + "# stack err : ").toCharArray(); //$NON-NLS-1$

  /**
   * the frame text.
   */
  private static final char[] FRAME = ("FRAME[").toCharArray(); //$NON-NLS-1$

  /**
   * the frame text.
   */
  private static final char[] FRAME2 = ("]: ").toCharArray(); //$NON-NLS-1$

  /**
   * the vm host
   */
  private final VMHost m_host;

  /**
   * the global memory of the vm
   */
  private final int[] m_global;

  /**
   * the count of memory access errors encountered during program execution
   */
  private int m_memErrors;

  //
  // /**
  // * the stack provided by the vm
  // */
  // private int[] m_stack;
  //
  // /**
  // * the stack pointer
  // */
  // private int m_sp;

  /**
   * the stack errors
   */
  private int m_stackErrors;

  /**
   * the current call depth
   */
  private int m_callDepth;

  /**
   * the count of call errors
   */
  private int m_callErrors;

  /**
   * the current frame
   */
  VMFrame m_frame;

  /**
   * the current step count.
   */
  private int m_stepCnt;

  /**
   * the count of passive steps.
   */
  private int m_passiveSteps;

  /**
   * the jump flag
   */
  private boolean m_jump;

  /**
   * if we're currently in an interrupt
   */
  private boolean m_interrupt;

  /**
   * the count of interrupts missed
   */
  private int m_missedInterrupts;

  /**
   * the count of interrupts performed
   */
  private int m_interrupts;

  /**
   * Create a new virtual machine
   * 
   * @param host
   *          the vm host
   */
  public VM(final VMHost host) {
    super();
    this.m_host = host;
    this.m_global = new int[host.m_globalSize];
    // this.m_stack = new int[host.m_localSize];
  }

  /**
   * Initialize this program by another program
   * 
   * @param program
   *          the program
   */
  @Override
  public void init(final Program<? super VM> program) {
    super.init(program);
    this.reset();
  }

  /**
   * reset the virtual machine<br/> all internal structures (except the
   * program) are cleared
   */
  public void reset() {
    VMFrame f, g;
    VMHost h;

    Arrays.fill(this.m_global, 0);
    this.m_memErrors = 0;
    // Arrays.fill(this.m_stack, 0);
    // this.m_sp = 0;
    this.m_stackErrors = 0;
    this.m_stepCnt = 0;
    this.m_callDepth = 0;
    this.m_callErrors = 0;

    h = this.m_host;
    f = this.m_frame;
    if (f != null) {
      g = f.m_next;
      while (g != null) {
        f = g;
        g = f.m_next;
        f.m_next = null;
        h.disposeFrame(f);
      }
      f = this.m_frame;
    }

    if (f == null) {
      this.m_frame = f = this.m_host.allocFrame(0);
    }
    if (this.m_code != null)
      f.m_code = this.m_code[0];
    f.m_ip = 0;
    f.m_next = null;
    this.m_stepCnt = 0;
    this.m_passiveSteps = 0;

    this.m_jump = false;
    this.m_missedInterrupts = 0;
    this.m_interrupts = 0;
    this.m_interrupt = false;
  }

  /**
   * Obtain the count of memory access errors encountered during program
   * execution.
   * 
   * @return the count of memory access errors encountered during program
   *         execution
   */
  public long getMemoryAccessErrors() {
    return this.m_memErrors;
  }

  /**
   * Read the value stored at a specified global memory address. If the
   * address is invalid (i.e. &lt; 0 or &gt;=
   * {@link #getGlobalMemorySize()}), the memory access error count will
   * be incremented and the address will be modulo divided to fit.
   * 
   * @param address
   *          the memory address to read from
   * @return the value stored at this address
   */
  public int readGlobal(final int address) {
    int a;
    int[] mem;

    mem = this.m_global;
    a = mem.length;
    if (address < 0) {
      this.m_memErrors++;
      a = ((a + (address % a)) % a);
    } else if (address >= a) {
      this.m_memErrors++;
      a = (address % a);
    } else
      a = address;

    return mem[a];
  }

  /**
   * Write a value to a specified global memory address. If the address is
   * invalid (i.e. &lt; 0 or &gt;= {@link #getGlobalMemorySize()}), the
   * memory access error count will be incremented and the address will be
   * modulo divided to fit.
   * 
   * @param address
   *          the memory address to write to
   * @param value
   *          the value to be stored at this address
   */
  public void writeGlobal(final int address, final int value) {
    int a;
    int[] mem;

    mem = this.m_global;
    a = mem.length;
    if (address < 0) {
      this.m_memErrors++;
      a = ((a + (address % a)) % a);
    } else if (address >= a) {
      this.m_memErrors++;
      a = (address % a);
    } else
      a = address;

    mem[a] = value;
  }

  /**
   * Read the value stored at a specified local memory address. If the
   * address is invalid (i.e. &lt; 0 or &gt;= {@link #getLocalMemorySize()}),
   * the memory access error count will be incremented and the address will
   * be modulo divided to fit. If no frame is currently available, the
   * memory error count is increased and 0 is returned.
   * 
   * @param address
   *          the memory address to read from
   * @return the value stored at this address
   */
  public int readLocal(final int address) {
    int a;
    int[] mem;

    if (this.m_frame == null) {
      this.m_memErrors++;
      return 0;
    }

    mem = this.m_frame.m_local;
    a = mem.length;
    if (address < 0) {
      this.m_memErrors++;
      a = ((a + (address % a)) % a);
    } else if (address >= a) {
      this.m_memErrors++;
      a = (address % a);
    } else
      a = address;

    return mem[a];
  }

  /**
   * Write a value to a specified local memory address. If the address is
   * invalid (i.e. &lt; 0 or &gt;= {@link #getLocalMemorySize()}), the
   * memory access error count will be incremented and the address will be
   * modulo divided to fit.
   * 
   * @param address
   *          the memory address to write to
   * @param value
   *          the value to be stored at this address
   */
  public void writeLocal(final int address, final int value) {
    int a;
    int[] mem;

    if (this.m_frame == null) {
      this.m_memErrors++;
    } else {
      mem = this.m_frame.m_local;
      a = mem.length;
      if (address < 0) {
        this.m_memErrors++;
        a = ((a + (address % a)) % a);
      } else if (address >= a) {
        this.m_memErrors++;
        a = (address % a);
      } else
        a = address;

      mem[a] = value;
    }
  }

  /**
   * Obtain the size of the operator stack. The operator stack is solely
   * used to store data and has, other that the stack of a pc, no
   * control-flow functionality.
   * 
   * @return the size of the operator stack
   */
  public int getStackSize() {
    if (this.m_frame != null)
      return this.m_frame.m_stack.length;
    return this.m_host.m_stackSize;
  }

  /**
   * Push a data word onto the stack. If pushing the word leads to a stack
   * overflow, the stack pointer will wrap and the stack error count is
   * increased.
   * 
   * @param data
   *          the data word
   */
  public void push(final int data) {
    int[] s;
    int sp;
    VMFrame f;

    f = this.m_frame;
    s = f.m_stack;
    sp = f.m_sp;
    if (s.length <= sp) {
      s[0] = data;
      f.m_sp = 0;
      this.m_stackErrors++;
    } else {
      s[sp] = data;
      f.m_sp = (sp + 1);
    }
  }

  /**
   * Pop a data word from the stack. If popping the word leads to a stack
   * underflow, the stack pointer will wrap and the stack error count is
   * increased.
   * 
   * @return the data word popped
   */
  public int pop() {
    int[] s;
    int sp;
    VMFrame f;

    f = this.m_frame;
    s = f.m_stack;
    sp = (f.m_sp - 1);

    if (sp < 0) {
      f.m_sp = s.length;
      this.m_stackErrors++;
      return s[0];
    }
    f.m_sp = sp;
    return s[sp];
  }

  /**
   * Obtain the count of errors that occured by accessing the stack.
   * 
   * @return the count of errors that occured by accessing the stack
   */
  public long getStackErrors() {
    return this.m_stackErrors;
  }

  /**
   * Obtain the virtual host that hosts this vm.
   * 
   * @return the virtual host that hosts this vm
   */
  public VMHost getVMHost() {
    return this.m_host;
  }

  /**
   * Obtain the current call-depth.
   * 
   * @return the current call-depth
   */
  public int getCallDepth() {
    return this.m_callDepth;
  }

  /**
   * Get the count of errors that occured during procedures calls. An error
   * may either occure when calling an invalid procedure index or due to
   * exceeding the limit of allowed nested calls.
   * 
   * @return the count of errors that occured during procedures calls
   */
  public long getCallErrors() {
    return this.m_callErrors;
  }

  /**
   * call a procedure
   * 
   * @param proc
   *          the procedure to be called
   * @return <code>true</code> if the call was successfull,
   *         <code>false</code> if it could not be performed
   */
  public boolean call(final int proc) {
    int sp;
    VMFrame f;

    f = this.m_frame;
    sp = f.m_sp;
    f.m_sp = 0;
    return this.call(proc, f.m_stack, sp);
  }

  /**
   * call a procedure
   * 
   * @param proc
   *          the procedure to be called
   * @param parameters
   *          the procedure parameters
   * @param parameterSize
   *          the count of parameters
   * @return <code>true</code> if the call was successfull,
   *         <code>false</code> if it could not be performed
   */
  private final boolean call(final int proc, final int[] parameters,
      final int parameterSize) {
    int cd, p;
    VMFrame f2;
    int[] x;

    p = this.m_code.length;
    if (proc < 0) {
      p = (((proc % p) + p) % p);
      this.m_callErrors++;
    } else if (proc >= p) {
      p = (proc % p);
      this.m_callErrors++;
    } else
      p = proc;

    cd = (this.m_callDepth + 1);
    f2 = this.m_host.allocFrame(cd);
    if (f2 == null) {
      this.m_callErrors++;
      return false;
    }

    this.m_callDepth = cd;
    f2.m_next = this.m_frame;
    this.m_frame = f2;

    if (parameterSize > 0) {
      x = f2.m_local;
      if (parameterSize > x.length) {
        this.m_memErrors++;
        cd = x.length;
      } else
        cd = parameterSize;

      System.arraycopy(parameters, 0, f2.m_local, 0, cd);
    }

    // f2.m_ip = 0;
    f2.m_code = this.m_code[p];
    return true;
  }

  /**
   * Obtain the vm frame currently active.
   * 
   * @return the vm frame currently active or <code>null</code> if the vm
   *         is in passive mode (no procedure is running).
   */
  public VMFrame getCurrentFrame() {
    return this.m_frame;
  }

  /**
   * Obtain the count of steps performed.
   * 
   * @return the count of steps performed
   */
  public long getStepCount() {
    return this.m_stepCnt;
  }

  /**
   * Obtain the count of steps spent in passive mode.
   * 
   * @return the count of steps spent in passive mode
   */
  public long getPassiveSteps() {
    return this.m_passiveSteps;
  }

  /**
   * perform one single step in the vm
   * 
   * @return <code>true</code> if the vm has performed one instruction,
   *         <code>false</code> if the machine was in sleep mode and no
   *         instruction needed to be performed
   */
  @SuppressWarnings("unchecked")
  public boolean step() {
    VMFrame f, g;
    int ip;
    int[] in;
    Instruction<? super VM>[] ic;

    this.m_stepCnt++;

    f = this.m_frame;
    if (f == null) {
      this.m_passiveSteps++;
      return false;
    }

    in = f.m_code;
    ip = f.m_ip;

    if (ip < in.length) {
      ic = this.m_is.m_instructions;
      ic[Mathematics.modulo(in[ip], ic.length)].execute(this, in[ip + 1],
          in[ip + 2], in[ip + 3]);
    }

    if (this.m_jump) {// in case a jump was performed
      ip = f.m_ip;
      this.m_jump = false;
    } else
      ip += 4;

    if (ip >= in.length) {
      g = this.m_frame;
      if (g != f) {// a procedure was called
        while ((g != null) && (g.m_next != f)) {
          // if multiple calls have been performed
          g = g.m_next;
        }
        if (g != null)// normally, something else cannot happen
        {
          g.m_next = f.m_next;
          if (f.m_interrupt)
            g.m_interrupt = true;
        } else
          this.m_callErrors++; // should not happen
      } else {
        this.m_frame = f.m_next;
        if (f.m_interrupt)
          this.m_interrupt = false;
      }
      // new - return value, interrupts dont have none
      if ((f.m_sp > 0) && (!(f.m_interrupt))) {
        if (this.m_frame != null)
          this.push(f.m_stack[0]);// store the return value
        else
          this.m_global[0] = f.m_stack[0];
      }

      this.m_host.disposeFrame(f);// drop the frame
      // this behavior accomplishes tail recursion resolution
      this.m_callDepth--;
    } else {
      f.m_ip = ip;
    }

    return true;
  }

  /**
   * Check whether we're currently inside an interrupt.
   * 
   * @return <code>true</code> if and only if the current code was
   *         invoked as interrupt, <code>false</code> otherwise
   */
  public boolean isInterrupt() {
    return this.m_interrupt;
  }

  /**
   * Invoke the specified procedure as interrupt. If an interrupt is
   * already running, nothing will be done.
   * 
   * @param proc
   *          the interrupt routine.
   * @param parameters
   *          the parameters of the interrupt
   * @param parameterSize
   *          the count of parameters
   */
  public void interrupt(final int proc, final int[] parameters,
      final int parameterSize) {
    if (this.m_interrupt)
      this.m_missedInterrupts++;
    else {
      this.m_interrupt = true;
      if (this.call(proc, parameters, parameterSize))
        this.m_interrupts++;
      this.m_frame.m_interrupt = true;
    }
  }

  /**
   * Obtain the count of interrupts that could not be performed because an
   * interrupt was already running.
   * 
   * @return the count of interrupts that could not be performed because an
   *         interrupt was already running
   */
  public long getMissedInterrupts() {
    return this.m_missedInterrupts;
  }

  /**
   * Obtain the count of interrupts performed. Only those interrupts which
   * resulted in a successfull invokation of the interrupt handler are
   * counted.
   * 
   * @return the count of interrupts performed
   */
  public long getPerformedInterrupts() {
    return this.m_interrupts;
  }

  /**
   * Perform an absolute jump to the instruction at the specified index
   * inside the current procedure. If the index is negative, it will be set
   * to <code>0</code>. If the vm is in passive mode, nothing will be
   * done. If the index is outside the procedure (because it is too large)
   * this will lead to the termination of the procedure.
   * 
   * @param index
   *          the absolute index of the instruction to jump to
   */
  public void jumpAbsolute(final int index) {
    VMFrame f;

    f = this.m_frame;
    if (f != null) {
      f.m_ip = ((index > 0) ? (index << 2) : 0);
      this.m_jump = true;
    }
  }

  /**
   * Perform a relative jump. If the resulting index is negative, it will
   * be set to <code>0</code>. If the vm is in passive mode, nothing
   * will be done. If the resulting index is outside the procedure (because
   * it is too large) this will lead to the termination of the procedure.
   * 
   * @param index
   *          the relative index of the instruction to jump to
   */
  public void jumpRelative(final int index) {
    VMFrame f;
    int j;

    f = this.m_frame;
    if (f != null) {
      j = (f.m_ip + (index << 2));
      f.m_ip = ((j > 0) ? j : 0);
      this.m_jump = true;
    }
  }

  /**
   * obtain the global memory size of the hosted vms.
   * 
   * @return the global memory size of the hosted vms
   */
  public int getGlobalMemorySize() {
    return this.m_global.length;
  }

  /**
   * obtain the local memory size of the hosted vms.
   * 
   * @return the local memory size of the hosted vms
   */
  public int getLocalMemorySize() {
    return this.m_host.m_localSize;
  }

  /**
   * Obtain the maximum call depth of the hosted vms.
   * 
   * @return the maximum call depth of the hosted vms
   */
  public int getMaxCallDepth() {
    return this.m_host.getMaxCallDepth();
  }

  /**
   * Check whether the vm(s) have no active procedure currently running.
   * 
   * @return <code>true</code> if no procedure/code is currently running
   *         and everything rests, <code>false</code> otherwise.
   */
  public boolean hasTerminated() {
    return (this.m_frame == null);
  }

  /**
   * Append this virtual machine's textual representation to a string
   * builder.
   * 
   * @param sb
   *          the string builder to append to.
   */
  @Override
  public void toStringBuilder(final StringBuilder sb) {
    VMFrame f;
    int i, j;
    int[][] code;

    code = this.m_code;
    f = this.m_frame;
    if ((code != null) && (f != null)) {
      i = 0;
      for (; f != null; f = f.m_next) {
        for (j = (code.length - 1); j >= 0; j--) {
          if (code[j] == f.m_code)
            break;
        }

        sb.append(FRAME);
        sb.append(i++);
        sb.append(FRAME2);
        Program.appendFunctionName(j, sb);
        sb.append(TextUtils.LINE_SEPARATOR);
        f.toStringBuilder(sb);
        sb.append(TextUtils.LINE_SEPARATOR);
      }
      sb.append(TextUtils.LINE_SEPARATOR);
    }

    sb.append(DATA);
    TextUtils.toStringBuilder(this.m_global, sb);
    sb.append(MEM_ERRORS);
    sb.append(this.m_memErrors);

    // sb.append(STACK);
    // TextUtils.toStringBuilder(this.m_stack, sb);
    // sb.append(STACK_PTR);
    // sb.append(this.m_sp);
    sb.append(STACK_ERRORS);
    sb.append(this.m_stackErrors);

    sb.append(INTERRUPTS);
    sb.append(this.m_interrupts);
    sb.append(MISSED_INTS);
    sb.append(this.m_missedInterrupts);

    sb.append(STEPS);
    sb.append(this.m_stepCnt);
    sb.append(PASSIVE_STEPS);
    sb.append(this.m_passiveSteps);

    sb.append(TextUtils.LINE_SEPARATOR);
    sb.append(TextUtils.LINE_SEPARATOR);

    super.toStringBuilder(sb);
  }

  // /**
  // * Clear the stack
  // */
  // protected void clearStack() {
  // this.m_frame.m_sp = 0;
  // }
}
