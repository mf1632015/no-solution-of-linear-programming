/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 *
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-17
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.machine.ll.vm.MemoryRecord.java
 * Last modification: 2006-12-17
 *                by: Thomas Weise
 *
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.machine.ll.vm;

import java.io.Serializable;

/**
 * A memory record
 * 
 * @author Thomas Weise
 */
public class MemoryRecord implements Serializable {
  /**
   * the serial version uid
   */
  private static final long serialVersionUID = 0;

  /**
   * the mem
   */
  private final int[] m_mem;

  /**
   * the mem pointer
   */
  private int m_size;

  /**
   * Create a new memory record.
   * 
   * @param memSize
   *          the mem size
   */
  public MemoryRecord(final int memSize) {
    super();
    this.m_mem = new int[memSize];
  }

  /**
   * take the stack from a vm frame
   * 
   * @param f
   *          the vm frame
   */
  public final void takeStack(final VMFrame f) {
    int sp;

    sp = f.m_sp;
    if (sp > 0) {
      System.arraycopy(f.m_stack, 0, this.m_mem, 0, sp);
      f.m_sp = 0;
      this.m_size = sp;
    } else
      this.m_size = 0;
  }

  /**
   * take the stack from a vm frame
   * 
   * @param vm
   *          the vm
   */
  public final void takeStack(final VM vm) {
    this.takeStack(vm.m_frame);
  }

  /**
   * Invoke an interrupt with this record's memory as data
   * 
   * @param vm
   *          the vm
   * @param index
   *          the interrupt index
   */
  public final void interrupt(final VM vm, final int index) {
    vm.interrupt(index, this.m_mem, this.m_size);
  }

  /**
   * Clear the stack of the given frame
   * 
   * @param f
   *          the frame to clear the stack of
   */
  protected static final void clearStack(final VMFrame f) {
    f.m_sp = 0;
  }

  /**
   * Clear the stack of the given vm
   * 
   * @param vm
   *          the vm to clear the stack of
   */
  protected static final void clearStack(final VM vm) {
    clearStack(vm.m_frame);
  }

}
