/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 *
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-02-27
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.machine.ll.vm.InstructionSetBuilder.java
 * Last modification: 2007-02-27
 *                by: Thomas Weise
 *
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.machine.ll.vm;

/**
 * This class is used to compile an instruction set
 * 
 * @param <V>
 *          the vm type
 * @author Thomas Weise
 */
public class InstructionSetBuilder<V extends VM> {
  /**
   * The instructions
   */
  Instruction<? super V>[] m_instructions;

  /**
   * the instruction count
   */
  int m_instructionCount;

  /**
   * Create a new instruction set builder
   * 
   * @param inherit
   *          the instruction set to inherite from
   */
  @SuppressWarnings("unchecked")
  public InstructionSetBuilder(final InstructionSet<? super V> inherit) {
    super();
    InstructionSet<VM> i;

    this.m_instructions = new Instruction[20];

    i = ((InstructionSet<VM>) inherit);

    // ((inherit == null) ? DefaultInstructionSet.INSTRUCTION_SET
    // : ((InstructionSet<VM>) inherit));
    if (i != null)
      this.addInstructionSet(i);

  }

  /**
   * Add a whole instruction set to this instruction set builder.
   * 
   * @param is
   *          the instruction set
   */
  @SuppressWarnings("unchecked")
  public void addInstructionSet(final InstructionSet<? super V> is) {
    int s, j;
    boolean b;
    Instruction<? extends V> i;

    j = is.size();
    b = (this.m_instructionCount > 0);
    for (s = 0; s < j; s++) {
      i = ((Instruction<? extends V>) (is.get(s)));
      if (b)
        i = i.copy();
      this.addInstruction((Instruction<? super V>) i);
    }
  }

  /**
   * Create a new instruction set.
   * 
   * @param instructions
   *          the instructions
   * @return the instruction set
   */
  protected InstructionSet<V> createInstructionSet(
      final Instruction<? super V>[] instructions) {
    return new InstructionSet<V>(instructions);
  }

  /**
   * Obtain the instruction set.
   * 
   * @return the instruction set.
   */
  @SuppressWarnings("unchecked")
  public synchronized InstructionSet<V> build() {
    Instruction<? super V>[] ins;
    int c;
    InstructionSet<V> is;

    c = this.m_instructionCount;
    ins = new Instruction[c];

    System.arraycopy(this.m_instructions, 0, ins, 0, c);

    is = this.createInstructionSet(ins);

    for (--c; c >= 0; c--)
      ins[c].m_instructionSet = ((InstructionSet) is);

    this.m_instructionCount = 0;

    return is;
  }

  /**
   * Add an instruction to this instruction set.
   * 
   * @param instruction
   *          the instruction to be added
   */
  @SuppressWarnings("unchecked")
  synchronized final void addInstruction(
      final Instruction<? super V> instruction) {
    Instruction<? super V>[] i;
    int c;

    i = this.m_instructions;
    c = this.m_instructionCount;
    if (c >= i.length) {
      i = new Instruction[c << 1];
      System.arraycopy(this.m_instructions, 0, i, 0, c);
      this.m_instructions = i;
    }
    i[c] = instruction;
    instruction.m_opCode = c;
    this.m_instructionCount = (c + 1);
  }
}
