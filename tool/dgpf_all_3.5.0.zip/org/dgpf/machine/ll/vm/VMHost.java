/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 *
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-16
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.machine.ll.vm.VMHost.java
 * Last modification: 2006-12-16
 *                by: Thomas Weise
 *
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.machine.ll.vm;

/**
 * A vm host manages all virtual machines.
 * 
 * @author Thomas Weise
 */
public class VMHost extends VMParameters {
  /**
   * the serial version uid
   */
  private static final long serialVersionUID = 1;

  /**
   * the vacant frames
   */
  private transient VMFrame m_frames;

  /**
   * create a new virtual machine host
   * 
   * @param globalSize
   *          the global memory size
   * @param localSize
   *          the local memory size
   * @param stackSize
   *          the stack size
   * @param maxCallDepth
   *          the maximum call depth
   * @throws IllegalArgumentException
   *           if
   *           <code>globalSize&lt;1 || localSize&lt;1 || stackSize&lt;1||maxCallDepth&lt;0</code>
   */
  public VMHost(final int globalSize, final int localSize,
      final int stackSize, final int maxCallDepth) {
    super(globalSize, localSize, stackSize, maxCallDepth);
  }

  /**
   * Create a new virtual machine host by using a set of vm parameters.
   * 
   * @param parameters
   *          the parameters to be used
   * @throws NullPointerException
   *           if <code>parameters==null</code>
   * @throws IllegalArgumentException
   *           if the parameters contain illegal settings
   */
  public VMHost(final IVMParameters parameters) {
    this(parameters.getGlobalMemorySize(),
        parameters.getLocalMemorySize(), parameters.getStackSize(),
        parameters.getMaxCallDepth());
  }

  /**
   * allocate a new frame
   * 
   * @param depth
   *          the current call depth
   * @return the new frame, or <code>null</code> if the call depth would
   *         exceed the limit
   */
  final VMFrame allocFrame(final int depth) {
    VMFrame f;
    if (depth > this.m_maxCallDepth)
      return null;
    f = this.m_frames;
    if (f != null) {
      this.m_frames = f.m_next;
      f.m_next = null;
      return f;
    }

    return new VMFrame(this.m_localSize, this.m_stackSize);
  }

  /**
   * dispose a virtual machine frame
   * 
   * @param f
   *          the frame to be disposed
   */
  final void disposeFrame(final VMFrame f) {
    f.m_next = this.m_frames;
    this.m_frames = f;
    f.clear();
  }
}
