/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 *
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-02-27
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.machine.ll.vm.Program.java
 * Last modification: 2007-02-27
 *                by: Thomas Weise
 *
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.machine.ll.vm;

import java.io.Serializable;

import org.sfc.math.Mathematics;
import org.sfc.text.TextUtils;
import org.sigoa.refimpl.utils.JavaTextable;

/**
 * A program.
 * 
 * @param <V>
 *          the vm type
 * @author Thomas Weise
 */
public class Program<V extends VM> extends JavaTextable implements
    Serializable {
  /**
   * the serial version uid
   */
  private static final long serialVersionUID = 1;

  /**
   * the instruction set this program belongs to
   */
  InstructionSet<? super V> m_is;

  /**
   * the program code
   */
  int[][] m_code;

  /**
   * The empty program.
   */
  @SuppressWarnings("unchecked")
  public static final Program<?> EMPTY_PROGRAM = new Program<VM>(
      ((InstructionSet<VM>) (InstructionSet.EMPTY_INSTRUCTION_SET)),
      new int[1][0]) {
    private static final long serialVersionUID = 1;

    private final Object readResolve() {
      return EMPTY_PROGRAM;
    }

    private final Object writeReplace() {
      return EMPTY_PROGRAM;
    }
  };

  /**
   * the default indentation
   */
  private static final char[] INDENT = (TextUtils.LINE_SEPARATOR + "  ").toCharArray();//$NON-NLS-1$

  /**
   * the procedure name
   */
  private static final char[] FUNC_CHARS = "function_".toCharArray(); //$NON-NLS-1$

  /**
   * the internal constructor
   */
  Program() {
    super();
  }

  /**
   * Initialize this program by another program
   * 
   * @param program
   *          the program
   */
  @SuppressWarnings("unchecked")
  void init(final Program<? super V> program) {
    this.m_code = program.m_code;
    this.m_is = program.m_is;
  }

  /**
   * create a new program
   * 
   * @param blueprint
   *          the program to be copied
   */
  public Program(final Program<? super V> blueprint) {
    this();
    this.init(blueprint);
  }

  /**
   * create a new program
   * 
   * @param code
   *          the code
   * @param is
   *          the instruction set utilized by this program
   */
  @SuppressWarnings("unchecked")
  public Program(final InstructionSet<? super V> is, final int[][] code) {
    this();
    this.m_code = code;
    this.m_is = ((is == null) ? //
    ((InstructionSet<VM>) (DefaultInstructionSet.INSTRUCTION_SET))
        : ((InstructionSet<VM>) is));
  }

  /**
   * Serializes the parameters of the constructor of this object.
   * 
   * @param sb
   *          the string builder
   * @param indent
   *          an optional parameter denoting the indentation
   */
  @Override
  protected void javaParametersToStringBuilder(final StringBuilder sb,
      final int indent) {

    if (this.m_is != null) {
      if (!(JavaTextable.findConstant(this.m_is, sb))) {
        this.m_is.javaToStringBuilder(sb, indent);
      }
    } else
      sb.append((Object) null);

    sb.append(", new "); //$NON-NLS-1$
    TextUtils.toStringBuilder(this.m_code, sb);
  }

  /**
   * Append the name of the procedure with the specified index to a string
   * builder.
   * 
   * @param index
   *          the index of the procedure
   * @param sb
   *          the string builder.
   */
  public static final void appendFunctionName(final int index,
      final StringBuilder sb) {
    sb.append(FUNC_CHARS);
    sb.append(index);
  }

  /**
   * Write this program's human readable representation to a string
   * builder.
   * 
   * @param add
   *          the string builder to write to
   */
  @Override
  @SuppressWarnings("unchecked")
  public void toStringBuilder(final StringBuilder add) {
    int[][] code;
    int[] c;
    int i, j, x, y, z, k;
    Instruction<? super V> ins;
    Instruction<? super V>[] ic;
    InstructionSet<? super V> is;

    is = this.m_is;
    code = this.m_code;
    if (code != null) {
      ic = is.m_instructions;
      for (i = 0; i < code.length; i++) {
        if (i > 0)
          add.append(TextUtils.LINE_SEPARATOR);
        appendFunctionName(i, add);
        add.append(':');
        c = code[i];

        x = 0;
        for (j = ((c.length >>> 2) - 1); j > 0; j /= 10) {
          x++;
        }

        for (j = 0, k = 0; k < c.length; j++, k += 4) {
          add.append(INDENT);

          if (j <= 0) {
            z = (x - 1);
          } else {
            z = x;
            for (y = j; y > 0; y /= 10) {
              z--;
            }
          }

          for (; z > 0; z--)
            add.append(' ');
          add.append(j);
          add.append(':');
          add.append(' ');

          ins = ic[Mathematics.modulo(c[k], ic.length)];

          // ((Instruction<V>) (InstructionSet.get(c[k],
          // is.m_instructions)));
          ins.toStringBuilder(c[k + 1], c[k + 2], c[k + 3], add);
        }
      }
    }
  }

  /**
   * obtain the count of procedures of this program
   * 
   * @return the count of procedures of this program
   */
  public int getFunctionCount() {
    return this.m_code.length;
  }

  /**
   * Obtain the count of instructions of a certain function.
   * 
   * @param function
   *          the function index
   * @return the count of instructions of the certain function
   */
  public int getInstructionCount(final int function) {
    return (this.m_code[function].length >>> 2);
  }

  /**
   * Obtain the total instruction count
   * 
   * @return the total instruction count
   */
  public int getInstructionCount() {
    int[][] x;
    int i, c;

    x = this.m_code;
    c = 0;
    for (i = (x.length - 1); i >= 0; i--) {
      c += (x[i].length >>> 2);
    }

    return c;
  }

  /**
   * Check whether this program equals another object.
   * 
   * @param o
   *          the object
   * @return <code>true</code> if the specified object is the same as
   *         this one
   */
  @Override
  @SuppressWarnings("unchecked")
  public boolean equals(final Object o) {
    int[][] code1, code2;
    int[] c1, c2;
    Program<V> p;
    int i, j;

    if (o == this)
      return true;

    if (o instanceof Program) {
      p = ((Program) o);
      code1 = this.m_code;
      code2 = p.m_code;

      if (code1 == null) {
        if (code2 == null)
          return true;
        return false;
      }
      if (code2 == null)
        return false;

      i = code1.length;
      if (i != code2.length)
        return false;

      for (--i; i >= 0; i--) {
        c1 = code1[i];
        c2 = code2[i];
        j = c1.length;
        if (j != c2.length)
          return false;

        for (--j; j >= 0; j--) {
          if (c1[j] != c2[j])
            return false;
        }
      }

      return true;
    }
    return false;
  }

  // /**
  // * Count the occurences of the specified instruction.
  // *
  // * @param opCode
  // * the opcode of the instruction
  // * @return the number of its occurences
  // */
  // public int countInstruction(final int opCode) {
  // int[][] ccc;
  // int[] cc;
  // int i, j, c, l, oc;
  //
  // c = 0;
  // l = this.m_is.m_instructions.length;
  // oc = Mathematics.modulo(opCode, l);
  // ccc = this.m_code;
  // for (i = (ccc.length - 1); i >= 0; i--) {
  // cc = ccc[i];
  // for (j = (cc.length - 4); j >= 0; j -= 4) {
  // if (Mathematics.modulo(cc[j], l) == oc)
  // c++;
  // }
  //    }
  //
  //    return c;
  //  }
  
  /**
   * Count the occurences of the specified instruction.
   * 
   * @param instruction
   *          the instruction
   * @return the number of its occurences
   */
  public int countInstruction(final Instruction<?> instruction) {
    int[][] ccc;
    int[] cc;
    int i, j, c, l, oc;

    c = 0;
    l = this.m_is.m_instructions.length;
    oc = Mathematics.modulo(instruction.getOpCode(), l);
    ccc = this.m_code;
    for (i = (ccc.length - 1); i >= 0; i--) {
      cc = ccc[i];
      for (j = (cc.length - 4); j >= 0; j -= 4) {
        if (Mathematics.modulo(cc[j], l) == oc)
          c++;
      }
    }

    return c;
  }
}
