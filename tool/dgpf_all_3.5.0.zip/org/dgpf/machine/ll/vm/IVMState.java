/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-01-07
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.machine.ll.vm.IVMState.java
 * Last modification: 2007-01-07
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.machine.ll.vm;

/**
 * The state of one or multiple virtual machine(s),
 * 
 * @author Thomas Weise
 */
public interface IVMState extends IVMParameters {
  /**
   * Obtain the count of memory access errors encountered during program
   * execution.
   * 
   * @return the count of memory access errors encountered during program
   *         execution
   */
  public abstract long getMemoryAccessErrors();

  /**
   * Obtain the count of errors that occured by accessing the stack.
   * 
   * @return the count of errors that occured by accessing the stack
   */
  public abstract long getStackErrors();

  /**
   * Get the count of errors that occured during procedures calls. An error
   * may either occure when calling an invalid procedure index or due to
   * exceeding the limit of allowed nested calls.
   * 
   * @return the count of errors that occured during procedures calls
   */
  public abstract long getCallErrors();

  /**
   * Obtain the count of steps performed.
   * 
   * @return the count of steps performed
   */
  public abstract long getStepCount();

  /**
   * Obtain the count of steps spent in passive mode.
   * 
   * @return the count of steps spent in passive mode
   */
  public abstract long getPassiveSteps();

  /**
   * Obtain the count of interrupts that could not be performed because an
   * interrupt was already running.
   * 
   * @return the count of interrupts that could not be performed because an
   *         interrupt was already running
   */
  public abstract long getMissedInterrupts();

  /**
   * Obtain the count of interrupts performed. Only those interrupts which
   * resulted in a successfull invokation of the interrupt handler are
   * counted.
   * 
   * @return the count of interrupts performed
   */
  public abstract long getPerformedInterrupts();

  /**
   * obtain the count of functions of this program
   * 
   * @return the count of functions of this program
   */
  public abstract int getFunctionCount();


  /**
   * Check whether the vm(s) have no active procedure currently running.
   * 
   * @return <code>true</code> if no procedure/code is currently running
   *         and everything rests, <code>false</code> otherwise.
   */
  public abstract boolean hasTerminated();
  
  /**
   * Obtain the count of instructions of a certain function.
   * 
   * @param function
   *          the function index
   * @return the count of instructions of the certain function
   */
  public abstract int getInstructionCount(final int function);

  /**
   * Obtain the total instruction count
   * 
   * @return the total instruction count
   */
  public abstract int getInstructionCount();
}
