/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 *
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-16
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.machine.ll.vm.VMParameters.java
 * Last modification: 2006-12-16
 *                by: Thomas Weise
 *
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.machine.ll.vm;

/**
 * A vm host manages all virtual machines.
 * 
 * @author Thomas Weise
 */
public class VMParameters implements IVMParameters {
  /**
   * the serial version uid
   */
  private static final long serialVersionUID = 1;

  /**
   * the global memory size of the hosted virtual machines
   */
  final int m_globalSize;

  /**
   * the local memory size of the hosted virtual machines
   */
  final int m_localSize;

  /**
   * the stack size
   */
  final int m_stackSize;

  /**
   * the maximum call depths of the hosted virtual machines.
   */
  final int m_maxCallDepth;

  /**
   * Create a new set of virtual machine frame parameters.
   * 
   * @param globalSize
   *          the global memory size
   * @param localSize
   *          the local memory size
   * @param stackSize
   *          the stack size
   * @param maxCallDepth
   *          the maximum call depth
   * @throws IllegalArgumentException
   *           if
   *           <code>globalSize&lt;1 || localSize&lt;1  || stackSize&lt;1 || maxCallDepth&lt;0</code>
   */
  public VMParameters(final int globalSize, final int localSize,
      final int stackSize, final int maxCallDepth) {
    super();
    if ((globalSize < 1) || (localSize < 1) || (stackSize < 1)
        || (maxCallDepth < 0))
      throw new IllegalArgumentException();
    this.m_globalSize = globalSize;
    this.m_maxCallDepth = maxCallDepth;
    this.m_localSize = localSize;
    this.m_stackSize = stackSize;
  }

  /**
   * Create an instance of the virtual machine parameters by copying an
   * existing one.
   * 
   * @param parameters
   *          the parameters to be copied
   * @throws NullPointerException
   *           if <code>parameters==null</code>
   * @throws IllegalArgumentException
   *           if the parameters contain illegal settings
   */
  public VMParameters(final IVMParameters parameters) {
    this(parameters.getGlobalMemorySize(),
        parameters.getLocalMemorySize(), parameters.getStackSize(),
        parameters.getMaxCallDepth());
  }

  /**
   * obtain the global memory size of the hosted vms.
   * 
   * @return the global memory size of the hosted vms
   */
  public int getGlobalMemorySize() {
    return this.m_globalSize;
  }

  /**
   * obtain the local memory size of the hosted vms.
   * 
   * @return the local memory size of the hosted vms
   */
  public int getLocalMemorySize() {
    return this.m_localSize;
  }

  /**
   * Obtain the maximum call depth of the hosted vms.
   * 
   * @return the maximum call depth of the hosted vms
   */
  public int getMaxCallDepth() {
    return this.m_maxCallDepth;
  }

  /**
   * Obtain the stack size.
   * 
   * @return the stack size
   */
  public int getStackSize() {
    return this.m_stackSize;
  }
}
