/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 *
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-02-26
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.machine.ll.vm.InstructionSet.java
 * Last modification: 2007-02-26
 *                by: Thomas Weise
 *
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.machine.ll.vm;

import java.io.Serializable;

import org.sfc.math.Mathematics;
import org.sfc.text.TextUtils;
import org.sigoa.refimpl.utils.JavaTextable;

/**
 * The instruction set
 * 
 * @param <V>
 *          the vm type
 * @author Thomas Weise
 */
public class InstructionSet<V extends VM> extends JavaTextable implements
    Serializable {
  /** the serial version uid */
  private static final long serialVersionUID = 1;

  /**
   * the instruction set builder string
   */
  static final char[] ISB_STR;

  /**
   * the instruction set builder creation string
   */
  private static final char[] ISB_CSTR;

  /**
   * the instruction set builder string
   */
  private static final char[] ISB_BSTR;

  static {
    String isb;

    isb = "isb";//$NON-NLS-1$
    ISB_STR = isb.toCharArray();

    ISB_BSTR = ("InstructionSetBuilder<VM> " + isb//$NON-NLS-1$
        + " = new InstructionSetBuilder<VM>(null);" + //$NON-NLS-1$
    TextUtils.LINE_SEPARATOR).toCharArray();
    ISB_CSTR = (isb + ".build();").toCharArray();//$NON-NLS-1$
  }

  /**
   * the empty instruction set.
   */
  @SuppressWarnings("unchecked")
  public static final InstructionSet<?> EMPTY_INSTRUCTION_SET = new InstructionSet<VM>(
      new Instruction[0]) {
    private static final long serialVersionUID = 1;

    private final Object readResolve() {
      return EMPTY_INSTRUCTION_SET;
    }

    private final Object writeReplace() {
      return EMPTY_INSTRUCTION_SET;
    }
  };

  /**
   * The instructions
   */
  transient final Instruction<? super V>[] m_instructions;

  /**
   * Create a new instruction set
   * 
   * @param instructions
   *          the instructions
   */
  protected InstructionSet(final Instruction<? super V>[] instructions) {
    super();
    this.m_instructions = instructions;
  }

  /**
   * Obtain the instruction that belongs to the given opcode.
   * 
   * @param opCode
   *          the op-code
   * @return the instruction
   */
  @SuppressWarnings("unchecked")
  public Instruction<? super V> get(final int opCode) {
    Instruction<? super V>[] i;
    i = this.m_instructions;
    return i[Mathematics.modulo(opCode, i.length)];
    // get(opCode, this.m_instructions);
  }

  /**
   * Serializes this object as string to a java string builder. The string
   * appended to the string builder can be copy-and-pasted into a java file
   * and represents the constructor of this object.
   * 
   * @param sb
   *          the string builder
   * @param indent
   *          an optional parameter denoting the indentation
   */
  @Override
  public void javaToStringBuilder(final StringBuilder sb, final int indent) {
    Instruction<?>[] cc;
    int i;

    sb.append(ISB_BSTR);

    cc = this.m_instructions;
    for (i = 0; i < cc.length; i++) {
      sb.append(TextUtils.LINE_SEPARATOR);
      TextUtils.appendSpaces(sb, indent);
      cc[i].javaToStringBuilder(sb, indent);
      sb.append(';');
    }
    sb.append(TextUtils.LINE_SEPARATOR);
    TextUtils.appendSpaces(sb, indent);
    sb.append(ISB_CSTR);
  }

  /**
   * Obtain the size of the instruction set
   * 
   * @return the size of the instruction set
   */
  public int size() {
    return this.m_instructions.length;
  }

  // /**
  // * Obtain the instruction of the given opcode from the instruction set.
  // *
  // * @param opCode
  // * the op-code
  // * @param ins
  // * the instruction set
  // * @return the instruction
  // */
  // @SuppressWarnings("unchecked")
  // static final Instruction<VM> get(final int opCode,
  // final Instruction[] ins) {
  // int l;
  // l = ins.length;
  // if (opCode < 0)
  // return ins[((opCode % l) + l) % l];
  // if (opCode < l)
  // return ins[opCode];
  // return ins[opCode % l];
  // }

  /**
   * Checks whether this instruction set equals another object
   * 
   * @param o
   *          the object to compare with
   * @return <code>true</code> if the objects equal each other,<code>false/<code> otherwise
   */
  @Override
  @SuppressWarnings("unchecked")
  public boolean equals(final Object o) {
    Instruction<? super V>[] i1, i2;
    int j1;

    if (o == this)
      return true;
    if (!(o instanceof InstructionSet))
      return false;

    i1 = ((InstructionSet) o).m_instructions;
    i2 = this.m_instructions;
    j1 = i1.length;
    if (j1 != i2.length)
      return false;
    for (--j1; j1 >= 0; j1--) {
      if (!(i1[j1].equals(i2[j1])))
        return false;
    }
    return true;
  }

  /**
   * Obtain the instance of the instruction identified by the specified
   * class.
   * 
   * @param cls
   *          the class
   * @return the instruction or <code>null</code> if no such instruction
   *         exists
   */
  @SuppressWarnings("unchecked")
  public Instruction<? super V> getInstance(
      final Class<? extends Instruction<? super V>> cls) {
    Instruction<? super V>[] ins;
    int c;

    ins = this.m_instructions;
    for (c = (ins.length - 1); c >= 0; c--) {
      if (ins[c].getClass().equals(cls))
        return ins[c];
    }
    return null;
  }
}
