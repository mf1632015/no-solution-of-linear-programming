/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-22
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.machine.gp.objectives.StaticProgramObjectiveFunction.java
 * Last modification: 2006-12-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.machine.gp.objectives;

import org.dgpf.machine.ll.vm.Program;
import org.dgpf.machine.ll.vm.VM;
import org.sigoa.refimpl.go.objectives.ObjectiveState;
import org.sigoa.refimpl.go.objectives.StaticObjectiveFunction;
import org.sigoa.refimpl.go.objectives.StaticObjectiveState;
import org.sigoa.spec.simulation.ISimulation;

/**
 * The basic static objective function for programs
 * 
 * @author Thomas Weise
 */
public class StaticProgramObjectiveFunction
    extends
    StaticObjectiveFunction<Program<VM>, ObjectiveState, StaticObjectiveState, ISimulation<Program<VM>>> {
  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * The program sanity check
   * 
   * @param individual
   *          The individual to be checked.
   * @param staticState
   *          the static state record
   * @return <code>true</code> if and only if the individual is worth
   *         being examined. <code>false</code> if it can be thrown away.
   * @throws NullPointerException
   *           if <code>individual==null</code>
   */
  @Override
  public boolean sanityCheck(final Program<VM> individual,
      final StaticObjectiveState staticState) {
    return ProgramObjectiveUtils.sanityCheck(individual);
  }

}
