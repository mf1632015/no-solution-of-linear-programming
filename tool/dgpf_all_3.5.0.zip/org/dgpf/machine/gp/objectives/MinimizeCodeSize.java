/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-22
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.machine.gp.objectives.MinimizeCodeSize.java
 * Last modification: 2006-12-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.machine.gp.objectives;

import org.dgpf.machine.ll.vm.Program;
import org.dgpf.machine.ll.vm.VM;
import org.sigoa.refimpl.go.objectives.ObjectiveState;
import org.sigoa.refimpl.go.objectives.StaticObjectiveState;
import org.sigoa.spec.go.OptimizationUtils;
import org.sigoa.spec.go.objectives.IObjectiveFunction;
import org.sigoa.spec.simulation.ISimulation;

/**
 * This objective function produces pressure in the direction of smaller
 * programs
 * 
 * @author Thomas Weise
 */
public class MinimizeCodeSize extends StaticProgramObjectiveFunction {
  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * The globally shared instance of this objective function
   */
  public static final IObjectiveFunction<Program<VM>, ObjectiveState, StaticObjectiveState, ISimulation<Program<VM>>> MINIMIZE_CODE_SIZE = new MinimizeCodeSize();

  /**
   * Create the objective function
   */
  protected MinimizeCodeSize() {
    super();
  }

  /**
   * read resolve
   * 
   * @return the read resolution
   */
  private final Object readResolve() {
    return MINIMIZE_CODE_SIZE;
  }

  /**
   * write replace
   * 
   * @return the write replacement
   */
  private final Object writeReplace() {
    return MINIMIZE_CODE_SIZE;
  }

  /**
   * This method is called only once per individual and is used to compute
   * its objective value.
   * 
   * @param individual
   *          The individual to be checked.
   * @param staticData
   *          the static data record
   * @return the objective value
   */
  @Override
  protected double computeValue(final Program<VM> individual,
      final StaticObjectiveState staticData) {

    if (individual != null) {
      return individual.getInstructionCount();
    }
    return OptimizationUtils.WORST;
  }

  /**
   * Append this object's textual representation to a string builder.
   * 
   * @param sb
   *          The string builder to append to.
   * @see #toString()
   */
  @Override
  public void toStringBuilder(final StringBuilder sb) {
    sb.append( "code_size"); //$NON-NLS-1$
  }
}
