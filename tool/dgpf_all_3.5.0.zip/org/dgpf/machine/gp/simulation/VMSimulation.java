/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-22
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.machine.gp.simulation.VMSimulation.java
 * Last modification: 2006-12-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.machine.gp.simulation;

import java.io.Serializable;

import org.dgpf.machine.ll.vm.IVMFactory;
import org.dgpf.machine.ll.vm.IVMParameters;
import org.dgpf.machine.ll.vm.IVMState;
import org.dgpf.machine.ll.vm.Program;
import org.dgpf.machine.ll.vm.VM;
import org.dgpf.machine.ll.vm.VMHost;
import org.sigoa.refimpl.simulation.Simulation;

/**
 * A simulator capable of simulating one single virtual machine.
 * 
 * @author Thomas Weise
 */
public class VMSimulation extends Simulation<Program<VM>> implements
    IVMState {
  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * the id of the single virtual machine simulator
   */
  public static final Serializable SINGLE_VM_SIMULATION_ID = VMSimulation.class;

  /**
   * the virtual machine host of this simulation.
   */
  private final VMHost m_host;

  /**
   * the virtual machine.
   */
  private final VM m_vm;

  /**
   * Instantiate the simulation.
   * 
   * @param parameters
   *          the virtual machine parameters that go for this simulation.
   * @param factory
   *          the VM factory or <code>null</code> for a reasonable
   *          default
   */
  public VMSimulation(final IVMParameters parameters,
      final IVMFactory<?> factory) {
    super();
    this.m_host = new VMHost(parameters);
    this.m_vm = ((factory != null) ? factory.createVM(this.m_host)
        : new VM(this.m_host));
  }

  /**
   * Instantiate the simulation.
   * 
   * @param parameters
   *          the virtual machine parameters that go for this simulation.
   */
  public VMSimulation(final IVMParameters parameters) {
    this(parameters,null);
  }

  /**
   * Obtain the virtual machine simulated with this simulator.
   * 
   * @return the virtual machine simulated with this simulator
   */
  public VM getVM() {
    return this.m_vm;
  }

  /**
   * This method is called right before the simulation begins.
   * 
   * @param what
   *          The item to be simulated.
   * @throws NullPointerException
   *           if <code>what</code> is <code>null</code>.
   */
  @Override
  public void beginSimulation(final Program<VM> what) {
    super.beginSimulation(what);
    this.m_vm.init(what);
  }

  /**
   * Perform <code>steps</code> simulation steps.
   * 
   * @param steps
   *          The count of simulation steps to be performed.
   * @return <code>true</code> if and only if further simulating would
   *         possible change the state of the simulation,
   *         <code>false</code> if the simulation has come to a final,
   *         terminal state which cannot change anymore.
   * @throws IllegalStateException
   *           If this simulation is not yet running.
   * @throws IllegalArgumentException
   *           if <code>steps <= 0</code>.
   */
  @Override
  public boolean simulate(final long steps) {
    // if (this.m_what == null)
    // throw new IllegalStateException();
    // if (steps <= 0)
    // throw new IllegalArgumentException();
    long l;
    VM v;

    v = this.m_vm;
    for (l = steps; l > 0; l--) {
      if (!(v.step()))
        return false;
    }
    return true;
  }

  /**
   * obtain the global memory size of the hosted vms.
   * 
   * @return the global memory size of the hosted vms
   */
  public int getGlobalMemorySize() {
    return this.m_vm.getGlobalMemorySize();
  }

  /**
   * obtain the local memory size of the hosted vms.
   * 
   * @return the local memory size of the hosted vms
   */
  public int getLocalMemorySize() {
    return this.m_vm.getLocalMemorySize();
  }

  /**
   * Obtain the maximum call depth of the hosted vms.
   * 
   * @return the maximum call depth of the hosted vms
   */
  public int getMaxCallDepth() {
    return this.m_vm.getMaxCallDepth();
  }

  /**
   * obtain the stack size of the hosted vms.
   * 
   * @return the stack size of the hosted vms
   */
  public int getStackSize() {
    return this.m_vm.getStackSize();
  }

  /**
   * Obtain the count of memory access errors encountered during program
   * execution.
   * 
   * @return the count of memory access errors encountered during program
   *         execution
   */
  public long getMemoryAccessErrors() {
    return this.m_vm.getMemoryAccessErrors();
  }

  /**
   * Obtain the count of errors that occured by accessing the stack.
   * 
   * @return the count of errors that occured by accessing the stack
   */
  public long getStackErrors() {
    return this.m_vm.getStackErrors();
  }

  /**
   * Get the count of errors that occured during procedures calls. An error
   * may either occure when calling an invalid procedure index or due to
   * exceeding the limit of allowed nested calls.
   * 
   * @return the count of errors that occured during procedures calls
   */
  public long getCallErrors() {
    return this.m_vm.getCallErrors();
  }

  /**
   * Obtain the count of steps performed.
   * 
   * @return the count of steps performed
   */
  public long getStepCount() {
    return this.m_vm.getStepCount();
  }

  /**
   * Obtain the count of steps spent in passive mode.
   * 
   * @return the count of steps spent in passive mode
   */
  public long getPassiveSteps() {
    return this.m_vm.getPassiveSteps();
  }

  /**
   * Obtain the count of interrupts that could not be performed because an
   * interrupt was already running.
   * 
   * @return the count of interrupts that could not be performed because an
   *         interrupt was already running
   */
  public long getMissedInterrupts() {
    return this.m_vm.getMissedInterrupts();
  }

  /**
   * Obtain the count of interrupts performed. Only those interrupts which
   * resulted in a successfull invokation of the interrupt handler are
   * counted.
   * 
   * @return the count of interrupts performed
   */
  public long getPerformedInterrupts() {
    return this.m_vm.getPerformedInterrupts();
  }

  /**
   * obtain the count of function of this program
   * 
   * @return the count of function of this program
   */
  public int getFunctionCount() {
    return this.m_vm.getFunctionCount();
  }

  /**
   * Check whether the vm(s) have no active procedure currently running.
   * 
   * @return <code>true</code> if no procedure/code is currently running
   *         and everything rests, <code>false</code> otherwise.
   */
  public boolean hasTerminated() {
    return this.m_vm.hasTerminated();
  }

  /**
   * Obtain the count of instructions of a certain function.
   * 
   * @param function
   *          the function index
   * @return the count of instructions of the certain function
   */
  public int getInstructionCount(final int function) {
    return this.m_vm.getInstructionCount(function);
  }

  /**
   * Obtain the total instruction count
   * 
   * @return the total instruction count
   */
  public int getInstructionCount() {
    return this.m_vm.getInstructionCount();
  }
}
