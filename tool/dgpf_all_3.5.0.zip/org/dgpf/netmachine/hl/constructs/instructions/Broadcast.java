/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 *
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-01
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.netmachine.hl.constructs.instructions.Broadcast.java
 * Last modification: 2007-03-01
 *                by: Thomas Weise
 *
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.netmachine.hl.constructs.instructions;

import org.dgpf.machine.hl.Construct;
import org.dgpf.machine.hl.Expression;
import org.dgpf.machine.hl.Instruction;
import org.dgpf.machine.hl.compiler.Compiler;
import org.dgpf.machine.hl.compiler.Resolver;
import org.dgpf.machine.ll.instructions.EIndirection;
import org.dgpf.machine.ll.programBuilder.Variable;
import org.dgpf.netmachine.ll.vm.DefaultNetInstructionSet;
import org.sigoa.refimpl.genomes.tree.INodeFactory;
import org.sigoa.refimpl.genomes.tree.Node;

/**
 * The send instruction
 * 
 * @author Thomas Weise
 */
public class Broadcast extends Instruction {
  /**
   * the serial version uid
   */
  private static final long serialVersionUID = 1L;

  /**
   * the operation text
   */
  static final char[] OP_TXT = "broadcast {type=".toCharArray(); //$NON-NLS-1$

  /**
   * the message type
   */
  int m_type;

  /**
   * Create a new send
   * 
   * @param parameters
   *          the function parameters
   * @param type
   *          the message type
   */
  public Broadcast(final Node[] parameters, final int type) {
    super(parameters);
    this.m_type = type;
  }

  /**
   * Serializes the parameters of the constructor of this object.
   * 
   * @param sb
   *          the string builder
   * @param indent
   *          an optional parameter denoting the indentation
   */
  @Override
  protected void javaParametersToStringBuilder(final StringBuilder sb,
      final int indent) {
    super.javaParametersToStringBuilder(sb, indent);
    sb.append(',');
    sb.append(' ');
    sb.append(this.m_type);
  }

  /**
   * Obtain the factory which deals with nodes of the same type as this
   * node.
   * 
   * @return the factory which deals with nodes of the same type as this
   *         node
   */
  @Override
  public INodeFactory getFactory() {
    return BroadcastFactory.BROADCAST_FACTORY;
  }

  /**
   * Transform this program into its human readable representation.
   * 
   * @param sb
   *          the string builder to write to
   * @param indent
   *          the indent
   */
  @Override
  protected void toStringBuilder(final StringBuilder sb, final int indent) {
    int i, s;

    sb.append(OP_TXT);
    sb.append(this.m_type);
    sb.append('}');

    s = this.size();
    if (s > 0) {
      sb.append(' ');
      sb.append('(');
      this.get(0).toStringBuilder(sb);
      for (i = 1; i < s; i++) {
        sb.append(',');
        sb.append(' ');
        this.get(i).toStringBuilder(sb);
      }
      sb.append(')');
    }
  }

  /**
   * Compile this construct.
   * 
   * @param compiler
   *          the compiler to use
   */
  @Override
  public void compile(final Compiler compiler) {
    int i, j;
    Construct cc;
    Variable x, r;

    j = this.size();
    compiler.beginConstruct();

    r = null;
    for (i = 0; i < j; i++) {
      cc = ((Construct) (this.get(i)));

      if (cc instanceof Expression) {
        x = ((Expression) cc).provideResultVariable(compiler);
      } else
        x = null;

      if (x == null) {
        if (r == null)
          r = compiler.allocateTarget();
        x = r;
      }

      cc.compile(compiler);
      if (x.getIndirection() != EIndirection.STACK)
        compiler.move(Variable.TOP_OF_STACK, x);
    }

    if (r != null)
      compiler.popTarget();

    compiler.endConstruct();
    compiler.addInstruction(DefaultNetInstructionSet.BROADCAST,
        Resolver.resolveFunction(this.m_type,
            compiler.getFunctionCount() - 1) + 1, 0, 0);
  }
}
