/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 *
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-01
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.netmachine.hl.constructs.instructions.Broadcast.java
 * Last modification: 2007-03-01
 *                by: Thomas Weise
 *
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.netmachine.hl.constructs.expressions;

import org.dgpf.machine.hl.Expression;
import org.dgpf.machine.hl.compiler.Compiler;
import org.dgpf.machine.ll.programBuilder.Variable;
import org.dgpf.netmachine.ll.vm.DefaultNetInstructionSet;
import org.sigoa.refimpl.genomes.tree.INodeFactory;

/**
 * The expression that returns the id
 * 
 * @author Thomas Weise
 */
public class ID extends Expression {
  /**
   * the serial version uid
   */
  private static final long serialVersionUID = 1L;

  /**
   * The globally shared instance of the id instruction
   */
  public static final ID ID = new ID();

  /**
   * the operation text
   */
  static final char[] OP_TXT = new char[] { 'i', 'd' };

  /**
   * the qualified name
   */
  static final char[] QN = (ID.class.getCanonicalName() + '.' + 'I' + 'D')
      .toCharArray();

  /**
   * Create id instruction
   */
  protected ID() {
    super(null);
  }

  /**
   * Serializes this object as string to a java string builder. The string
   * appended to the string builder can be copy-and-pasted into a java file
   * and represents the constructor of this object.
   * 
   * @param sb
   *          the string builder
   * @param indent
   *          an optional parameter denoting the indentation
   */
  @Override
  public void javaToStringBuilder(final StringBuilder sb, final int indent) {
    sb.append(QN);
  }

  /**
   * Obtain the factory which deals with nodes of the same type as this
   * node.
   * 
   * @return the factory which deals with nodes of the same type as this
   *         node
   */
  @Override
  public INodeFactory getFactory() {
    return IDFactory.ID_FACTORY;
  }

  /**
   * Transform this program into its human readable representation.
   * 
   * @param sb
   *          the string builder to write to
   * @param indent
   *          the indent
   */
  @Override
  protected void toStringBuilder(final StringBuilder sb, final int indent) {
    sb.append(OP_TXT);
  }

  /**
   * Compile this construct.
   * 
   * @param compiler
   *          the compiler to use
   */
  @Override
  public void compile(final Compiler compiler) {
    Variable v;

    v = this.provideResultVariable(compiler);
    if (v == null)
      v = compiler.getTarget();

    compiler.addInstruction(DefaultNetInstructionSet.ID, v.encode(), 0, 0);
  }

  /**
   * read resolve
   * 
   * @return the read resolution
   */
  private final Object readResolve() {
    return ID;
  }

  /**
   * write replace
   * 
   * @return the write replacement
   */
  private final Object writeReplace() {
    return ID;
  }
}
