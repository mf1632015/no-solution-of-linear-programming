/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-23
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.netmachine.gp.simulation.INetworkSimulation.java
 * Last modification: 2007-03-23
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.netmachine.gp.simulation;

import org.dgpf.machine.ll.vm.IVMState;
import org.dgpf.netmachine.ll.vm.INetVMParameters;
import org.dgpf.netmachine.ll.vm.INetwork;
import org.dgpf.netmachine.ll.vm.NetVM;

/**
 * This interface is common to all network simulations.
 * 
 * @author Thomas Weise
 */
public interface INetworkSimulation extends INetwork, IVMState,
    INetVMParameters {

  /**
   * Obtain the count of messages sent.
   * 
   * @return the count of messages sent
   */
  public abstract int getSentMessages();

  /**
   * Obtain the count of lost messages.
   * 
   * @return the count of lost messages
   */
  public abstract int getLostMessages();

  /**
   * This method should be called when an individual has ended. It is used
   * to reset internal random number generators so the next individual will
   * encounter the exact same circumstances as this one.
   */
  public abstract void endIndividual();

  /**
   * Obtain the vm at the specified position in the network.
   * 
   * @param index
   *          the index of the vm
   * @return the network-enabled virtual machine at position
   *         <code>index</code>
   */
  public abstract NetVM getVM(final int index);
}
