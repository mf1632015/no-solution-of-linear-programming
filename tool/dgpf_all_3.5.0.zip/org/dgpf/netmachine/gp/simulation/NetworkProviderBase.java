/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-22
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.netmachine.gp.simulation.NetworkProviderBase.java
 * Last modification: 2007-03-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.netmachine.gp.simulation;

import org.dgpf.machine.ll.vm.Program;
import org.dgpf.netmachine.ll.vm.INetVMFactory;
import org.dgpf.netmachine.ll.vm.INetVMParameters;
import org.dgpf.netmachine.ll.vm.NetVM;
import org.sigoa.refimpl.simulation.SimulationProvider;
import org.sigoa.spec.simulation.ISimulation;

/**
 * The basic network provider.
 * 
 * @author Thomas Weise
 */
public abstract class NetworkProviderBase extends SimulationProvider {
  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * the network-enabled virtual machine parameters
   */
  private final INetVMParameters m_params;

  /**
   * the vm factory
   */
  private final INetVMFactory<?> m_factory;

  /**
   * Instantiate the basic network simulation provider.
   * 
   * @param parameters
   *          the virtual machine parameters that go for the simulations.
   * @param factory
   *          the VM factory or <code>null</code> for a reasonable
   *          default
   * @param clazz
   *          the class of the simple network, or <code>null</code> for a
   *          reasonable default
   */
  public NetworkProviderBase(final INetVMParameters parameters,
      final INetVMFactory<?> factory,
      final Class<? extends ISimulation<Program<NetVM>>> clazz) {
    super(clazz);
    this.m_params = parameters;
    this.m_factory = factory;
  }

  /**
   * Instantiate the simple network simulation.
   * 
   * @param params
   *          the virtual machine parameters that go for the simulations.
   * @param factory
   *          the VM factory or <code>null</code> for a reasonable
   *          default
   * @return the new simulation
   */
  protected abstract ISimulation<?> createNetwork(
      final INetVMParameters params, final INetVMFactory<?> factory);

  /**
   * Create a new instance of this simulator.
   * 
   * @return The newly created simulator instance.
   */
  @Override
  public ISimulation<?> createSimulation() {
    return this.createNetwork(this.m_params, this.m_factory);
  }
}
