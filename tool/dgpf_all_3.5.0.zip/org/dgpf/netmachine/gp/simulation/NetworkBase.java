/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-22
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.netmachine.network.gp.simulation.NetworkBase.java
 * Last modification: 2007-03-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.netmachine.gp.simulation;

import org.dgpf.machine.ll.vm.Program;
import org.dgpf.machine.ll.vm.VM;
import org.dgpf.machine.ll.vm.VMHost;
import org.dgpf.netmachine.ll.vm.INetVMFactory;
import org.dgpf.netmachine.ll.vm.INetVMParameters;
import org.dgpf.netmachine.ll.vm.NetVM;
import org.sfc.math.Mathematics;
import org.sigoa.refimpl.simulation.Simulation;
import org.sigoa.spec.stoch.IRandomizer;

/**
 * The simple network implementation
 * 
 * @author Thomas Weise
 */
public abstract class NetworkBase extends Simulation<Program<NetVM>>
    implements INetworkSimulation {
  /**
   * the serial version uid
   */
  private static final long serialVersionUID = 0;

  /**
   * the minimum id
   */
  private static final int MIN_ID = Mathematics.nextPrime((1 << 16) - 1);

  /**
   * the maximum id
   */
  private static final int MAX_ID = Mathematics
      .nextPrime(Integer.MAX_VALUE >>> 3);

  /**
   * the id span
   */
  private static final int ID_SPAN = (MAX_ID - MIN_ID + 1);

  /**
   * The network vms.
   */
  protected final NetVM[] m_vms;

  /**
   * the virtual machine host of this simulation.
   */
  private final VMHost m_host;

  /**
   * Create a new simple network
   * 
   * @param parameters
   *          the networked vm parameters
   * @param vmFactory
   *          the VM factory or <code>null</code> for a reasonable
   *          default
   */
  public NetworkBase(final INetVMParameters parameters,
      final INetVMFactory<? extends NetVM> vmFactory) {
    super();

    INetVMFactory<? extends NetVM> f;
    NetVM[] v;
    int c, i;

    this.m_host = new VMHost(parameters);
    c = parameters.getVMCount();
    this.m_vms = v = new NetVM[c];
    f = ((vmFactory != null) ? vmFactory : NetVM.NET_VM_FACTORY);

    for (i = (c - 1); i >= 0; i--) {
      v[i] = f.createVM(this.m_host, this);
    }
  }

  /**
   * This method is called right before the simulation begins.
   * 
   * @param what
   *          The item to be simulated.
   * @throws NullPointerException
   *           if <code>what</code> is <code>null</code>.
   */
  @Override
  @SuppressWarnings("unchecked")
  public void beginSimulation(final Program<NetVM> what) {
    final NetVM[] vs;
    int cmi, i, x, y;
    final IRandomizer r;

    super.beginSimulation(what);

    vs = this.m_vms;
    cmi = (vs.length - 1);

    // initialize the virtual machines
    for (i = cmi; i >= 0; i--) {
      vs[i].init(((Program<? super VM>) what));
    }

    r = this.getRandomizer();
    // the id generating loop
    for (i = cmi; i >= 0; i--) {
      inner: for (;;) {

        do {
          y = Mathematics.nextPrime(MIN_ID + r.nextInt(ID_SPAN));
        } while (y > MAX_ID);

        for (x = cmi; x > i; x--) {
          if (vs[x].getID() == y)
            continue inner;
        }
        vs[i].setID(y);
        break inner;
      }
    }
  }

  /************************************************************************
   * Status methods *******************************************************
   ***********************************************************************/

  /**
   * Obtain the count of memory access errors encountered during program
   * execution.
   * 
   * @return the count of memory access errors encountered during program
   *         execution
   */
  public long getMemoryAccessErrors() {
    long s;
    int i;
    NetVM[] n;

    n = this.m_vms;
    s = 0;
    for (i = (n.length - 1); i >= 0; i--) {
      s += n[i].getMemoryAccessErrors();
    }
    return s;
  }

  /**
   * Obtain the count of errors that occured by accessing the stack.
   * 
   * @return the count of errors that occured by accessing the stack
   */
  public long getStackErrors() {
    long s;
    int i;
    NetVM[] n;

    n = this.m_vms;
    s = 0;
    for (i = (n.length - 1); i >= 0; i--) {
      s += n[i].getStackErrors();
    }
    return s;
  }

  /**
   * Get the count of errors that occured during procedures calls. An error
   * may either occure when calling an invalid procedure index or due to
   * exceeding the limit of allowed nested calls.
   * 
   * @return the count of errors that occured during procedures calls
   */
  public long getCallErrors() {
    long s;
    int i;
    NetVM[] n;

    n = this.m_vms;
    s = 0;
    for (i = (n.length - 1); i >= 0; i--) {
      s += n[i].getCallErrors();
    }
    return s;
  }

  /**
   * Obtain the count of steps performed.
   * 
   * @return the count of steps performed
   */
  public long getStepCount() {
    long s;
    int i;
    NetVM[] n;

    n = this.m_vms;
    s = 0;
    for (i = (n.length - 1); i >= 0; i--) {
      s += n[i].getStepCount();
    }
    return s;
  }

  /**
   * Obtain the count of steps spent in passive mode.
   * 
   * @return the count of steps spent in passive mode
   */
  public long getPassiveSteps() {
    long s;
    int i;
    NetVM[] n;

    n = this.m_vms;
    s = 0;
    for (i = (n.length - 1); i >= 0; i--) {
      s += n[i].getPassiveSteps();
    }
    return s;
  }

  /**
   * Obtain the count of interrupts that could not be performed because an
   * interrupt was already running.
   * 
   * @return the count of interrupts that could not be performed because an
   *         interrupt was already running
   */
  public long getMissedInterrupts() {
    long s;
    int i;
    NetVM[] n;

    n = this.m_vms;
    s = 0;
    for (i = (n.length - 1); i >= 0; i--) {
      s += n[i].getMissedInterrupts();
    }
    return s;
  }

  /**
   * Obtain the count of interrupts performed. Only those interrupts which
   * resulted in a successfull invokation of the interrupt handler are
   * counted.
   * 
   * @return the count of interrupts performed
   */
  public long getPerformedInterrupts() {
    long s;
    int i;
    NetVM[] n;

    n = this.m_vms;
    s = 0;
    for (i = (n.length - 1); i >= 0; i--) {
      s += n[i].getPerformedInterrupts();
    }
    return s;
  }

  /**
   * obtain the count of functions of this program
   * 
   * @return the count of functions of this program
   */
  public int getFunctionCount() {
    return this.getSimulated().getFunctionCount();
  }

  /**
   * Obtain the count of instructions of a certain function.
   * 
   * @param function
   *          the function index
   * @return the count of instructions of the certain function
   */
  public int getInstructionCount(final int function) {
    return this.getSimulated().getInstructionCount(function);
  }

  /**
   * Obtain the total instruction count
   * 
   * @return the total instruction count
   */
  public int getInstructionCount() {
    return this.getSimulated().getInstructionCount();
  }

  /**
   * obtain the global memory size of the hosted vms.
   * 
   * @return the global memory size of the hosted vms
   */
  public int getGlobalMemorySize() {
    return this.m_host.getGlobalMemorySize();
  }

  /**
   * obtain the local memory size of the hosted vms.
   * 
   * @return the local memory size of the hosted vms
   */
  public int getLocalMemorySize() {
    return this.m_host.getLocalMemorySize();
  }

  /**
   * Obtain the maximum call depth of the hosted vms.
   * 
   * @return the maximum call depth of the hosted vms
   */
  public int getMaxCallDepth() {
    return this.m_host.getMaxCallDepth();
  }

  /**
   * Obtain the stack size.
   * 
   * @return the stack size
   */
  public int getStackSize() {
    return this.m_host.getStackSize();
  }

  /**
   * Obtain the count of virtual machines in the network.
   * 
   * @return the count of virtual machines in the network
   */
  public int getVMCount() {
    return this.m_vms.length;
  }

  /**
   * Obtain the vm at the specified position in the network.
   * 
   * @param index
   *          the index of the vm
   * @return the network-enabled virtual machine at position
   *         <code>index</code>
   */
  public NetVM getVM(final int index) {
    return this.m_vms[index];
  }

  /**
   * this method is called whenever a vm performs a step
   */
  protected void onStep() {//

  }
}
