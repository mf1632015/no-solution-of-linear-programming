/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-22
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.netmachine.gp.simulation.simple.SimpleMessage.java
 * Last modification: 2007-03-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.netmachine.gp.simulation.simple;

import java.io.Serializable;

import org.dgpf.machine.ll.vm.MemoryRecord;
import org.dgpf.machine.ll.vm.VM;
import org.dgpf.netmachine.ll.vm.NetVM;

/**
 * the internal message class
 * 
 * @author Thomas Weise
 */
final class SimpleMessage extends MemoryRecord implements Serializable {
  /**
   * the serial version uid
   */
  private static final long serialVersionUID = 0;

  /**
   * the next simple message
   */
  SimpleMessage m_next;

/**
 * the source
 */
  NetVM m_src;
/**
 * the message type
 */
  int m_type;
/**
 * the delivery delay
 */
  int m_delay;
  
  /**
   * Create a new memory record.
   * 
   * @param memSize
   *          the mem size
   */
  SimpleMessage(final int memSize) {
    super(memSize);
  }
  
  
  /**
   * Clear the stack of the given vm
   * 
   * @param vm
   *          the vm to clear the stack of
   */
  static final void doClearStack(final VM vm) {
    clearStack(vm);
  }
}
