/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-22
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.netmachine.network.gp.simulation.simple.SimpleNetwork.java
 * Last modification: 2007-03-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.netmachine.gp.simulation.simple;

import java.util.Arrays;
import java.util.Comparator;

import org.dgpf.machine.ll.vm.Program;
import org.dgpf.netmachine.gp.simulation.INetworkSimulation;
import org.dgpf.netmachine.gp.simulation.NetworkBase;
import org.dgpf.netmachine.ll.vm.INetVMFactory;
import org.dgpf.netmachine.ll.vm.INetVMParameters;
import org.dgpf.netmachine.ll.vm.NetVM;
import org.sfc.math.Mathematics;
import org.sigoa.refimpl.stoch.Randomizer;
import org.sigoa.spec.stoch.IRandomizer;

/**
 * The simple network implementation
 * 
 * @author Thomas Weise
 */
public class SimpleNetwork extends NetworkBase implements
    INetworkSimulation {
  /**
   * the serial version uid
   */
  private static final long serialVersionUID = 0;

  /**
   * the comparator
   */
  private static final Comparator<NetVM> CMP = new Comparator<NetVM>() {
    public int compare(final NetVM o1, final NetVM o2) {
      return (System.identityHashCode(o1) - System.identityHashCode(o2));
    }
  };

  /**
   * The randomizer used for topology and id creation
   */
  private final IRandomizer m_random;

  /**
   * the grid
   */
  private final NetVM[][] m_grid;

  /**
   * the message cache
   */
  private transient SimpleMessage m_cache;

  /**
   * the pending messages
   */
  private SimpleMessage m_pending;

  /**
   * the count of sent messages
   */
  private int m_sent;

  /**
   * the count of lost messages
   */
  private int m_lost;

  /**
   * The lose values
   */
  private boolean[] m_lose;

  /**
   * the lose index
   */
  private int m_loseIdx;

  /**
   * the deterministic delays
   */
  private final int[] m_delays;

  /**
   * the deterministic delay index
   */
  private int m_delayIdx;

  /**
   * active
   */
  private final boolean[] m_active;

  /**
   * the count of active nodes.
   */
  private int m_activeCnt;

  /**
   * the sequence
   */
  private final int[] m_sequence;

  /**
   * the sequence index
   */
  private int m_sequenceIdx;

  /**
   * the pending count
   */
  private int m_pc;

  /**
   * the maximum pending count
   */
  private int m_maxPC;

  // /**
  // * the modulus
  // */
  // private int m_mod;

  /**
   * Create a new simple network
   * 
   * @param parameters
   *          the networked vm parameters
   * @param vmFactory
   *          the VM factory or <code>null</code> for a reasonable
   *          default
   */
  public SimpleNetwork(final INetVMParameters parameters,
      final INetVMFactory<? extends NetVM> vmFactory) {
    super(parameters, vmFactory);

    int c, x;

    c = this.m_vms.length;
    Arrays.sort(this.m_vms, CMP);

    this.m_maxPC = (c * c);

    this.m_random = new Randomizer();
    this.m_random.setDefaultSeed();

    this.m_active = new boolean[c];
    x = Mathematics.nextPrime((c * c) << 1);
    this.m_lose = new boolean[x];
    x = Mathematics.nextPrime(x + 2 + (x & 0x1ff));
    this.m_delays = new int[x];
    x = Mathematics.nextPrime(x + 2 + (x & 0x1ff));
    this.m_sequence = new int[x];

    this.m_grid = new NetVM[c][c];
  }

  /**
   * This method is called right before the simulation begins.
   * 
   * @param what
   *          The item to be simulated.
   * @throws NullPointerException
   *           if <code>what</code> is <code>null</code>.
   */
  @Override
  @SuppressWarnings("unchecked")
  public void beginSimulation(final Program<NetVM> what) {
    final NetVM[][] grid;
    final NetVM[] vs;
    int cnt, cmi, i, x, y;
    final IRandomizer r;
    boolean b;
    NetVM v, w;
    final boolean[] l;
    int[] del;

    super.beginSimulation(what);

    // this.m_mod = Math.max(1, what.getFunctionCount() - 1);

    grid = this.m_grid;
    vs = this.m_vms;
    cnt = vs.length;
    cmi = cnt - 1;
    r = this.m_random;
    this.m_pc = 0;

    for (i = cmi; i >= 0; i--) {
      Arrays.fill(grid[i], null);
    }

    // the network builder
    grid[r.nextInt(cnt)][r.nextInt(cnt)] = vs[0];
    for (i = cmi; i > 0; i--) {
      v = vs[i];
      b = false;
      for (;;) {
        x = r.nextInt(cnt);
        y = r.nextInt(cnt);
        if (grid[x][y] != null)
          continue;
        if ((x > 0) && ((w = grid[x - 1][y]) != null)) {
          b = true;
          v.addNeighbor(w);
          w.addNeighbor(v);
        }

        if ((x < cmi) && ((w = grid[x + 1][y]) != null)) {
          b = true;
          v.addNeighbor(w);
          w.addNeighbor(v);
        }

        if ((y < cmi) && ((w = grid[x][y + 1]) != null)) {
          b = true;
          v.addNeighbor(w);
          w.addNeighbor(v);
        }

        if ((y > 0) && ((w = grid[x][y - 1]) != null)) {
          b = true;
          v.addNeighbor(w);
          w.addNeighbor(v);
        }

        if (b) {
          grid[x][y] = v;
          v.setCoordinates(x, y, 1);
          break;
        }
      }
    }

    // Arrays.sort(vs, CMP);

    // init the lose values
    x = ((int) (30.0d * Math.sqrt(r.nextDouble())));
    l = this.m_lose;
    if (x <= 1)
      Arrays.fill(l, false);
    else {
      for (i = (l.length - 1); i >= 0; i--) {
        l[i] = (r.nextInt(x) <= 0);
      }
      this.m_loseIdx = 0;
    }

    // init the delays
    del = this.m_delays;
    for (i = (del.length - 1); i >= 0; i--) {
      del[i] = r.nextInt(12);
    }
    this.m_delayIdx = 0;

    // set up the active count
    Arrays.fill(this.m_active, true);
    this.m_activeCnt = cnt;

    // setup the sequence
    del = this.m_sequence;
    for (i = (del.length - 1); i >= 0; i--) {
      del[i] = r.nextInt(cnt);
    }
    this.m_sequenceIdx = 0;
  }

  /**
   * This method is called when the simulation has ended.
   * 
   * @throws IllegalStateException
   *           If this simulation is not yet running.
   */
  @Override
  public void endSimulation() {
    SimpleMessage m, n;

    for (m = this.m_pending; m != null; m = n) {
      n = m.m_next;
      this.disposeMessage(m);
    }
    this.m_pending = null;
    this.m_sent = 0;
    this.m_lost = 0;

    super.endSimulation();
  }

  /**
   * This method should be called when an individual has ended. It is used
   * to reset internal random number generators so the next individual will
   * encounter the exact same circumstances as this one.
   */
  public void endIndividual() {
    this.m_random.setDefaultSeed();
  }

  /**
   * Broadcast a message
   * 
   * @param vm
   *          the sending vm
   * @param type
   *          the message type
   */
  public void broadcast(final NetVM vm, final int type) {
    SimpleMessage a, b, na;
    int del, s;
    boolean z;

    this.m_sent++;

    if (this.m_pc >= this.m_maxPC)
      z = true;
    else {
      del = this.m_loseIdx;
      z = this.m_lose[del++];
      if (del >= this.m_lose.length)
        this.m_loseIdx = 0;
      else
        this.m_loseIdx = del;
    }

    if (z) {
      // this message is lost
      this.m_lost++;
      SimpleMessage.doClearStack(vm);
    } else {
      // obtain this message's delay
      this.m_pc++;
      del = (this.m_delayIdx + 1);
      if (del >= this.m_delays.length)
        del = 0;
      this.m_delayIdx = del;

      // initialize this message
      na = this.allocateMessage();
      na.takeStack(vm);
      na.m_src = vm;
      na.m_type = type;// (Mathematics.modulo(type - 1, this.m_mod) + 1);

      del = this.m_delays[del];
      b = null;
      for (a = this.m_pending; a != null; a = a.m_next) {
        s = a.m_delay;
        if (s > del) {
          a.m_delay = (s - del);
          if (b == null)
            this.m_pending = na;
          else {
            na.m_next = b.m_next;
            b.m_next = na;
          }
          na.m_next = a;
          na.m_delay = del;
          return;
        }
        del -= s;
        b = a;
      }

      if (b == null)
        this.m_pending = na;
      else
        b.m_next = na;
      na.m_delay = del;
    }
  }

  /**
   * <p>
   * Perform <code>steps</code> simulation steps. A simulation step of a
   * network equals somehow a logical time step. Some virtual machines in
   * the net may perform no, one, or multiple ticks. Messages may be
   * received and sent.
   * </p>
   * <p>
   * This method returns <code>true</code> as long as either some vms are
   * in the active mode or messages are still pending to be delivered. If
   * <code>false</code> is returned, no vm is active any more and no
   * message is pending - thus, the simulation has come to rest and nothing
   * can change anymore.
   * </p>
   * 
   * @param steps
   *          The count of simulation steps to be performed.
   * @return <code>true</code> if and only if further simulating would
   *         possible change the state of the simulation,
   *         <code>false</code> otherwise
   * @throws IllegalStateException
   *           If this simulation is not yet running.
   * @throws IllegalArgumentException
   *           if <code>steps <= 0</code>.
   */
  @Override
  public boolean simulate(final long steps) {
    NetVM[] vs;
    int i, j, l, z, ac;
    boolean[] b;
    int[] seq;
    int seqI;

    vs = this.m_vms;
    l = vs.length;
    b = this.m_active;
    seq = this.m_sequence;
    seqI = this.m_sequenceIdx;
    for (i = (int) steps; i > 0; i--) {

      this.deliver();

      if ((ac = this.m_activeCnt) > 0) {
        inner: for (j = l; j > 0; j--) {

          z = seq[seqI++];
          if (seqI >= seq.length)
            seqI = 0;

          if (b[z]) {
            if (!(vs[z].step())) {
              b[z] = false;
              if ((--ac) <= 0) {
                if (this.m_pending == null) {
                  this.m_activeCnt = 0;
                  return false;
                }
                break inner;
              }
            }
            this.onStep();
          }
        }

        this.m_activeCnt = ac;
      }
    }

    this.m_sequenceIdx = seqI;
    return true;
  }

  /**
   * find a certain network vm in an array
   * 
   * @param v
   *          the array of network vms
   * @param n
   *          the vm to find
   * @return its index
   */
  private static final int index(final NetVM[] v, final NetVM n) {
    int i;
    i = Arrays.binarySearch(v, n, CMP);
    if (v[i] == n)
      return i;
    for (i = (v.length - 1); i > 0; i--) {
      if (v[i] == n)
        return i;
    }
    return 0;
  }

  /**
   * Deliver pending messages
   */
  private final void deliver() {
    SimpleMessage a, newPend;
    int t, i, idx;
    NetVM src, n;
    NetVM[] vms;
    boolean[] ac;

    a = this.m_pending;
    if ((a != null) && ((--a.m_delay) <= 0)) {
      vms = this.m_vms;
      ac = this.m_active;
      do {
        t = a.m_type;
        newPend = a.m_next;
        src = a.m_src;
        for (i = (src.getNeighborCount() - 1); i >= 0; i--) {
          n = src.getNeighbor(i);
          a.interrupt(n, t);
          idx = index(vms, n);
          if (!ac[idx]) {
            ac[idx] = true;
            this.m_activeCnt++;
          }
        }
        this.disposeMessage(a);
        this.m_pc--;
        a = newPend;
      } while ((a != null) && (a.m_delay <= 0));

      this.m_pending = newPend;
    }
  }

  /**
   * allocate a new simple message
   * 
   * @return the new simple message
   */
  private final SimpleMessage allocateMessage() {
    SimpleMessage m;

    m = this.m_cache;
    if (m != null) {
      this.m_cache = m.m_next;
      m.m_next = null;
      return m;
    }

    return new SimpleMessage(this.m_vms[0].getStackSize());
  }

  /**
   * dispose a message record
   * 
   * @param msg
   *          the message record to be disposed
   */
  private final void disposeMessage(final SimpleMessage msg) {
    msg.m_next = this.m_cache;
    this.m_cache = msg;
  }

  /************************************************************************
   * Status methods *******************************************************
   ***********************************************************************/

  /**
   * Check whether the vm(s) have no active procedure currently running.
   * 
   * @return <code>true</code> if no procedure/code is currently running
   *         and everything rests, <code>false</code> otherwise.
   */
  public boolean hasTerminated() {
    return ((this.m_activeCnt <= 0) && (this.m_pending == null));
  }

  /**
   * Obtain the count of messages sent.
   * 
   * @return the count of messages sent
   */
  public int getSentMessages() {
    return this.m_sent;
  }

  /**
   * Obtain the count of lost messages.
   * 
   * @return the count of lost messages
   */
  public int getLostMessages() {
    return this.m_lost;
  }
}
