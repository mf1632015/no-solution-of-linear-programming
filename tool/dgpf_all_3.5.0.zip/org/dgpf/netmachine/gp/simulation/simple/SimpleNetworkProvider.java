/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-22
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.netmachine.gp.simulation.simple.SimpleNetworkProvider.java
 * Last modification: 2007-03-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.netmachine.gp.simulation.simple;

import org.dgpf.netmachine.gp.simulation.NetworkProviderBase;
import org.dgpf.netmachine.ll.vm.INetVMFactory;
import org.dgpf.netmachine.ll.vm.INetVMParameters;
import org.sigoa.spec.simulation.ISimulation;

/**
 * The simple network provider.
 * 
 * @author Thomas Weise
 */
public class SimpleNetworkProvider extends NetworkProviderBase {
  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * Instantiate the simple network simulation provider.
   * 
   * @param parameters
   *          the virtual machine parameters that go for the simulations.
   */
  public SimpleNetworkProvider(final INetVMParameters parameters) {
    this(parameters, null);
  }

  /**
   * Instantiate the simple network simulation provider.
   * 
   * @param parameters
   *          the virtual machine parameters that go for the simulations.
   * @param factory
   *          the VM factory or <code>null</code> for a reasonable
   *          default
   */
  public SimpleNetworkProvider(final INetVMParameters parameters,
      final INetVMFactory<?> factory) {
    this(parameters, factory, null);
  }

  /**
   * Instantiate the simple network simulation provider.
   * 
   * @param parameters
   *          the virtual machine parameters that go for the simulations.
   * @param factory
   *          the VM factory or <code>null</code> for a reasonable
   *          default
   * @param clazz
   *          the class of the simple network, or <code>null</code> for a
   *          reasonable default
   */
  public SimpleNetworkProvider(final INetVMParameters parameters,
      final INetVMFactory<?> factory,
      final Class<? extends SimpleNetwork> clazz) {
    super(parameters, factory, (clazz != null) ? clazz
        : SimpleNetwork.class);
  }

  /**
   * Instantiate the simple network simulation.
   * 
   * @param params
   *          the virtual machine parameters that go for the simulations.
   * @param factory
   *          the VM factory or <code>null</code> for a reasonable
   *          default
   * @return the new simulation
   */
  @Override
  protected ISimulation<?> createNetwork(final INetVMParameters params,
      final INetVMFactory<?> factory) {
    return new SimpleNetwork(params, factory);
  }

}
