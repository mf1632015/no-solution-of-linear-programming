/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-22
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.netmachine.ll.vm.NetVM.java
 * Last modification: 2007-03-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.netmachine.ll.vm;

import org.dgpf.machine.ll.vm.VM;
import org.dgpf.machine.ll.vm.VMHost;
import org.sfc.math.Mathematics;

/**
 * The networked virtual machine
 * 
 * @author Thomas Weise
 */
public class NetVM extends VM {
  /**
   * the serial version uid
   */
  private static final long serialVersionUID = 1;

  /**
   * The globally shared network vm factory.
   */
  public static final INetVMFactory<NetVM> NET_VM_FACTORY = new INetVMFactory<NetVM>() {
    private static final long serialVersionUID = 0;

    public NetVM createVM(final VMHost h, final INetwork network) {
      return new NetVM(h, network);
    }

    private final Object readResolve() {
      return NET_VM_FACTORY;
    }

    private final Object writeReplace() {
      return NET_VM_FACTORY;
    }
  };

  /**
   * the underlying network.
   */
  private final INetwork m_network;

  /**
   * the id of this vm
   */
  private int m_id;

  /**
   * the neighbor count
   */
  private int m_neighborCnt;

  /**
   * the neighbors
   */
  private NetVM[] m_neighbors;

  /**
   * the x-coordinate this vm resides at
   */
  private int m_x;

  /**
   * the y-coordinate this vm resides at
   */
  private int m_y;

  /**
   * the z-coordinate this vm resides at
   */
  private int m_z;

  /**
   * Create a new network-enabled virtual machine
   * 
   * @param host
   *          the vm host
   * @param network
   *          the network this network-enabled vm should be part of
   */
  public NetVM(final VMHost host, final INetwork network) {
    super(host);
    this.m_neighbors = new NetVM[8];
    this.m_network = network;
  }

  /**
   * Obtain access to the network this vm is part of.
   * 
   * @return the network this vm is part of
   */
  public INetwork getNetwork() {
    return this.m_network;
  }

  /**
   * Set the id of this vm
   * 
   * @param id
   *          the id of this vm
   */
  public void setID(final int id) {
    this.m_id = id;
  }

  /**
   * Obtain the id of this vm
   * 
   * @return the id of this vm
   */
  public int getID() {
    return this.m_id;
  }

  /**
   * Obtain the neighbor count.
   * 
   * @return the neighbor count
   */
  public int getNeighborCount() {
    return this.m_neighborCnt;
  }

  /**
   * Obtain the <code>index</code>th neighbor
   * 
   * @param index
   *          the index of the wanted neighbor
   * @return the neighbor at that index
   */
  public NetVM getNeighbor(final int index) {
    return this.m_neighbors[Mathematics.modulo(index, this.m_neighborCnt)];
  }

  /**
   * Add a neighbor to this vm.
   * 
   * @param vm
   *          the new neighbor vm
   */
  public void addNeighbor(final NetVM vm) {
    NetVM[] v;
    int c;

    c = this.m_neighborCnt;
    v = this.m_neighbors;
    if (c >= v.length) {
      v = new NetVM[c << 1];
      System.arraycopy(this.m_neighbors, 0, v, 0, c);
      this.m_neighbors = v;
    }
    v[c] = vm;
    this.m_neighborCnt = (c + 1);
  }

  /**
   * reset the virtual machine<br/> all internal structures (except the
   * program) are cleared
   */
  @Override
  public void reset() {
    this.m_id = 0;
    this.m_neighborCnt = 0;
    this.m_x = 0;
    this.m_y = 0;
    this.m_z = 0;
    super.reset();
  }

  /**
   * Set the coordinates for this vm.
   * 
   * @param x
   *          the new x coordinate
   * @param y
   *          the new y coordinate
   * @param z
   *          the new z coordinate
   */
  public void setCoordinates(final int x, final int y, final int z) {
    this.m_x = x;
    this.m_y = y;
    this.m_z = z;
  }

  /**
   * Obtain the x-coordinate of this vm.
   * 
   * @return the x-coordinate of this vm
   */
  public int getX() {
    return this.m_x;
  }

  /**
   * Obtain the y-coordinate of this vm.
   * 
   * @return the y-coordinate of this vm
   */
  public int getY() {
    return this.m_y;
  }

  /**
   * Obtain the z-coordinate of this vm.
   * 
   * @return the z-coordinate of this vm
   */
  public int getZ() {
    return this.m_z;
  }

  /**
   * Broadcast a message of the <code>type</code>.
   * 
   * @param type
   *          the message type
   */
  public void broadcast(final int type) {
    this.m_network.broadcast(this, type);
  }
}
