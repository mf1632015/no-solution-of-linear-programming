/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-22
 * Creator          : Thomas Weise
 * Original Filename: org.dgpf.netmachine.ll.DefaultNetInstructionSet.java
 * Last modification: 2007-03-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.dgpf.netmachine.ll.vm;

import org.dgpf.machine.ll.vm.DefaultInstructionSet;
import org.dgpf.machine.ll.vm.Instruction;
import org.dgpf.machine.ll.vm.InstructionSet;
import org.dgpf.machine.ll.vm.InstructionSetBuilder;
import org.dgpf.netmachine.ll.vm.instructions.ID;
import org.dgpf.netmachine.ll.vm.instructions.Broadcast;

/**
 * The default networking instruction set
 * 
 * @author Thomas Weise
 */
public final class DefaultNetInstructionSet {

  /**
   * the default networking instruction set
   */
  public static final InstructionSet<NetVM> INSTRUCTION_SET;

  /**
   * The default send instruction
   */
  public static final Instruction<NetVM> BROADCAST;
  /**
   * The default id instruction
   */
  public static final Instruction<NetVM> ID;

  static {

    InstructionSetBuilder<NetVM> b = new InstructionSetBuilder<NetVM>(
        DefaultInstructionSet.INSTRUCTION_SET) {
      @Override
      protected InstructionSet<NetVM> createInstructionSet(
          final Instruction<? super NetVM>[] instructions) {
        return new InstructionSet<NetVM>(instructions) {
          private static final long serialVersionUID = 1;

          private final Object readResolve() {
            return INSTRUCTION_SET;
          }

          private final Object writeReplace() {
            return INSTRUCTION_SET;
          }
        };
      }
    };

    BROADCAST = new Broadcast(b);
    ID = new ID(b);

    INSTRUCTION_SET = b.build();
  }

}
