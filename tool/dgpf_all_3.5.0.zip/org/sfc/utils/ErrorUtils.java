/*
 * Copyright (c) 2006 Thomas Weise
 * Software Foundation Classes
 * http://sourceforge.net/projects/java-sfc
 * 
 * E-Mail           : tweise@gmx.de
 * Creation Date    : 2006-11-22
 * Creator          : Thomas Weise
 * Original Filename: org.sfc.utils.ErrorUtils.java
 * Last modification: 2006-11-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sfc.utils;

/**
 * This class provides some utilties for errors.
 * 
 * @author Thomas Weise
 */
public final class ErrorUtils {

  // /**
  // * check whether the error management was initialized or not
  // */
  // static volatile boolean s_needInit = true;

  /**
   * This method should be called inside methods that must never be
   * invoked, such as private constructors of method collection objects.
   */
  public static final void doNotCall() {
    showError(new Throwable("I told you not to call this method!!!"));//$NON-NLS-1$  
    tunnelError("This method must not be called.");//$NON-NLS-1$    
  }

  /**
   * Convert an error to one that does not need a <code>throws</code>-
   * or <code>exceptions</code>-statement.
   * 
   * @param t
   *          The error to convert.
   */
  public static final void tunnelError(final Throwable t) {
    throw new TunnelledException(t);
  }

  /**
   * Throw an error that does not need a <code>throws</code>- or
   * <code>exceptions</code>-statement.
   * 
   * @param cause
   *          A string describing the error's cause.
   */
  public static final void tunnelError(final String cause) {
    throw new TunnelledException(cause);
  }

  // /**
  // * Initialize the error management.
  // */
  // public static final void initErrorManagement() {
  // if (s_needInit) {
  // synchronized (ErrorUtils.class) {
  // if (s_needInit) {
  //          
  // s_needInit = false;
  // }
  // }
  // }
  // }

  /**
   * Check two errors for equality.
   * 
   * @param t1
   *          The first error.
   * @param t2
   *          The second error.
   * @return <code>true</code> if and only if the identify exactly the
   *         same error.
   */
  public static final boolean testErrorEqual(final Throwable t1,
      final Throwable t2) {

    StackTraceElement[] st1, st2;
    int i;

    if (t1 == t2)
      return true;

    if ((t1 == null) || (t2 == null))
      return false;

    if (Utils.testEqual(t1.getClass(), t2.getClass())
        && Utils.testEqual(t1.getMessage(), t2.getMessage())
        && Utils.testEqual(t1.getLocalizedMessage(), t2
            .getLocalizedMessage())) {
      st1 = t1.getStackTrace();
      st2 = t2.getStackTrace();

      i = st1.length;
      if (i != st2.length)
        return false;

      for (--i; i >= 0; i--) {
        if (!(Utils.testEqual(st1[i], st2[i])))
          return false;
      }
      return true;
    }
    return false;
  }

  /**
   * Show the specified error to the user
   * 
   * @param t
   *          the error to be shown
   */
  public static final void showError(final Throwable t) {
    ErrorDialog.INSTANCE.display(t);
  }

  /**
   * This class cannot be instantiated.
   */
  private ErrorUtils() {
    doNotCall();
  }

  /**
   * The internal error class for tunneled errors.
   * 
   * @author Thomas Weise
   */
  public static final class TunnelledException extends RuntimeException {
    /**
     * the serial version uid
     */
    private static final long serialVersionUID = 1L;

    /**
     * Create a new tunnelled error.
     * 
     * @param cause
     *          the cause
     */
    TunnelledException(final String cause) {
      super(cause);
    }

    /**
     * Create a new tunnelled error.
     * 
     * @param cause
     *          the cause
     */
    TunnelledException(final Throwable cause) {
      super(cause);
    }
  }
}
