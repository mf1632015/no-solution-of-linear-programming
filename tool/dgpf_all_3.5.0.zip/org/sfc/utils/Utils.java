/*
 * Copyright (c) 2006 Thomas Weise
 * Software Foundation Classes
 * http://sourceforge.net/projects/java-sfc
 * 
 * E-Mail           : tweise@gmx.de
 * Creation Date    : 2006-12-21
 * Creator          : Thomas Weise
 * Original Filename: org.sfc.utils.Utils.java
 * Last modification: 2006-12-21
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sfc.utils;

import java.lang.reflect.Array;

/**
 * A class for unclassified utilities.
 * 
 * @author Thomas Weise
 */
public final class Utils {

  /**
   * Check two objects for equality.
   * 
   * @param o1
   *          The first object.
   * @param o2
   *          The second object.
   * @return <code>true</code> if and only if the two objects are equal.
   */
  public static final boolean testEqual(final Object o1, final Object o2) {
    if (o1 == o2)
      return true;
    if ((o1 == null) || (o2 == null))
      return false;
    return o1.equals(o2);
  }

  /**
   * Check two objects for equality also considering array equality.
   * 
   * @param o1
   *          The first object.
   * @param o2
   *          The second object.
   * @return <code>true</code> if and only if the two objects are equal.
   */
  public static final boolean testEqualDeep(final Object o1,
      final Object o2) {
    Class<?> c1, c2;
    int i;

    if (o1 == o2)
      return true;
    if ((o1 == null) || (o2 == null))
      return false;

    if (o1.equals(o2))
      return true;

    c1 = o1.getClass();
    c2 = o2.getClass();
    if (c1 != c2)
      return false;
    if (!(c1.isArray()))
      return false;

    i = Array.getLength(o1);
    if (i != Array.getLength(o2))
      return false;

    for (--i; i >= 0; i--) {
      if (!testEqualDeep(Array.get(o1, i), Array.get(o2, i)))
        return false;
    }
    return true;
  }

  /**
   * You cannot instantiate this class.
   */
  private Utils() {
    ErrorUtils.doNotCall();
  }
}
