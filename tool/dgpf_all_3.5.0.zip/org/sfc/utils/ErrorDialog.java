/*
 * Copyright (c) 2006 Thomas Weise
 * Software Foundation Classes
 * http://sourceforge.net/projects/java-sfc
 * 
 * E-Mail           : tweise@gmx.de
 * Creation Date    : 2006-11-22
 * Creator          : Thomas Weise
 * Original Filename: org.sfc.utils.ErrorUtils.java
 * Last modification: 2006-11-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sfc.utils;

import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

import org.sfc.gui.ComponentUtils;
import org.sfc.gui.windows.SfcDialog;
import org.sfc.text.TextUtils;

/**
 * The error dialog
 * 
 * @author Thomas Weise
 */
final class ErrorDialog extends SfcDialog {
  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * Create a new error dialog
   */
  static final ErrorDialog INSTANCE = new ErrorDialog();

  /**
   * the tree
   */
  private DefaultTreeModel m_tree;

  /**
   * the tree
   */
  private JTree m_tree2;

  /**
   * the error type
   */
  private JLabel m_type;

  /**
   * the text area
   */
  private JTextArea m_text;

  /**
   * the stack trace
   */
  private JTextArea m_trace;

  /**
   * Create a new error dialog
   */
  ErrorDialog() {
    super(null);

    Container c;
    JButton jb;
    JPanel jp;
    JTree jt;

    this.setModal(true);
    this.setTitle("Error"); //$NON-NLS-1$

    c = this.getContentPane();
    c.setLayout(new GridBagLayout());

    ComponentUtils.putGrid(c, new JScrollPane(
        this.m_tree2 = jt = new JTree(this.m_tree = new DefaultTreeModel(
            null))), 0, 0, 1, 3,//
        1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH);
    jt.addTreeSelectionListener(new TreeSelectionListener() {
      public void valueChanged(final TreeSelectionEvent e) {
        TreePath tp;
        Object o;
        tp = e.getNewLeadSelectionPath();
        if (tp != null) {
          o = tp.getLastPathComponent();
          if (o instanceof DefaultMutableTreeNode) {
            o = (((DefaultMutableTreeNode) o).getUserObject());
            if (o instanceof ThrowableWrapper) {
              ErrorDialog.this.setThrowable(((ThrowableWrapper) o).m_t);
            }
          }
        }
      }
    });

    ComponentUtils.putGrid(c, this.m_type = new JLabel(), //
        1, 0, 1, 1,//
        0, 0, GridBagConstraints.CENTER, GridBagConstraints.BOTH);

    ComponentUtils.putGrid(c, new JScrollPane(
        this.m_text = new JTextArea()), 1, 1, 1, 1,//
        1, 0.25d, GridBagConstraints.CENTER, GridBagConstraints.BOTH);
    
    ComponentUtils.putGrid(c, new JScrollPane(
        this.m_trace = new JTextArea()), 1, 2, 1, 1,//
        1, 1, GridBagConstraints.CENTER, GridBagConstraints.BOTH);

    jp = new JPanel();

    ComponentUtils.putGrid(c, jp, 0, 3, 2, 0,//
        0, 0, GridBagConstraints.CENTER, GridBagConstraints.NONE);

    jp.add(jb = ComponentUtils.createOkButton());
    jb.addActionListener(new ActionListener() {
      public void actionPerformed(final ActionEvent ae) {
        ErrorDialog.this.closeByUser();
      }
    });

  }

  /**
   * set the throwable
   * 
   * @param t
   *          the throwable
   */
  final void setThrowable(final Throwable t) {
    String s;
    StringBuilder sb;
    Class<?> c;
    StackTraceElement ste;
    StackTraceElement[] st;
    int i;

    this.m_text.setText("no text"); //$NON-NLS-1$
    this.m_type.setText("unknown type");//$NON-NLS-1$
    this.m_trace.setText("no trace");//$NON-NLS-1$

    if (t != null) {

      s = TextUtils.preprocessString(t.getLocalizedMessage());
      if (s == null)
        s = TextUtils.preprocessString(t.getMessage());
      if (s != null)
        this.m_text.setText(s);

      c = t.getClass();
      if (c != null) {
        s = c.getCanonicalName();
        if (s != null)
          this.m_type.setText(s);
      }

      st = t.getStackTrace();
      if (st != null) {
        if (st.length <= 0)
          this.m_trace.setText("empty trace");//$NON-NLS-1$
        else {
          sb = new StringBuilder();
          for (i = 0; i < st.length; i++) {
            if (i > 0)
              sb.append(TextUtils.LINE_SEPARATOR);
            ste = st[i];
            if (ste == null)
              sb.append(String.valueOf(null));
            else {
              sb.append(ste.getClassName());
              sb.append('.');
              sb.append(ste.getMethodName());
              sb.append('(');
              sb.append(ste.getFileName());
              sb.append(':');
              sb.append(ste.getLineNumber());
              sb.append(')');
            }
          }
          
          this.m_trace.setText(sb.toString());
        }
      }
    }

  }

  /**
   * Display this dialog.
   * 
   * @param t
   *          the throwable to be displayed
   */
  final void display(final Throwable t) {
    DefaultMutableTreeNode r, n;
    Throwable tt;

    if (t != null) {
      r = new DefaultMutableTreeNode(new ThrowableWrapper(t));
      for (tt = t.getCause(); tt != null; tt = tt.getCause()) {
        n = r;
        r = new DefaultMutableTreeNode(new ThrowableWrapper(tt));
        r.add(n);
      }

    } else
      r = new DefaultMutableTreeNode(String.valueOf(null));

    this.m_tree.setRoot(r);
    this.m_tree2.setSelectionPath(new TreePath(r));
    // this.setThrowable(t);
    this.pack();
    this.setVisible(true);
  }

  /**
   * Close the object. You must not perform any operations with the object
   * afterwards nor should you allow any reference to point on this object.
   * Also you must not access any member variables of the object. Call this
   * method when you don't need an object anymore, allowing it to perform
   * some cleanup.
   */
  @Override
  public synchronized void close() {
    super.close();
    this.reuse();
  }

  /**
   * Read resolve this dialog
   * 
   * @return the resolved error dialog
   */
  private final Object readResolve() {
    return INSTANCE;
  }

  /**
   * Write replace this dialog
   * 
   * @return the resolved error dialog
   */
  private final Object writeReplace() {
    return this.readResolve();
  }

  /**
   * the internal throwable wrapper
   * 
   * @author Thomas Weise
   */
  private static final class ThrowableWrapper implements Serializable {
    /**
     * The serial version uid.
     */
    private static final long serialVersionUID = 1;

    /** the internal throwable */
    final Throwable m_t;

    /**
     * create a new throwable wrapper
     * 
     * @param t
     *          the throwable to wrap
     */
    ThrowableWrapper(final Throwable t) {
      super();
      this.m_t = t;
    }

    /**
     * Obtain the string representing this wrapper
     * 
     * @return the string representing this wrapper
     */
    @Override
    public final String toString() {
      return this.m_t.getClass().getSimpleName();
    }
  }
}
