/*
 * Copyright (c) 2006 Thomas Weise
 * Software Foundation Classes
 * http://sourceforge.net/projects/java-sfc
 * 
 * E-Mail           : tweise@gmx.de
 * Creation Date    : 2006-11-26
 * Creator          : Thomas Weise
 * Original Filename: org.sfc.io.StreamLoader.java
 * Last modification: 2006-11-26
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sfc.io;

import java.io.IOException;
import java.io.InputStream;

/**
 * This one is allows you to load streams completely into a byte array. You
 * can also concat multiple streams that way.
 * 
 * @author Thomas Weise
 */
public final class StreamLoader {
  /**
   * The internal data array.
   */
  private byte[] m_data;

  /**
   * The internal read buffer.
   */
  private byte[] m_buffer;

  /**
   * The current length of the internal data.
   */
  private int m_length;

  /**
   * Create a new StreamLoader.
   */
  public StreamLoader() {
    this(8 * 1024);
  }

  /**
   * Create a new StreamLoader.
   * 
   * @param bufferSize
   *          The initial read buffer size. You can leave this this
   *          parameter 0 and a reasonable default will be used.
   */
  public StreamLoader(final int bufferSize) {
    super();

    int bs;

    if (bufferSize <= 0)
      bs = 4096;
    else
      bs = bufferSize;

    this.m_data = new byte[bs];
    this.m_buffer = new byte[bs];
  }

  /**
   * Reset the stream loader. Invalidate the internal data and set the
   * current data length back to 0. You can reuse the loader after a call
   * to reset. The content returned by get_data() is unspecified
   * afterwards. get_length() will return 0.
   */
  public void reset() {
    this.m_length = 0;
  }

  /**
   * Load an input stream completely into the buffer.
   * 
   * @param is
   *          The input stream to load.
   * @return true if everything went ok, false if an exception got caught.
   */
  public boolean loadStream(final InputStream is) {
    int i, j, l;
    byte[] b, d;

    try {
      j = this.m_length;
      d = this.m_data;
      b = this.m_buffer;

      while ((i = is.read(b)) > 0) {
        l = (j + i);
        if (l >= d.length) {
          d = new byte[l << 1];
          System.arraycopy(this.m_data, 0, d, 0, j);
          this.m_data = d;
        }

        System.arraycopy(b, 0, d, j, i);

        j = l;
      }

      this.m_length = j;
      return true;
    } catch (IOException ioe) {
      return false;
    } finally {
      try {
        is.close();
      } catch (IOException ioe2) {
        return false;
      }
    }
  }

  /**
   * Returns the current length of the loaded data.
   * 
   * @return The current length of the loaded data.
   */
  public int getLength() {
    return this.m_length;
  }

  /**
   * Returns the currently loaded data.
   * 
   * @return A byte array containing get_length() bytes of valid data.
   */
  public byte[] getData() {
    return this.m_data;
  }

  /**
   * A convenient method to load streams identified by an object.
   * 
   * @param source
   *          The source object to be loaded.
   * @return true if everything went ok, false otherwise.
   */
  public boolean load(final Object source) {
    return loadStream(IO.getInputStream(source));
  }
}
