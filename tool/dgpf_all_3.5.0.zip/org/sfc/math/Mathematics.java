/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-05
 * Creator          : Thomas Weise
 * Original Filename: org.sfc.math.Mathematics.java
 * Last modification: 2007-03-05
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sfc.math;

import org.sfc.utils.ErrorUtils;

/**
 * This class contains some mathematic utilities.
 * 
 * @author Thomas Weise
 */
public final class Mathematics {

  /**
   * the highest possible integer prime
   */
  public static final int MAX_PRIME = 2147483629;// getMaxPrime();

  /**
   * The sqare root of the maximum integer.
   */
  private static final int SQRT_MAX_INT = ((int) (Math
      .sqrt(Integer.MAX_VALUE)));

  /**
   * The sqare root of the maximum integer threshold.
   */
  private static final int SQRT_MAX_INT_TH = (SQRT_MAX_INT * SQRT_MAX_INT);

  /**
   * Wrap a value so it fits into 0...mod-1
   * 
   * @param value
   *          the value to be wrapped
   * @param mod
   *          the modulo operator
   * @return the wrapped value
   */
  public static final int modulo(final int value, final int mod) {
    if (value < 0)
      return (((value % mod) + mod) % mod);
    return (value % mod);
  }

  /**
   * Wrap a value so it fits into 0...mod-1
   * 
   * @param value
   *          the value to be wrapped
   * @param mod
   *          the modulo operator
   * @return the wrapped value
   */
  public static final long modulo(final long value, final long mod) {
    if (value < 0)
      return (((value % mod) + mod) % mod);
    return (value % mod);
  }

  /**
   * Perform a division which returns a result rounded to the next higher
   * integer.
   * 
   * @param dividend
   *          the divident
   * @param divisor
   *          the divisor
   * @return the result
   */
  public static final int ceilDiv(final int dividend, final int divisor) {
    int d;

    d = (dividend / divisor);
    if ((d * divisor) != dividend)
      return (d + 1);
    return d;
  }

  /**
   * Perform a division which returns a result rounded to the next higher
   * integer.
   * 
   * @param dividend
   *          the divident
   * @param divisor
   *          the divisor
   * @return the result
   */
  public static final long ceilDiv(final long dividend, final long divisor) {
    long d;

    d = (dividend / divisor);
    if ((d * divisor) != dividend)
      return (d + 1);
    return d;
  }

  /**
   * check whether a given number is prime or not
   * 
   * @param num
   *          the number to check
   * @return <code>true</code> if it is, <code>false</code> otherwise
   */
  public static final boolean isPrime(final int num) {
    int i, m;

    if (num <= 1)
      return false;
    if (num <= 3)
      return true;

    if ((num & 1) == 0)
      return false;

    if (num > MAX_PRIME)
      return false;

    i = 3;

    if (num < SQRT_MAX_INT_TH) {
      do {
        if ((num % i) <= 0)
          return false;
        i += 2;
      } while ((i * i) < num);
    } else {
      m = SQRT_MAX_INT;
      do {
        if ((num % i) <= 0)
          return false;
        i += 2;
      } while (i <= m);
    }

    return true;
  }

  /**
   * Obtain the next prime greater than <code>num</code>.
   * 
   * @param num
   *          the number we want to find a greater or equal prime of
   * @return the greater prime
   */
  public static final int nextPrime(final int num) {
    int n, i, m;

    if (num >= MAX_PRIME)
      return MAX_PRIME;
    n = ((num < 3) ? 3 : (((num & 1) == 0) ? (num + 1) : num));

    main:
    for (;; n += 2) {
      i = 3;

      if (n < SQRT_MAX_INT_TH) {
        do {
          if ((n % i) <= 0)
            continue main;
          i += 2;
        } while ((i * i) < n);
      } else {
        m = SQRT_MAX_INT;
        do {
          if ((n % i) <= 0)
            continue main;
          i += 2;
        } while (i <= m);
      }

      return n;
    }
  }

  /**
   * the forbidden constructor
   */
  private Mathematics() {
    ErrorUtils.doNotCall();
  }

}
