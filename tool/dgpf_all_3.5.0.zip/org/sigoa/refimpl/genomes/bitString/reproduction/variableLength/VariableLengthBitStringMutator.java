/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-21
 * Creator          : Thomas Weise
 * Original Filename: org.sigoa.refimpl.genomes.bitString.reproduction.variableLength.VariableLengthBitStringMutator.java
 * Last modification: 2006-12-21
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sigoa.refimpl.genomes.bitString.reproduction.variableLength;

import org.sigoa.refimpl.genomes.bitString.reproduction.BitStringToggleNConsecutiveBitsMutator;
import org.sigoa.refimpl.genomes.bitString.reproduction.BitStringToggleNRandomBitsMutator;
import org.sigoa.refimpl.go.reproduction.MultiMutator;
import org.sigoa.spec.go.reproduction.IMutator;

/**
 * This mutator combines the most common bit string mutators in one
 * interface.
 * 
 * @author Thomas Weise
 */
public class VariableLengthBitStringMutator extends MultiMutator<byte[]> {
  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * create a new mutator that deletes a sequence of bits from a genome
   * 
   * @param granularity
   *          the granularity of the creator, the bit count of the pieces
   *          new genomes will consist of
   * @throws IllegalArgumentException
   *           if <code>granularity &lt;=0</code>
   */
  public VariableLengthBitStringMutator(final int granularity) {
    super(create(granularity), new double[] {  1, 1, 0.6, 0.6 });
  }

  /**
   * create the new internal mutators
   * 
   * @param granularity
   *          the granularity of the creator, the bit count of the pieces
   *          new genomes will consist of
   * @return the mutator array
   */
  @SuppressWarnings("unchecked")
  private static final IMutator<byte[]>[] create(final int granularity) {
    return new IMutator[] {
        new VariableLengthBitStringDeleteMutator(granularity),
        new VariableLengthBitStringInsertMutator(granularity),
        BitStringToggleNConsecutiveBitsMutator.BIT_STRING_TOGGLE_N_CONSECUTIVE_BITS_MUTATOR,
        BitStringToggleNRandomBitsMutator.BIT_STRING_TOGGLE_N_RANDOM_BITS_MUTATOR 
        };
  }

  /**
   * create a new mutator that deletes a sequence of bits from a genome
   */
  public VariableLengthBitStringMutator() {
    this(1);
  }

}
