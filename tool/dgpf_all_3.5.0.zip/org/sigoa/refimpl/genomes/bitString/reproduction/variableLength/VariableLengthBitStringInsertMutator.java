/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-21
 * Creator          : Thomas Weise
 * Original Filename: org.sigoa.refimpl.genomes.bitString.reproduction.variableLength.VariableLengthBitStringInsertMutator.java
 * Last modification: 2006-12-21
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sigoa.refimpl.genomes.bitString.reproduction.variableLength;

import java.io.IOException;
import java.io.ObjectInputStream;

import org.sigoa.refimpl.genomes.bitString.BitStringInputStream;
import org.sigoa.refimpl.genomes.bitString.BitStringOutputStream;
import org.sigoa.refimpl.go.reproduction.Mutator;
import org.sigoa.spec.stoch.IRandomizer;

/**
 * This mutator inserts an additional sequence of bits into a bit string.
 * 
 * @author Thomas Weise
 */
public class VariableLengthBitStringInsertMutator extends Mutator<byte[]> {
  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * the internal bit string input stream
   */
  private transient BitStringInputStream m_is;

  /**
   * the internal bit string output stream
   */
  private transient BitStringOutputStream m_os;

  /**
   * the granularity.
   */
  private final int m_granularity;

  /**
   * create a new mutator that inserts a new sequence of bits into a genome
   * 
   * @param granularity
   *          the granularity of the creator, the bit count of the pieces
   *          new genomes will consist of
   * @throws IllegalArgumentException
   *           if <code>granularity &lt;=0</code>
   */
  public VariableLengthBitStringInsertMutator(final int granularity) {
    super();
    this.init();
    if (granularity <= 0)
      throw new IllegalArgumentException();
    this.m_granularity = granularity;
  }

  /**
   * create a new mutator that inserts a new sequence of bits into a genome
   */
  public VariableLengthBitStringInsertMutator() {
    this(1);
  }

  /**
   * initialize this object
   */
  private final void init() {
    this.m_is = new BitStringInputStream();
    this.m_os = new BitStringOutputStream();
  }

  /**
   * Deserialize the mutator.
   * 
   * @param stream
   *          The stream to deserialize from.
   * @throws IOException
   *           if io fucks up.
   * @throws ClassNotFoundException
   *           if the class could not be found.
   */
  private final void readObject(final ObjectInputStream stream)
      throws IOException, ClassNotFoundException {
    stream.defaultReadObject();
    this.init();
  }

  /**
   * Perform one single mutation.
   * 
   * @param source
   *          The source genotype.
   * @param random
   *          The randomizer to be used.
   * @return The resulting genotype.
   * @throws NullPointerException
   *           if <code>source==null||random==null</code>.
   */
  @Override
  public synchronized byte[] mutate(final byte[] source,
      final IRandomizer random) {

    int c, p, g, mc;
    final int l;
    BitStringInputStream bis;
    BitStringOutputStream bos;
    byte[] res;

    if ((source == null) || (random == null))
      throw new NullPointerException();

    g = this.m_granularity;
    l = ((source.length << 3) / g);
    do {
      c = (1 + (int) (random.nextExponential(1d)));
    } while (c > 1000);
    p = random.nextInt(l + 1);

    bis = this.m_is;
    bos = this.m_os;
    c *= g;
    p *= g;

    bis.init(source, 0, p);
    for (mc = (bis.availableBits() >>> 5); mc > 0; mc--) {
      bos.writeBits(bis.readBits(32), 32);
    }
    mc = bis.availableBits();
    bos.writeBits(bis.readBits(mc), mc);

    for (; c > 0; c -= 32) {
      bos.writeBits(random.nextInt(), ((c > 32) ? 32 : c));
    }

    bis.init(source, p, ((l * g) - p));
    for (mc = (bis.availableBits() >>> 5); mc > 0; mc--) {
      bos.writeBits(bis.readBits(32), 32);
    }
    mc = bis.availableBits();
    bos.writeBits(bis.readBits(mc), mc);

    res = bos.getOutput();
    bos.clear();
    bis.clear();

    return res;
  }

}
