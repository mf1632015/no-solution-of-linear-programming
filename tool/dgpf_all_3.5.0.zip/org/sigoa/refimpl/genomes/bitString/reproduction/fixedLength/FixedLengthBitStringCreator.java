/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-20
 * Creator          : Thomas Weise
 * Original Filename: org.sigoa.refimpl.genomes.bitString.reproduction.fixedLength.FixedLengthBitStringCreator.java
 * Last modification: 2006-12-20
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sigoa.refimpl.genomes.bitString.reproduction.fixedLength;

import org.sigoa.refimpl.genomes.bitString.reproduction.BitStringCreator;
import org.sigoa.spec.stoch.IRandomizer;

/**
 * This creator generates bit strings of a fixed length
 * 
 * @author Thomas Weise
 */
public class FixedLengthBitStringCreator extends BitStringCreator {

  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * the length (in bits) of the strings to be created
   */
  private final int m_length;

  /**
   * Create a new <code>FixedLengthBitStringCreator</code>.
   * 
   * @param length
   *          the length (in granularity bits) of the strings to be created
   * @param granularity
   *          the granularity of the creator, the bit count of the pieces
   *          new genomes will consist of
   * @throws IllegalArgumentException
   *           if <code>granularity &lt;=0||length&lt;=0</code>
   */
  public FixedLengthBitStringCreator(final int length,
      final int granularity) {
    super(granularity);
    if (length <= 0)
      throw new IllegalArgumentException();
    this.m_length = length;
  }

  /**
   * Create a new <code>FixedLengthBitStringCreator</code>.
   * 
   * @param length
   *          the length (in granularity bits) of the strings to be created
   * @throws IllegalArgumentException
   *           if <code>length&lt;=0</code>
   */
  public FixedLengthBitStringCreator(final int length) {
    this(length, 1);
  }

  /**
   * Obtain the length of the bit string to be created (in granularity
   * units).
   * 
   * @param random
   *          a randomizer which is maybe useful
   * @return the length of the bit string to be created (in granularity
   *         units)
   */
  @Override
  protected int getNewLength(final IRandomizer random) {
    return this.m_length;
  }
}
