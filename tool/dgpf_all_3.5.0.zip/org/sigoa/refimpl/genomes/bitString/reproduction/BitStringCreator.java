/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-19
 * Creator          : Thomas Weise
 * Original Filename: org.sigoa.refimpl.genomes.bitString.reproduction.BitStringCreator.java
 * Last modification: 2006-12-19
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sigoa.refimpl.genomes.bitString.reproduction;

import org.sigoa.refimpl.go.reproduction.Creator;
import org.sigoa.spec.stoch.IRandomizer;

/**
 * a creator able to create bit strings
 * 
 * @author Thomas Weise
 */
public abstract class BitStringCreator extends Creator<byte[]> {

  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * the granularity of the creator, the bit count of the pieces new
   * genomes will consist of
   */
  private final int m_granularity;

  /**
   * Instantiate the bit string creator
   * 
   * @param granularity
   *          the granularity of the creator, the bit count of the pieces
   *          new genomes will consist of
   * @throws IllegalArgumentException
   *           if <code>granularity &lt;=0</code>
   */
  protected BitStringCreator(final int granularity) {
    super();
    if (granularity <= 0)
      throw new IllegalArgumentException();
    this.m_granularity = granularity;
  }

  /**
   * Obtain the length of the bit string to be created (in granularity
   * units).
   * 
   * @param random
   *          a randomizer which is maybe useful
   * @return the length of the bit string to be created (in granularity
   *         units)
   */
  protected abstract int getNewLength(final IRandomizer random);

  /**
   * Create a single new random genotype
   * 
   * @param random
   *          The randomizer to be used.
   * @return The resulting genotype.
   * @throws NullPointerException
   *           if <code>random==null</code>.
   */
  public byte[] create(final IRandomizer random) {
    int l;
    byte[] b;

    do {
      l = this.getNewLength(random);
    } while (l <= 0);

    l = (((l * this.m_granularity) + 7) >>> 3);
    b = new byte[l];

    for (--l; l >= 0; l--) {
      b[l] = (byte) (random.nextInt(256));
    }

    return b;
  }

  /**
   * Obtain the bit string creator's granularity.
   * 
   * @return the bit string creator's granularity
   */
  public int getGranularity() {
    return this.m_granularity;
  }
}
