/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-21
 * Creator          : Thomas Weise
 * Original Filename: org.sigoa.refimpl.genomes.bitString.reproduction.BitStringCrossover.java
 * Last modification: 2006-12-21
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sigoa.refimpl.genomes.bitString.reproduction;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;

import org.sigoa.refimpl.genomes.bitString.BitStringInputStream;
import org.sigoa.refimpl.genomes.bitString.BitStringOutputStream;
import org.sigoa.refimpl.go.reproduction.Crossover;
import org.sigoa.spec.stoch.IRandomizer;

/**
 * The base class for bit string crossover operations.
 * 
 * @author Thomas Weise
 */
public class BitStringCrossover extends Crossover<byte[]> {
  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * the crossover point coordinates
   */
  private transient int[] m_points1;

  /**
   * the crossover point coordinates
   */
  private transient int[] m_points2;

  /**
   * the internal bit string input stream
   */
  private transient BitStringInputStream m_is;

  /**
   * the internal bit string output stream
   */
  private transient BitStringOutputStream m_os;

  /**
   * the granularity.
   */
  private final int m_granularity;

  /**
   * create a new bit string crossover. At most <code>maxPoints</code>
   * split points will occure and boundaries aligned to
   * <code>granularity</code> bits.
   * 
   * @param maxPoints
   *          the count of coordinates needed
   * @param granularity
   *          the granularity of the creator, the bit count of the pieces
   *          new genomes will consist of
   * @throws IllegalArgumentException
   *           if <code>granularity &lt;=0</code>
   */
  public BitStringCrossover(final int maxPoints, final int granularity) {
    super();
    this.init(maxPoints);
    if (granularity <= 0)
      throw new IllegalArgumentException();
    this.m_granularity = granularity;
  }

  /**
   * create a new bit string crossover
   * 
   * @param maxPoints
   *          the count of coordinates needed
   */
  public BitStringCrossover(final int maxPoints) {
    this(maxPoints, 1);
  }

  /**
   * initialize this object
   * 
   * @param maxPoints
   *          the count of coordinates needed
   */
  private final void init(final int maxPoints) {
    this.m_points1 = new int[maxPoints];
    this.m_points2 = new int[maxPoints];
    this.m_is = new BitStringInputStream();
    this.m_os = new BitStringOutputStream();
  }

  /**
   * Serialize this crossover.
   * 
   * @param out
   *          the output stream
   * @throws IOException
   *           maybe
   */
  private final void writeObject(final ObjectOutputStream out)
      throws IOException {
    out.defaultWriteObject();
    out.writeInt(this.m_points1.length);
  }

  /**
   * Deserialize the crossover.
   * 
   * @param stream
   *          The stream to deserialize from.
   * @throws IOException
   *           if io fucks up.
   * @throws ClassNotFoundException
   *           if the class could not be found.
   */
  private final void readObject(final ObjectInputStream stream)
      throws IOException, ClassNotFoundException {
    stream.defaultReadObject();
    this.init(stream.readInt());
  }

  /**
   * Obtain the count of split points to be used
   * 
   * @param random
   *          the randomizer
   * @param max
   *          the maximum count of split points available
   * @return the count of split points to be used
   */
  protected int getSplitCount(final IRandomizer random, final int max) {
    return max;
  }

  /**
   * Obtain the crossover points where to crossover the parents. The
   * indices should be between (inclusive) 1 and (exclusive)
   * parent.length-1.
   * 
   * @param length1
   *          the length of the first parent in bits
   * @param length2
   *          the length of the second parent in bits
   * @param random
   *          the randomizer
   * @param points1
   *          an integer array to fill in the crossover points of the first
   *          parent
   * @param points2
   *          an integer array to fill in the crossover points of the
   *          second parent
   * @param count
   *          the count of split points to generate
   */
  protected void getCrossoverPoints(final int length1, final int length2,
      final IRandomizer random, final int[] points1, final int[] points2,
      final int count) {
    int i, sp, m, j;

    m = (Math.min(length1, length2) - 1);

    for (i = (count - 1); i >= 0; i--) {
      main: for (;;) {
        sp = (1 + random.nextInt(m));
        for (j = (i + 1); j < count; j++) {
          if (points1[j] == sp)
            continue main;
        }
        break main;
      }

      points1[i] = sp;
      points2[i] = sp;
    }
  }

  /**
   * Perform one single recombination/crossover.
   * 
   * @param source1
   *          The first source genotype.
   * @param source2
   *          The second source genotype.
   * @param random
   *          The randomizer to be used.
   * @return The resulting genotype.
   * @throws NullPointerException
   *           if <code>source1==null||source2==null||random==null</code>.
   */
  @Override
  public synchronized byte[] crossover(final byte[] source1,
      final byte[] source2, final IRandomizer random) {

    final int[] ii1, ii2;
    int[] ii;
    int l1, l2, i, g, sc, mc, i1, i2;
    byte[] res;
    boolean b;
    final BitStringInputStream is;
    final BitStringOutputStream os;

    if ((source1 == null) || (source2 == null))
      throw new NullPointerException();
    
    ii2 = this.m_points2;
    ii1 = this.m_points1;
    l1 = (source1.length << 3);
    l2 = (source2.length << 3);
    g = this.m_granularity;

    i1 = (l1 / g);
    i2 = (l2 / g);
    mc = Math.min(Math.min(i1, i2) - 1, ii1.length);
    if (mc <= 0) {
      return (random.nextBoolean() ? source1 : source2);
    }

    do {
      sc = this.getSplitCount(random, mc);
    } while (sc <= 0);

    this.getCrossoverPoints(i1, i2, random, ii1, ii2, sc);

    Arrays.sort(ii1, 0, sc);
    Arrays.sort(ii2, 0, sc);

    is = this.m_is;
    os = this.m_os;

    b = true;
    for (i = 0; i <= sc; i++) {

      if (b) {
        res = source1;
        ii = ii1;
        mc = l1;
      } else {
        res = source2;
        ii = ii2;
        mc = l2;
      }

      if (i <= 0)
        i1 = 0;
      else
        i1 = (ii[i - 1] * g);

      if (i < sc)
        i2 = (ii[i] * g);
      else
        i2 = mc;

      is.init(res, i1, i2 - i1);

      for (mc = (is.availableBits() >>> 5); mc > 0; mc--) {
        os.writeBits(is.readBits(32), 32);
      }
      mc = is.availableBits();
      os.writeBits(is.readBits(mc), mc);

      b = (!b);
    }

    res = os.getOutput();
    os.clear();
    is.clear();
    
    return res;
  }
  
  /**
   * Obtain the bit string creator's granularity.
   * 
   * @return the bit string creator's granularity
   */
  public int getGranularity() {
    return this.m_granularity;
  }
}
