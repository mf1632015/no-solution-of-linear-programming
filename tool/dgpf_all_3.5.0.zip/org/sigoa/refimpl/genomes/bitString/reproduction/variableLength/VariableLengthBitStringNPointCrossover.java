/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-22
 * Creator          : Thomas Weise
 * Original Filename: org.sigoa.refimpl.genomes.bitString.reproduction.variableLength.VariableLengthBitStringNPointCrossover.java
 * Last modification: 2006-12-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sigoa.refimpl.genomes.bitString.reproduction.variableLength;

import org.sigoa.refimpl.genomes.bitString.reproduction.BitStringCrossover;
import org.sigoa.spec.stoch.IRandomizer;

/**
 * the n-point crossover for variable length bit strings
 * 
 * @author Thomas Weise
 */
public class VariableLengthBitStringNPointCrossover extends
    BitStringCrossover {
  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * Create a new bit string n-point crossover. N split points will occure
   * and boundaries aligned to <code>granularity</code> bits.
   * 
   * @param granularity
   *          the granularity
   */
  public VariableLengthBitStringNPointCrossover(final int granularity) {
    super(128, granularity);
  }

  /**
   * Create a new bit string n-point crossover. N split points will occure.
   */
  public VariableLengthBitStringNPointCrossover() {
    this(1);
  }

  /**
   * Obtain the count of split points to be used
   * 
   * @param random
   *          the randomizer
   * @param max
   *          the maximum count of split points available
   * @return the count of split points to be used
   */
  @Override
  protected int getSplitCount(final IRandomizer random, final int max) {
    int i;

    do {
      i = (1 + (int) (random.nextExponential(0.9d)));
    } while (i > max);

    return i;
  }

  /**
   * Obtain the crossover points where to crossover the parents. The
   * indices should be between (inclusive) 1 and (exclusive)
   * parent.length-1.
   * 
   * @param length1
   *          the length of the first parent in bits
   * @param length2
   *          the length of the second parent in bits
   * @param random
   *          the randomizer
   * @param points1
   *          an integer array to fill in the crossover points of the first
   *          parent
   * @param points2
   *          an integer array to fill in the crossover points of the
   *          second parent
   * @param count
   *          the count of split points to generate
   */
  @Override
  protected void getCrossoverPoints(final int length1, final int length2,
      final IRandomizer random, final int[] points1, final int[] points2,
      final int count) {
    int i, sp, m, j, i2;

    // m = (Math.min(length1, length2) - 1);

    m = (length1 - 1);
    i = i2 = (count - 1);
    for (; i >= 0; i--) {
      main: for (;;) {
        sp = (1 + random.nextInt(m));
        for (j = (i + 1); j < count; j++) {
          if (points1[j] == sp)
            continue main;
        }
        break main;
      }

      points1[i] = sp;
      if ((sp < (length2 - 1)) && random.nextBoolean()) 
        points2[i2--] = sp;
    }

    m = (length2 - 1);
    for (; i2 >= 0; i2--) {
      main: for (;;) {
        sp = (1 + random.nextInt(m));
        for (j = (i2 + 1); j < count; j++) {
          if (points2[j] == sp)
            continue main;
        }
        break main;
      }

      points2[i2] = sp;
    }
  }
}
