/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-10
 * Creator          : Thomas Weise
 * Original Filename: org.sigoa.refimpl.genomes.doubleArray.reproduction.DoubleArrayReproducer.java
 * Last modification: 2006-12-10
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sigoa.refimpl.genomes.doubleArray.reproduction;

import java.io.Serializable;

import org.sigoa.refimpl.go.ImplementationBase;

/**
 * An internal base class for double vector reproduction
 * 
 * @author Thomas Weise
 */
class DoubleArrayReproducer extends
    ImplementationBase<double[], Serializable> implements Serializable {
  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * the minima for the single dimensions
   */
  final double[] m_min;

  /**
   * the maxima for the single dimensions
   */
  final double[] m_max;

  /**
   * the spans for the single dimensions
   */
  final double[] m_span;

  /**
   * Create a new double vector reproducer.
   * 
   * @param min
   *          the minima for the single dimensions
   * @param max
   *          the maxima for the single dimensions
   * @throws IllegalArgumentException
   *           if
   *           <code>(min == null) || (max == null) || (min.length != max.length)</code>
   *           or if the extend in one dimension is smaller or equal to
   *           zero
   */
  DoubleArrayReproducer(final double[] min, final double[] max) {
    super();

    double[] d;
    int i;

    if ((min == null) || (max == null) || ((i = min.length) != max.length))
      throw new IllegalArgumentException();
    this.m_min = min.clone();
    this.m_max = max.clone();

    d = max.clone();
    for (--i; i >= 0; i--) {
      if ((d[i] -= min[i]) <= 0.0d)
        throw new IllegalArgumentException();
    }
    this.m_span = d;
  }
}
