/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-10
 * Creator          : Thomas Weise
 * Original Filename: org.sigoa.refimpl.genomes.doubleArray.reproduction.DoubleArrayMutator.java
 * Last modification: 2006-12-10
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sigoa.refimpl.genomes.doubleArray.reproduction;

import org.sigoa.spec.go.reproduction.IMutator;
import org.sigoa.spec.stoch.IRandomizer;

/**
 * A double vector mutator.
 * 
 * @author Thomas Weise
 */
public class DoubleArrayMutator extends DoubleArrayReproducer implements
    IMutator<double[]> {
  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * the sigmas used for mutation
   */
  private final double[][] m_sigmas;

  /**
   * Create a new double vector mutator.
   * 
   * @param min
   *          the minima for the single dimensions
   * @param max
   *          the maxima for the single dimensions
   * @throws IllegalArgumentException
   *           if
   *           <code>(min == null) || (max == null) || (min.length != max.length)</code>
   *           or if the extend in one dimension is smaller or equal to
   *           zero
   */
  public DoubleArrayMutator(final double[] min, final double[] max) {
    super(min, max);

    double[] sig, spans;
    double[][] sig2;
    double s, d;
    int l, i;

    spans = this.m_span;
    i = spans.length;
    sig2 = new double[i][];

    for (--i; i >= 0; i--) {
      l = 5;
      sig = new double[l];
      d = 0.3;
      s = spans[i];
      for (--l; l >= 0; l--) {
        s *= d;
        sig[l] = s;
        d *= 0.6;
      }
      sig2[i] = sig;
    }

    this.m_sigmas = sig2;
  }

  /**
   * Perform one single mutation.
   * 
   * @param source
   *          The source genotype.
   * @param random
   *          The randomizer to be used.
   * @return The resulting genotype.
   * @throws NullPointerException
   *           if <code>source==null||random==null</code>.
   */
  public double[] mutate(final double[] source, final IRandomizer random) {

    double[] r, v;
    double mi, ma, n;
    int i;

    r = source.clone();
    i = random.nextInt(r.length);

    ma = this.m_max[i];
    mi = this.m_min[i];
    v = this.m_sigmas[i];

    do {
      n = random.nextNormal(source[i], v[random.nextInt(v.length)]);
    } while ((n < mi) || (n > ma) || (n == r[i]));

    r[i] = n;

    return r;
  }
}
