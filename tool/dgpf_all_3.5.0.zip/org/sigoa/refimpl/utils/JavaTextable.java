/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-04-02
 * Creator          : Thomas Weise
 * Original Filename: org.sigoa.refimpl.utils.JavaTextable.java
 * Last modification: 2007-04-02
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sigoa.refimpl.utils;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.sfc.text.TextUtils;
import org.sfc.text.Textable;

/**
 * The default implementation of the {@link IJavaTextable}-interface.
 * 
 * @author Thomas Weise
 */
public class JavaTextable extends Textable implements IJavaTextable {

  /**
   * the new string
   */
  private static final char[] NEW_TEXT = "new ".toCharArray(); //$NON-NLS-1$

  /**
   * the new node text
   */
  private static final char[] NEW_NODES2 = "[] {".toCharArray();//$NON-NLS-1$

  /**
   * the new node text
   */
  private static final char[] NEW_NODES3 = "[0]".toCharArray();//$NON-NLS-1$

  /**
   * Serializes this object as string to a java string builder. The string
   * appended to the string builder can be copy-and-pasted into a java file
   * and represents the constructor of this object.
   * 
   * @param sb
   *          the string builder
   * @param indent
   *          an optional parameter denoting the indentation
   */
  public void javaToStringBuilder(final StringBuilder sb, final int indent) {
    sb.append(NEW_TEXT);
    sb.append(this.getClass().getCanonicalName());
    sb.append('(');
    this.javaParametersToStringBuilder(sb, indent + 2);
    sb.append(')');
  }

  /**
   * Serializes the parameters of the constructor of this object.
   * 
   * @param sb
   *          the string builder
   * @param indent
   *          an optional parameter denoting the indentation
   */
  protected void javaParametersToStringBuilder(final StringBuilder sb,
      final int indent) {
    //
  }

  /**
   * Append an array of java textables to the given string builder.
   * 
   * @param ch
   *          the textables
   * @param count
   *          their number
   * @param nullOnZeroCount
   *          <code>true</code> if and only if we can use
   *          <code>null</code> if the count is zero, <code>false</code>
   *          means an array will be created anyway.
   * @param sb
   *          the string builder to append to
   * @param indent
   *          the indent
   */
  protected static final void appendJavaTextables(
      final IJavaTextable[] ch, final int count,
      final boolean nullOnZeroCount, final StringBuilder sb,
      final int indent) {
    int i, j;

    j = (count - 1);
    if (j >= 0) {
      sb.append(TextUtils.LINE_SEPARATOR);
      TextUtils.appendSpaces(sb, indent);
      sb.append(NEW_TEXT);
      sb.append(ch.getClass().getComponentType().getCanonicalName());
      sb.append(NEW_NODES2);

      for (i = 0; i <= j; i++) {
        sb.append(TextUtils.LINE_SEPARATOR);
        TextUtils.appendSpaces(sb, indent + 2);
        ch[i].javaToStringBuilder(sb, indent + 4);
        if (i < j) {
          sb.append(',');
          sb.append(' ');
        }
      }

      sb.append(TextUtils.LINE_SEPARATOR);
      TextUtils.appendSpaces(sb, indent);
      sb.append('}');
    } else {
      if (nullOnZeroCount)
        sb.append((Object) null);
      else {
        sb.append(NEW_TEXT);
        sb.append(ch.getClass().getComponentType().getCanonicalName());
        sb.append(NEW_NODES3);
      }

      // sb.append(NEW_NODES);
      // sb.append(NEW_NODES3);
    }
  }

  /**
   * This method tries to find the specified constant's qualified name.
   * 
   * @param o
   *          the constant to search
   * @param sb
   *          the string builder to append the name to
   * @return <code>true</code> if and only if the constant could be
   *         found, <code>false</code> otherwise
   */
  protected static final boolean findConstant(final Object o,
      final StringBuilder sb) {
    Class<?> oc, c, c2;
    Method m;
    Constructor<?> cc;
    Field[] ff;
    Field f;
    int i;
    boolean b;
    Object q;

    if (o == null)
      return false;

    oc = c = o.getClass();

    while (c != null) {

      b = true;
      ff = c.getDeclaredFields();
      for (;;) {

        for (i = (ff.length - 1); i >= 0; i--) {
          f = ff[i];

          if (Modifier.isStatic(f.getModifiers())
              && f.getType().isAssignableFrom(oc)) {
            try {
              q = f.get(null);
              if (o.equals(q)) {
                sb.append(c.getCanonicalName());
                sb.append('.');
                sb.append(f.getName());
                return true;
              }
            } catch (Throwable t) {
              //
            }
          }
        }

        if (b) {
          ff = c.getFields();
          b = false;
        } else
          break;
      }

      c2 = c.getEnclosingClass();
      if (c2 != null)
        c = c2;
      else {
        m = c.getEnclosingMethod();
        if (m != null)
          c = m.getDeclaringClass();
        else {
          cc = c.getEnclosingConstructor();
          if (cc != null)
            c = cc.getDeclaringClass();
          else
            c = null;
        }
      }
    }

    return false;
  }
}
