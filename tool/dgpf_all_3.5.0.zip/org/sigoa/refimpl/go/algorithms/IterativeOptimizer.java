/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-08
 * Creator          : Thomas Weise
 * Original Filename: org.sigoa.refimpl.go.algorithms.IterativeOptimizer.java
 * Last modification: 2006-12-08
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sigoa.refimpl.go.algorithms;

import java.io.Serializable;

import org.sigoa.refimpl.go.Optimizer;
import org.sigoa.spec.go.algorithms.IIterativeAlgorithm;
import org.sigoa.spec.jobsystem.EActivityState;

/**
 * The base class for iterative algorithms.
 * 
 * @param <G>
 *          the genotype
 * @param <PP>
 *          the phenotype
 * @author Thomas Weise
 */
public class IterativeOptimizer<G extends Serializable, PP extends Serializable>
    extends Optimizer<G, PP> implements IIterativeAlgorithm {
  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * the current iteration
   */
  private long m_iteration;

  /**
   * the total iterations
   */
  private long m_totalIteration;

  /**
   * the iteration synchronizer
   */
  private final Object m_iterSync;

  /**
   * Create a new iterative optimizer
   */
  public IterativeOptimizer() {
    super();
    this.m_iterSync = new Object();
  }

  /**
   * Returns the number of current iteration. The first iteration will have
   * the number 0.
   * 
   * @return the current iteration
   */
  public long getIteration() {
    synchronized (this.m_iterSync) {
      return this.m_iteration;
    }
  }

  /**
   * Returns the total number of iterations performed.
   * 
   * @return the total number of iterations performed
   */
  public long getTotalIterations() {
    synchronized (this.m_iterSync) {
      return this.m_totalIteration;
    }
  }

  /**
   * Reset this optimization algorithm. This does also reset the iteration
   * counter but doesn't affect the total iteration counter.
   */
  @Override
  public void reset() {
    synchronized (this.m_iterSync) {
      this.m_iteration = 0;
    }
    super.reset();
  }

  /**
   * Normally, an optimizer can be used only once. After it has been run
   * and finished its work, it cannot be run again as defined by the
   * <code>EActivityState</code> semantics. This method allows you to
   * reset the activity state to <code>INITIALIZED</code>. Therefore,
   * you can use the optimizer again. This method also calls
   * <code>reset</code> in order to make the optimizer virgin again.
   * 
   * @throws IllegalStateException
   *           if the algorithm is currently running or being initialized.
   * @see EActivityState
   * @see #reset()
   */
  @Override
  public void reuse() {
    super.reuse();
    synchronized (this.m_iterSync) {
      this.m_totalIteration = 0;
    }
  }

  /**
   * this method is invoked for each iteration performed
   * 
   * @param index
   *          the index of the current itertion
   */
  protected void iteration(final long index) {//    
  }

  /**
   * this method is invoked before each iteration is performed
   * 
   * @param index
   *          the index of the current itertion
   */
  protected void beforeIteration(final long index) {//    
  }

  /**
   * this method is invoked after each iteration is performed
   * 
   * @param index
   *          the index of the current itertion
   */
  protected void afterIteration(final long index) {//    
  }

  /**
   * This method does the work of the optimizer.
   */
  @Override
  protected void doRun() {
    long l;

    synchronized (this.m_iterSync) {
      l = this.m_iteration;
    }

    while (this.isRunning()) {
      this.applyRules();
      this.beforeIteration(l);
      this.iteration(l);
      this.afterIteration(l);

      synchronized (this.m_iterSync) {
        l = (++this.m_iteration);
        this.m_totalIteration++;
      }
    }
  }
}
