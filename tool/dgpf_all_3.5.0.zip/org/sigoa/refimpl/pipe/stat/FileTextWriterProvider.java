/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-28
 * Creator          : Thomas Weise
 * Original Filename: org.sigoa.refimpl.pipe.stat.FileTextWriterProvider.java
 * Last modification: 2006-12-28
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sigoa.refimpl.pipe.stat;

import java.io.File;

import org.sfc.io.CanonicalFile;
import org.sfc.io.IO;
import org.sfc.io.TextWriter;
import org.sfc.text.TextUtils;

/**
 * This text writer provider generates output files that are situated in a
 * specified directory.
 * 
 * @author Thomas Weise
 */
public class FileTextWriterProvider implements IWriterProvider<TextWriter> {
  /**
   * the serial version uid
   */
  private static final long serialVersionUID = 1L;

  /**
   * the destination directory.
   */
  private final CanonicalFile m_directory;

  /**
   * the file name prefix.
   */
  private final String m_prefix;

  /**
   * Create a new file text writer provider.
   * 
   * @param directory
   *          the directory to place the files in
   * @param prefix
   *          the file name prefix
   */
  public FileTextWriterProvider(final Object directory, final String prefix) {
    super();
    this.m_directory = IO.getFile(directory);
    this.m_prefix = prefix;
  }

  /**
   * Obtain the next output writer.
   * 
   * @param iteration
   *          the current iteration
   * @return the next output writer or <code>null</code> if none could be
   *         created
   */
  public TextWriter provideWriter(final long iteration) {
    String name;
    File f;
    CanonicalFile g;

    name = (((this.m_prefix != null) ? this.m_prefix : "") + //$NON-NLS-1$
        TextUtils.longToString(iteration, 5) + ".txt"); //$NON-NLS-1$

    f = this.m_directory;
    if (f != null)
      f = new File(f, name);
    else
      f = new File(name);

    g = CanonicalFile.canonicalize(f);

    if (g == null) {
      g = IO.getFile(f);
      if (g == null) {
        g = IO.getFile(this.m_directory + name);
        if (g == null) {
          g = IO.getFile(name);
          if (g == null)
            return null;
        }
      }
    }

    return new TextWriter(g);
  }
}
