/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-11-22
 * Creator          : Thomas Weise
 * Original Filename: org.sigoa.refimpl.jobsystem.multiprocessor.MPJSThread.java
 * Last modification: 2007-02-23
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package org.sigoa.refimpl.jobsystem.multiprocessor;

import java.io.Serializable;

import org.sigoa.refimpl.events.ErrorEvent;
import org.sigoa.refimpl.utils.DefaultThread;
import org.sigoa.spec.events.IEvent;
import org.sigoa.spec.jobsystem.IHost;
import org.sigoa.spec.jobsystem.IJobInfo;
import org.sigoa.spec.jobsystem.IWaitable;
import org.sigoa.spec.security.ISecurityInfo;
import org.sigoa.spec.security.SecurityUtils;
import org.sigoa.spec.simulation.ISimulationManager;
import org.sigoa.spec.stoch.IRandomizer;

/**
 * The job system worker thread.
 * 
 * @author Thomas Weise
 */
public class MPJSThread extends DefaultThread implements IHost {

  /**
   * The job system that owns this thread.
   */
  final MultiProcessorJobSystem m_js;

  /**
   * The currently running sub-job.
   */
  MPJSJobBase m_job;

  /**
   * The internal randomizer.
   */
  private final IRandomizer m_randomizer;

  /**
   * Create a new job system thread.
   * 
   * @param name
   *          The name of the new job system thread.
   * @param multiProcessorJobSystem
   *          The job system instance using this thread.
   * @param tg
   *          the threadgroup to use
   */
  public MPJSThread(final String name,
      final MultiProcessorJobSystem multiProcessorJobSystem,
      final ThreadGroup tg) {
    super(tg, name);

    if (name == null)
      throw new NullPointerException();

    this.m_js = multiProcessorJobSystem;
    this.m_randomizer = multiProcessorJobSystem.doCreateRandomizer();
  }

  /**
   * Execute a job. This method can only be called from a job that is
   * already running within an <code>IJobSystem</code>-instance. With
   * it, the job may enqueue additional tasks. If the job added is neither
   * in the state <code>INITIALIZED</code> or <code>RUNNING</code> it
   * is discarted.
   * 
   * @param job
   *          the job to execute
   * @return an instance of <code>IRunning</code> allowing you to wait
   *         for the job to complete
   * @throws NullPointerException
   *           if <code>job==null</code>.
   */
  public IWaitable executeJob(final Runnable job) {
    return this.m_job.m_state.addSubJob(job, this.m_job);
  }

  /**
   * Wait until all tasks of the current job are finished.
   */
  public void flushJobs() {
    this.m_job.m_state.flush(this);
  }

  /**
   * Perform the work of this thread.
   */
  @Override
  protected void doRun() {
    while (this.isRunning()) {
      this.m_js.doJob(this);
    }
  }

  /**
   * Obtain the job information interface provided at job creation.
   * 
   * @param <G>
   *          the genotype of the optimizer job
   * @param <PP>
   *          the phenotype of the optimizer job
   * @return The job information interface.
   */
  @SuppressWarnings("unchecked")
  public <G extends Serializable, PP extends Serializable> IJobInfo<G, PP> getJobInfo() {
    return ((IJobInfo<G, PP>) (this.m_job.m_state.m_info));
  }

  /**
   * Obtain the simulation manager of this job system.
   * 
   * @return The simulation manager of the job system running this job.
   */
  public ISimulationManager getSimulationManager() {
    return this.m_js.getSimulationManager();
  }

  /**
   * does nothing
   * 
   * @param eh
   *          ignored
   * @throws SecurityException
   *           always
   */
  @Override
  public void setUncaughtExceptionHandler(final UncaughtExceptionHandler eh) {
    throw new SecurityException();
  }

  /**
   * Forward an event to the job system owning this host.
   * 
   * @param event
   *          The event to be processed.
   */
  public void receiveEvent(final IEvent event) {
    ISecurityInfo si;
    si = SecurityUtils.getSecurityInfoManager();
    if (si == null)
      throw new SecurityException();
    si.checkEvent(event);
    this.m_js.receiveEvent(this.m_job.m_state.m_id, event);
  }

  /**
   * Call this method if the current thread should do something else, like
   * working on another job, because the current job could only perform a
   * wait operation. It is not specified for how long control will be
   * transfered to another job.
   */
  public void defer() {
    Thread.yield();
  }

  /**
   * This method is called whenever an error was caught. It effectively
   * replaces the <code>UncaughtExceptionHandler</code>
   * 
   * @param t
   *          the error caught
   */
  @Override
  protected void onError(final Throwable t) {
    Serializable s;
    super.onError(t);
    this.m_js.onError(t);
    s = this.m_job.m_state.m_id;
    this.m_js.receiveEvent(s, new ErrorEvent(s, t));
  }

  /**
   * Obtain the unique identifier of the optimization process this task is
   * part of.
   * 
   * @return the unique identifier of the optimization process this task is
   *         part of
   */
  public Serializable getOptimizationId() {
    return this.m_job.m_state.m_id;
  }

  /**
   * Returns the randomizer for the jobs running in this host.
   * 
   * @return the randomizer for the jobs running in this host
   */
  public IRandomizer getRandomizer() {
    return this.m_randomizer;
  }
}
