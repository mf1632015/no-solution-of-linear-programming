/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-11-28
 * Creator          : Thomas Weise
 * Original Filename: test.junit.org.dgpf.machine.ll.vm.VMTest.java
 * Last modification: 2006-11-28
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.junit.org.dgpf.machine.ll.vm;

import junit.framework.JUnit4TestAdapter;

import org.dgpf.machine.ll.instructions.EIndirection;
import org.dgpf.machine.ll.instructions.arith.Compare;
import org.dgpf.machine.ll.vm.DefaultInstructionSet;
import org.dgpf.machine.ll.vm.ECondition;
import org.dgpf.machine.ll.vm.EFlag;
import org.dgpf.machine.ll.vm.InstructionSet;
import org.dgpf.machine.ll.vm.Program;
import org.dgpf.machine.ll.vm.VM;
import org.dgpf.machine.ll.vm.VMHost;
import org.junit.Assert;
import org.junit.Test;

import test.junit.TestBase;

/**
 * With this class we test virtual machines and everything around.
 * 
 * @author Thomas Weise
 */
public class VMTest extends TestBase {

  /**
   * create a new virtual machine host
   * 
   * @param maxMemSize
   *          the memory size
   * @param localSize
   *          the local size
   * @param stackSize
   *          the stack size
   * @param maxCallDepth
   *          the maximum call depth
   * @return the new vm host
   * @throws IllegalArgumentException
   *           if
   *           <code>memSize&lt;0 || stackSize&lt;0 || localSize &lt;0 | maxCallDepth&lt;0</code>
   */
  protected VMHost createVMHost(final int maxMemSize, final int localSize,
      final int stackSize, final int maxCallDepth) {
    return new VMHost(maxMemSize, localSize, stackSize, maxCallDepth);
  }

  /**
   * create a new virtual machine
   * 
   * @param host
   *          the host
   * @return the vm
   */
  protected VM createVM(final VMHost host) {
    return new VM(host);
  }

  /**
   * Check whether the vm host creation works ok.
   */
  @Test
  public void testCreateVMHost() {
    Assert.assertNotNull(this.createVMHost(10, 10, 10, 10));
    Assert.assertNotNull(this.createVMHost(1, 1, 1, 0));

    try {
      this.createVMHost(-1, 1, 1, 1);
      Assert.fail();
    } catch (IllegalArgumentException e) {//      
    }

    try {
      this.createVMHost(1, -1, 1, 1);
      Assert.fail();
    } catch (IllegalArgumentException e) {//      
    }

    try {
      this.createVMHost(1, 1, -1, 1);
      Assert.fail();
    } catch (IllegalArgumentException e) {//      
    }
  }

  /**
   * Check whether the vm creation works ok.
   */
  @Test
  @SuppressWarnings("unchecked")
  public void testCreateVM() {
    VMHost h;
    VM v;

    h = this.createVMHost(100, 100, 7, 22);
    Assert.assertNotNull(h);

    try {
      this.createVM(null);
      Assert.fail();
    } catch (NullPointerException npe) {//      
    }

    v = this.createVM(h);
    Assert.assertNotNull(v);

    String s;
    s = v.toString();
    Assert.assertNotNull(s);
    Assert.assertTrue(s.length() > 0);

    Assert.assertTrue(v.getMaxCallDepth() == h.getMaxCallDepth());
    Assert.assertTrue(v.getCallDepth() == 0);
    Assert.assertTrue(v.getCallErrors() == 0);
    Assert.assertTrue(v.getCurrentFrame() == null);
    Assert.assertTrue(v.getMemoryAccessErrors() == 0);
    Assert.assertTrue(v.getMissedInterrupts() == 0);
    Assert.assertTrue(v.getPassiveSteps() == 0);
    Assert.assertTrue(v.getPerformedInterrupts() == 0);
    Assert.assertTrue(v.getStackErrors() == 0);
    Assert.assertTrue(v.getStepCount() == 0);
    Assert.assertTrue(v.getVMHost() == h);
  }

  /**
   * Check whether the conditions are evaluated correctly.
   */
  @Test
  @SuppressWarnings("unchecked")
  public void testConditions() {
    int i;

    i = EFlag.compare(1, 0);
    Assert.assertTrue(ECondition.ABOVE.check(i));
    Assert.assertTrue(ECondition.GREATER.check(i));
    Assert.assertTrue(ECondition.ABOVE_OR_EQUAL.check(i));
    Assert.assertTrue(ECondition.GREATER_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.BELOW_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.LESS_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.BELOW.check(i));
    Assert.assertFalse(ECondition.LESS.check(i));

    i = EFlag.compare(0, -1);
    Assert.assertTrue(ECondition.GREATER.check(i));
    Assert.assertTrue(ECondition.GREATER_OR_EQUAL.check(i));
    Assert.assertTrue(ECondition.BELOW.check(i));
    Assert.assertTrue(ECondition.BELOW_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.LESS_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.LESS.check(i));
    Assert.assertFalse(ECondition.ABOVE.check(i));
    Assert.assertFalse(ECondition.ABOVE_OR_EQUAL.check(i));

    i = EFlag.compare(Integer.MAX_VALUE, 1);
    Assert.assertTrue(ECondition.ABOVE.check(i));
    Assert.assertTrue(ECondition.ABOVE_OR_EQUAL.check(i));
    Assert.assertTrue(ECondition.GREATER.check(i));
    Assert.assertTrue(ECondition.GREATER_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.BELOW.check(i));
    Assert.assertFalse(ECondition.BELOW_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.LESS.check(i));
    Assert.assertFalse(ECondition.LESS_OR_EQUAL.check(i));

    i = EFlag.compare(-1, -2);
    Assert.assertTrue(ECondition.GREATER.check(i));
    Assert.assertTrue(ECondition.GREATER_OR_EQUAL.check(i));
    Assert.assertTrue(ECondition.ABOVE.check(i));
    Assert.assertTrue(ECondition.ABOVE_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.LESS.check(i));
    Assert.assertFalse(ECondition.LESS_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.BELOW.check(i));
    Assert.assertFalse(ECondition.BELOW_OR_EQUAL.check(i));

    i = EFlag.compare(-1, 0);
    Assert.assertTrue(ECondition.LESS.check(i));
    Assert.assertTrue(ECondition.LESS_OR_EQUAL.check(i));
    Assert.assertTrue(ECondition.ABOVE.check(i));
    Assert.assertTrue(ECondition.ABOVE_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.GREATER.check(i));
    Assert.assertFalse(ECondition.GREATER_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.BELOW.check(i));
    Assert.assertFalse(ECondition.BELOW_OR_EQUAL.check(i));

    i = EFlag.compare(-2, -1);
    Assert.assertTrue(ECondition.LESS.check(i));
    Assert.assertTrue(ECondition.LESS_OR_EQUAL.check(i));
    Assert.assertTrue(ECondition.BELOW.check(i));
    Assert.assertTrue(ECondition.BELOW_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.GREATER.check(i));
    Assert.assertFalse(ECondition.GREATER_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.ABOVE.check(i));
    Assert.assertFalse(ECondition.ABOVE_OR_EQUAL.check(i));

    i = EFlag.compare(-2, -2);
    Assert.assertFalse(ECondition.LESS.check(i));
    Assert.assertTrue(ECondition.LESS_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.BELOW.check(i));
    Assert.assertTrue(ECondition.BELOW_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.GREATER.check(i));
    Assert.assertTrue(ECondition.GREATER_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.ABOVE.check(i));
    Assert.assertTrue(ECondition.ABOVE_OR_EQUAL.check(i));

    i = EFlag.compare(2, 2);
    Assert.assertFalse(ECondition.LESS.check(i));
    Assert.assertTrue(ECondition.LESS_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.BELOW.check(i));
    Assert.assertTrue(ECondition.BELOW_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.GREATER.check(i));
    Assert.assertTrue(ECondition.GREATER_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.ABOVE.check(i));
    Assert.assertTrue(ECondition.ABOVE_OR_EQUAL.check(i));

    i = EFlag.compare(Integer.MAX_VALUE, Integer.MAX_VALUE);
    Assert.assertFalse(ECondition.LESS.check(i));
    Assert.assertTrue(ECondition.LESS_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.BELOW.check(i));
    Assert.assertTrue(ECondition.BELOW_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.GREATER.check(i));
    Assert.assertTrue(ECondition.GREATER_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.ABOVE.check(i));
    Assert.assertTrue(ECondition.ABOVE_OR_EQUAL.check(i));

    i = EFlag.compare(Integer.MIN_VALUE, Integer.MIN_VALUE);
    Assert.assertFalse(ECondition.LESS.check(i));
    Assert.assertTrue(ECondition.LESS_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.BELOW.check(i));
    Assert.assertTrue(ECondition.BELOW_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.GREATER.check(i));
    Assert.assertTrue(ECondition.GREATER_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.ABOVE.check(i));
    Assert.assertTrue(ECondition.ABOVE_OR_EQUAL.check(i));

    i = EFlag.compare(Integer.MAX_VALUE, Integer.MIN_VALUE);
    Assert.assertFalse(ECondition.LESS.check(i));
    Assert.assertFalse(ECondition.LESS_OR_EQUAL.check(i));
    Assert.assertTrue(ECondition.BELOW.check(i));
    Assert.assertTrue(ECondition.BELOW_OR_EQUAL.check(i));
    Assert.assertTrue(ECondition.GREATER.check(i));
    Assert.assertTrue(ECondition.GREATER_OR_EQUAL.check(i));
    Assert.assertFalse(ECondition.ABOVE.check(i));
    Assert.assertFalse(ECondition.ABOVE_OR_EQUAL.check(i));
  }

  /**
   * Check whether the encoding works correctly
   */
  @Test
  @SuppressWarnings("unchecked")
  public void testEncoding() {
    int p, v;

    for (ECondition e : ECondition.values()) {
      p = ECondition.encode(e);
      Assert.assertSame(ECondition.decode(p), e);
    }

    for (EFlag e : EFlag.values()) {
      p = EFlag.encode(e);
      Assert.assertSame(EFlag.decode(p), e);
    }

    for (EIndirection e : EIndirection.values()) {
      if (e == EIndirection.CONSTANT)
        v = -1000;
      else
        v = 0;
      for (; v <= 1000; v++) {
        p = EIndirection.encode(e, v);
        Assert.assertSame(EIndirection.decodeIndirection(p), e);
        Assert.assertTrue(EIndirection.decodeIndex(e, p) == v);
      }
    }

  }

  /**
   * Check whether the program creation works correctly
   */
  @Test
  @SuppressWarnings("unchecked")
  public void testProgram() {
    InstructionSet<VM> is;
    int[][] code;
    Program<VM> p;
    VM vm;
    VMHost vh;

    is = DefaultInstructionSet.INSTRUCTION_SET;

    code = new int[][] { {//
        DefaultInstructionSet.ADD.getOpCode(),
        EIndirection.encode(EIndirection.GLOBAL, 5),
        EIndirection.encode(EIndirection.LOCAL, 5),// 
        3243254, DefaultInstructionSet.JUMP.getOpCode(),
        ECondition.encode(ECondition.GREATER),
        678,
        -1,//        
        284324, 324871747,
        3455,
        74837472, //    
        1234324, 4,
        1324871747,
        94837472, // /
        -234324, 90,
        -1324871747,
        -94837472,// /
        is.getInstance(Compare.class).getOpCode(),
        EIndirection.encode(EIndirection.GLOBAL, 5), 34,
        EIndirection.encode(EIndirection.LOCAL, 5),// 
    }

    };

    p = new Program<VM>(is, code);
    Assert.assertNotNull(p.toString());

    vh = this.createVMHost(10, 10, 10, 10);
    vm = this.createVM(vh);
    vm.init(p);
    Assert.assertNotNull(vm.toString());
  }

  /**
   * Perform all tests.
   */
  @Override
  public void allTests() {
    this.testCreateVMHost();
    this.testCreateVM();
    this.testEncoding();
  }

  /**
   * Create a test suitable for a test suite.
   * 
   * @return A test suitable for a test suite.
   */
  public static final junit.framework.Test vmTestSuite() {
    return new JUnit4TestAdapter(VMTest.class);
  }
}
