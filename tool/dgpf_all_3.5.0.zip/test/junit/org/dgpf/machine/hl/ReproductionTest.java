/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-11-22 06:18:01
 * Creator          : Thomas Weise
 * Original Filename: test.junit.org.dgpf.machine.hl.ReproductionTest.java
 * Last modification: 2006-11-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.junit.org.dgpf.machine.hl;

import junit.framework.JUnit4TestAdapter;

import org.dgpf.machine.hl.DefaultLanguage;
import org.junit.Assert;
import org.junit.Test;
import org.sigoa.refimpl.genomes.tree.INodeFactory;
import org.sigoa.refimpl.genomes.tree.Node;
import org.sigoa.refimpl.genomes.tree.reproduction.NodeFactorySet;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeDeleteMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeExchangeCrossover;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeInsertMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeReplaceMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.TreeCreator;
import org.sigoa.refimpl.stoch.Randomizer;
import org.sigoa.spec.go.reproduction.ICreator;
import org.sigoa.spec.go.reproduction.IMutator;
import org.sigoa.spec.stoch.IRandomizer;

import test.junit.TestBase;

/**
 * The test of the standard tree reproduction routines.
 * 
 * @author Thomas Weise
 */
public class ReproductionTest extends TestBase {

  /**
   * test the node for errors.
   * 
   * @param fs
   *          the node factory set
   * @param n
   *          the node
   */
  private static final void testDeep(final NodeFactorySet fs, final Node n) {

    INodeFactory f1, f2;

    Assert.assertNotNull(n);
    Assert.assertNotNull(n.toString());

    f1 = fs.getRootFactory();
    f2 = n.getFactory();

    Assert.assertTrue(((f1 == null) && (f2 == null)) || (f1 == f2));

    doTestDeep(n);
  }

  /**
   * test the node for errors.
   * 
   * @param n
   *          the node
   */
  private static final void doTestDeep(final Node n) {
    int j;
    Node v;
    Assert.assertNotNull(n);
    j = n.size();
    Assert.assertTrue((j > 0) ^ (n.isTerminal()));
    Assert.assertTrue(j>=n.getFactory().getMinChildren());
    Assert.assertTrue(j<=n.getFactory().getMaxChildren());
    for (--j; j >= 0; j--) {
      Assert.assertNotNull(v = n.get(j));
      Assert.assertTrue(n.getFactory().isChildAllowed(v.getClass(), j));
      doTestDeep(v);
    }
  }

  /**
   * Test the crossover routines.
   */
  @Test
  public void testSubTreeExchangeCrossover() {
    ICreator<Node> creator;
    Node c1, c2, c3;
    int i;
    IRandomizer r;

    r = new Randomizer();
    creator = getTreeCreator();
    for (i = 1000; i >= 0; i--) {
      c1 = creator.create(r);
      c2 = creator.create(r);
      testDeep(DefaultLanguage.DEFAULT_LANGUAGE, c1);
      testDeep(DefaultLanguage.DEFAULT_LANGUAGE, c2);
      c3 = SubTreeExchangeCrossover.SUB_TREE_EXCHANGE_CROSSOVER.crossover(
          c1, c2, r);
      testDeep(DefaultLanguage.DEFAULT_LANGUAGE, c3);
      c1 = null;
      c2 = null;
      c3 = null;
      System.gc();
    }

  }

  /**
   * Test the sub tree replace mutator
   */
  @Test
  public void testSubTreeReplaceMutator() {
    TreeCreator creator, cx;
    IMutator<Node> mut;
    Node c1, c2;
    int i;
    IRandomizer r;

    r = new Randomizer();
    creator = getTreeCreator();
    cx = new TreeCreator(DefaultLanguage.DEFAULT_LANGUAGE, 2, 0.2d);
    mut = new SubTreeReplaceMutator(cx);

    for (i = 1000; i >= 0; i--) {
      c1 = creator.create(r);
      testDeep(DefaultLanguage.DEFAULT_LANGUAGE, c1);
      c2 = mut.mutate(c1, r);
      testDeep(DefaultLanguage.DEFAULT_LANGUAGE, c2);
      c1 = null;
      c2 = null;
      System.gc();
    }

  }

  /**
   * Test the sub tree insert mutator
   */
  @Test
  public void testSubTreeInsertMutator() {
    TreeCreator creator, cx;
    IMutator<Node> mut;
    Node c1, c2;
    int i;
    IRandomizer r;

    r = new Randomizer();
    creator = getTreeCreator();
    cx = new TreeCreator(DefaultLanguage.DEFAULT_LANGUAGE, 2, 0.2d);
    mut = new SubTreeInsertMutator(cx);

    for (i = 1000; i >= 0; i--) {
      c1 = creator.create(r);
      testDeep(DefaultLanguage.DEFAULT_LANGUAGE, c1);
      c2 = mut.mutate(c1, r);
      testDeep(DefaultLanguage.DEFAULT_LANGUAGE, c2);
      c1 = null;
      c2 = null;
      System.gc();
    }

  }

  /**
   * Test the sub tree mutator
   */
  @Test
  public void testSubTreeMutator() {
    TreeCreator creator;
    IMutator<Node> mut;
    Node c1, c2;
    int i;
    IRandomizer r;

    r = new Randomizer();
    creator = getTreeCreator();
    mut = SubTreeMutator.SUB_TREE_MUTATOR;

    for (i = 1000; i >= 0; i--) {
      c1 = creator.create(r);
      testDeep(DefaultLanguage.DEFAULT_LANGUAGE, c1);
      c2 = mut.mutate(c1, r);
      testDeep(DefaultLanguage.DEFAULT_LANGUAGE, c2);
      c1 = null;
      c2 = null;
      System.gc();
    }

  }

  /**
   * get the tree creator
   * 
   * @return the tree creator
   */
  private TreeCreator getTreeCreator() {
    return new TreeCreator(DefaultLanguage.DEFAULT_LANGUAGE, 10, 0.2d);
  }

  /**
   * Test the sub tree delete mutator
   */
  @Test
  public void testSubTreeDeleteMutator() {
    ICreator<Node> creator;
    Node c1, c2;
    int i;
    IRandomizer r;

    r = new Randomizer();
    creator = getTreeCreator();
    for (i = 1000; i >= 0; i--) {
      c1 = creator.create(r);
      testDeep(DefaultLanguage.DEFAULT_LANGUAGE, c1);
      c2 = SubTreeDeleteMutator.SUB_TREE_DELETE_MUTATOR.mutate(c1, r);
      testDeep(DefaultLanguage.DEFAULT_LANGUAGE, c2);
      c1 = null;
      c2 = null;
      System.gc();
    }

  }

  /**
   * Test the creation routines.
   */
  @Test
  public void testCreation() {
    ICreator<Node> creator;
    Node c;
    int i, k;
    IRandomizer r;

    r = new Randomizer();

    for (k = 10; k >= 0; k--) {
      creator = new TreeCreator(DefaultLanguage.DEFAULT_LANGUAGE, 2 + r
          .nextInt(5), 0.2d);

      for (i = 100; i >= 0; i--) {
        c = creator.create(r);
        testDeep(DefaultLanguage.DEFAULT_LANGUAGE, c);
        c = null;
        System.gc();
      }
    }
  }

  /**
   * Perform all tests.
   */
  @Override
  public void allTests() {
    this.testCreation();
    this.testSubTreeDeleteMutator();
    this.testSubTreeExchangeCrossover();
    this.testSubTreeReplaceMutator();
    this.testSubTreeInsertMutator();
  }

  /**
   * Create a test suitable for a test suite.
   * 
   * @return A test suitable for a test suite.
   */
  public static final junit.framework.Test suite() {
    return new JUnit4TestAdapter(ReproductionTest.class);
  }
}
