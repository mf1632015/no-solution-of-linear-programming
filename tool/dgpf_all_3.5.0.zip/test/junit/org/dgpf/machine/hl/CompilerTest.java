/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-11-22 06:18:01
 * Creator          : Thomas Weise
 * Original Filename: test.junit.org.dgpf.machine.hl.CompilerTest.java
 * Last modification: 2006-11-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.junit.org.dgpf.machine.hl;

import junit.framework.JUnit4TestAdapter;

import org.dgpf.machine.hl.Construct;
import org.dgpf.machine.hl.DefaultLanguage;
import org.dgpf.machine.hl.Function;
import org.dgpf.machine.hl.compiler.Compiler;
import org.dgpf.machine.hl.constructs.expressions.Add;
import org.dgpf.machine.hl.constructs.expressions.Comparison;
import org.dgpf.machine.hl.constructs.expressions.Constant;
import org.dgpf.machine.hl.constructs.expressions.EComparison;
import org.dgpf.machine.hl.constructs.expressions.Load;
import org.dgpf.machine.hl.constructs.expressions.Mul;
import org.dgpf.machine.hl.constructs.expressions.Sub;
import org.dgpf.machine.hl.constructs.instructions.DeclVar;
import org.dgpf.machine.hl.constructs.instructions.For;
import org.dgpf.machine.hl.constructs.instructions.IfThenElse;
import org.dgpf.machine.hl.constructs.instructions.Store;
import org.dgpf.machine.hl.constructs.instructions.While;
import org.dgpf.machine.ll.instructions.EIndirection;
import org.dgpf.machine.ll.vm.ECondition;
import org.dgpf.machine.ll.vm.Program;
import org.dgpf.machine.ll.vm.VM;
import org.junit.Assert;
import org.junit.Test;
import org.sigoa.refimpl.genomes.tree.Node;
import org.sigoa.refimpl.genomes.tree.reproduction.TreeCreator;
import org.sigoa.refimpl.stoch.Randomizer;
import org.sigoa.spec.go.reproduction.ICreator;
import org.sigoa.spec.stoch.IRandomizer;

import test.junit.TestBase;

/**
 * The test of the standard tree reproduction routines.
 * 
 * @author Thomas Weise
 */
public class CompilerTest extends TestBase {

  /**
   * Test the crossover routines.
   */
  @Test
  public void testCompiler() {
    Construct n;
    Compiler c;
    Program<VM> pr;

    c = new Compiler(null);

    n = new org.dgpf.machine.hl.Program(//
        new Node[] {//

            new Function(//            
                new Node[] {//
                new IfThenElse(new Node[] {//
                        new Comparison(EComparison.A,//
                            new Node[] { new Constant(1), new Load(3) }), //

                        new Store(1, new Node[] {//
                            new Add(new Node[] {
                                new Constant(1),
                                new Mul(new Node[] { new Constant(2),
                                    new Constant(3) }) }) //
                            }), //

                        new Store(1, new Node[] {//
                            new Sub(new Node[] {
                                new Constant(1),
                                new Mul(new Node[] { new Constant(2),
                                    new Constant(3) }) }) //
                            }) //
                    }) //
                }), //   

            new DeclVar(EIndirection.GLOBAL, -1),
            new Function(//            
                new Node[] {//
                    new Store(1, new Node[] {//
                        new Comparison(EComparison.A,//
                            new Node[] { new Constant(1), new Load(3) }) //
                        }), //   

                    new Store(1, new Node[] {//
                        new Add(new Node[] {
                            new Constant(1),
                            new Mul(new Node[] { new Constant(2),
                                new Constant(3) }) }) //
                        }) //
                }), //

            new Function(//            
                new Node[] {//
                new While(new Node[] {//
                        new Comparison(EComparison.A,//
                            new Node[] { new Constant(1), new Load(3) }), //

                        new Store(1, new Node[] {//
                            new Add(new Node[] {
                                new Constant(1),
                                new Mul(new Node[] { new Constant(2),
                                    new Constant(3) }) }) //
                            }) //
                    }) //
                }), //           

            new Function(//            
                new Node[] {//
                new For(ECondition.GREATER, new Node[] {//
                    // new Div(new Node[]{
                    new Constant(22), new Constant(3),
                    // }),
                        // new Mul(new Node[]{
                        // new Constant(2),
                        // new Load(3)
                        // }),
                        new Store(1, new Node[] {//
                            new Add(new Node[] {
                                new Constant(1),
                                new Mul(new Node[] { new Constant(2),
                                    new Constant(3) }) }) //
                            }) //
                    }) //
                }) //  
        }//
    );

    n.compile(c);
    Assert.assertNotNull(n.toString());

    // c.beginFunction(1);
    // c.addInstruction(DefaultInstructionSet.ADD.getOpCode(), EIndirection
    // .encode(EIndirection.LOCAL, 1), EIndirection.encode(
    // EIndirection.GLOBAL, 2), EIndirection.encode(
    // EIndirection.LOCAL_LOCAL, 3));
    // c.endFunction();

    pr = c.getProgram();
    Assert.assertNotNull(pr.toString());
  }

  /**
   * Test the crossover routines.
   */
  @Test
  public void testRndCompiler() {
    ICreator<Node> creator;
    Node c;
    int i;
    IRandomizer r;
    Compiler cm;
    Program<VM> pr;

    r = new Randomizer();
    cm = new Compiler(null);
    creator = getTreeCreator();
    for (i = 1000; i >= 0; i--) {
      c = creator.create(r);
      Assert.assertNotNull(c.toString());
      ((Construct) c).compile(cm);
      pr = cm.getProgram();
      cm.clear();

      Assert.assertNotNull(pr.toString());

      pr = null;
      System.gc();
    }

  }

  /**
   * get the tree creator
   * 
   * @return the tree creator
   */
  private TreeCreator getTreeCreator() {
    return new TreeCreator(DefaultLanguage.DEFAULT_LANGUAGE, 10, 0.2d);
  }

  /**
   * Perform all tests.
   */
  @Override
  public void allTests() {
    this.testCompiler();
    this.testRndCompiler();
  }

  /**
   * Create a test suitable for a test suite.
   * 
   * @return A test suitable for a test suite.
   */
  public static final junit.framework.Test suite() {
    return new JUnit4TestAdapter(CompilerTest.class);
  }
}
