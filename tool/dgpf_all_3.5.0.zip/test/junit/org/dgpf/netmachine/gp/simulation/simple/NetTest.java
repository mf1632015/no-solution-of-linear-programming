/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-11-28
 * Creator          : Thomas Weise
 * Original Filename: test.junit.org.dgpf.netmachine.gp.simulation.simple.NetTest.java
 * Last modification: 2006-11-28
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.junit.org.dgpf.netmachine.gp.simulation.simple;

import junit.framework.JUnit4TestAdapter;

import org.dgpf.machine.hl.compiler.Compiler;
import org.dgpf.machine.ll.instructions.EIndirection;
import org.dgpf.machine.ll.programBuilder.Variable;
import org.dgpf.machine.ll.vm.Program;
import org.dgpf.netmachine.gp.simulation.simple.SimpleNetwork;
import org.dgpf.netmachine.ll.vm.DefaultNetInstructionSet;
import org.dgpf.netmachine.ll.vm.NetVM;
import org.dgpf.netmachine.ll.vm.NetVMParameters;
import org.junit.Test;

import test.gp.netvm.cs.CSUtils;
import test.junit.TestBase;

/**
 * With this class we test a network of virtual machines and everything
 * around.
 * 
 * @author Thomas Weise
 */
public class NetTest extends TestBase {

  /**
   * test a program
   * 
   * @param prog
   *          the program
   */
  private static final void testProgram(final Program<NetVM> prog) {
    NetVMParameters parameters;
    SimpleNetwork sn;
    int i, j;

    parameters = new NetVMParameters(//
        100,// global size
        100,// lobal size
        30,// stack size
        20,// call depth
        CSUtils.VM_COUNT// the vm count
    );

    sn = new SimpleNetwork(parameters, null);
    for (j = 10; j >= 0; j--) {
      sn.beginSimulation(prog);

      for (i = 100; i >= 0; i--) {
        if (!(sn.simulate(1000)))
          break;
      }

      sn.endSimulation();
    }
  }

  /**
   * Check whether the network works correctly
   */
  @Test
  @SuppressWarnings("unchecked")
  public void testNet() {
    Compiler c;
    Variable v1, v2, v3, v4;

    c = new Compiler(DefaultNetInstructionSet.INSTRUCTION_SET);

    c.beginFunction(0);
    c.beginConstruct();
    v1 = c.allocateVariable(EIndirection.LOCAL, 0, false);
    v2 = c.allocateVariable(EIndirection.LOCAL, 0, false);
    v3 = c.allocateVariable(EIndirection.LOCAL, 0, false);
    c.move(v1, Variable.FFFF);
    c.move(v2, Variable.ONE);
    c.add(v3, v2, v1);
    c.move(Variable.TOP_OF_STACK, v1);
    c.move(Variable.TOP_OF_STACK, v2);
    c.move(Variable.TOP_OF_STACK, v3);
    c.addInstruction(DefaultNetInstructionSet.ID, v1.encode(), 0, 0);
    c.move(Variable.TOP_OF_STACK, v1);
    c.addInstruction(DefaultNetInstructionSet.BROADCAST, 1, 0, 0);
    c.endConstruct();

    c.beginFunction(0);
    c.beginConstruct();
    v1 = c.allocateVariable(EIndirection.LOCAL, 0, false);
    v2 = c.allocateVariable(EIndirection.LOCAL, 0, false);
    v3 = c.allocateVariable(EIndirection.LOCAL, 0, false);
    v4 = c.allocateVariable(EIndirection.LOCAL, 0, false);
    c.move(Variable.TOP_OF_STACK, v1);
    c.move(Variable.TOP_OF_STACK, v2);
    c.move(Variable.TOP_OF_STACK, v3);
    c.move(Variable.TOP_OF_STACK, v4);
    c.addInstruction(DefaultNetInstructionSet.BROADCAST, 2, 0, 0);
    c.endConstruct();

    c.beginFunction(0);
    c.beginConstruct();
    v1 = c.allocateVariable(EIndirection.LOCAL, 0, false);
    v2 = c.allocateVariable(EIndirection.LOCAL, 0, false);
    v3 = c.allocateVariable(EIndirection.LOCAL, 0, false);
    v4 = c.allocateVariable(EIndirection.LOCAL, 0, false);
    c.add(v1, v2, v3);
    c.add(v1, v1, v4);
    c.endConstruct();

    testProgram(((Program) (c.getProgram())));
  }

  /**
   * Perform all tests.
   */
  @Override
  public void allTests() {
    this.testNet();
  }

  /**
   * Create a test suitable for a test suite.
   * 
   * @return A test suitable for a test suite.
   */
  public static final junit.framework.Test suite() {
    return new JUnit4TestAdapter(NetTest.class);
  }
}
