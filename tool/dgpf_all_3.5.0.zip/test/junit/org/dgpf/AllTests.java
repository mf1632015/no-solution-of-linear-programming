/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-11-22 06:18:01
 * Creator          : Thomas Weise
 * Original Filename: test.junit.org.dgpf.AllTests.java
 * Last modification: 2006-11-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.junit.org.dgpf;

import junit.framework.Test;
import junit.framework.TestSuite;
import test.junit.org.dgpf.machine.hl.ReproductionTest;
import test.junit.org.dgpf.netmachine.gp.simulation.simple.NetTest;

/**
 * The test suite.
 * 
 * @author Thomas Weise
 */
public class AllTests {

  /**
   * Create the test suite.
   * 
   * @return The test suite.
   */
  public static final Test suite() {
    TestSuite suite = new TestSuite("Test for org.dgpf");//$NON-NLS-1$
    // $JUnit-BEGIN$

    suite.addTest(test.junit.org.dgpf.machine.ll.vm.VMTest.vmTestSuite());
    suite.addTest(test.junit.org.dgpf.machine.hl.ReproductionTest.suite());
    suite.addTest(test.junit.org.dgpf.machine.hl.CompilerTest.suite());
    suite.addTest(NetTest.suite());

    suite.addTest(ReproductionTest.suite());

    // $JUnit-END$
    return suite;
  }

}
