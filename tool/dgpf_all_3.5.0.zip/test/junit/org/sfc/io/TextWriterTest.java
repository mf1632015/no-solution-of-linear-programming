/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-31
 * Creator          : Thomas Weise
 * Original Filename: test.junit.org.sfc.io.TextWriterTest.java
 * Last modification: 2006-12-31
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.junit.org.sfc.io;

import java.io.StringWriter;
import java.io.Writer;

import junit.framework.JUnit4TestAdapter;

import org.junit.Assert;
import org.junit.Test;
import org.sfc.io.TextWriter;

import test.junit.TestBase;

/**
 * A test for the text writer class.
 * 
 * @author Thomas Weise
 */
public class TextWriterTest extends TestBase {

  /**
   * Create a new text writer.
   * 
   * @param w
   *          the source writer
   * @return the textwriter
   */
  protected TextWriter createTextWriter(final Writer w) {
    return new TextWriter(w);
  }

  /**
   * Check whether the text writer creation works ok.
   */
  @Test
  public void testCreate() {
    Assert.assertNotNull(this.createTextWriter(new StringWriter()));
  }

  /**
   * Check whether the text writer functions work ok.
   */
  @Test
  public void testFunctionality() {
    StringWriter w;
    TextWriter t;
    String s;
    CharSequence cs;
    long z;

    w = new StringWriter();
    t = this.createTextWriter(w);

    z = System.currentTimeMillis();
    t.append('h');
    cs = "allo"; //$NON-NLS-1$
    t.append(cs);
    t.append(cs, 1, 2);

    t.ensureNewLine();
    t.flush();
    t.newLine();
    t.setCSVSeparator(";"); //$NON-NLS-1$
    t.writeCSVSeparator();
    t.setLocalizeNumbers(true);
    t.write(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 });
    t.ensureNewLine();
    t.formatOn();
    t.incIndent();
    t.write(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 });
    t.decIndent();
    t.ensureNewLine();
    t.write(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 });
    t.incIndent();
    t.ensureNewLine();
    t.write(new char[] {'H', 'a', 'l', 'l', 'o', '!'});
   t.ensureNewLine();
   t.incIndent();
   t.write(' ');
   t.write("it is me!"); //$NON-NLS-1$
   t.decIndent();
   t.write(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8,9,10 },2,3);
   t.ensureNewLine();
   t.write("me again! me!", 0, 9); //$NON-NLS-1$
   t.decIndent();
   t.ensureNewLine();
   t.writeBase64(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8,9,10 },2,3);
   t.writeBoolean(true);
   t.writeBoolean2(false);
   t.incIndent();
   t.ensureNewLine();
   t.writeByte(10);
   t.ensureNewLine();
   t.formatOff();
   t.writeBytes("hallo"); //$NON-NLS-1$
   t.writeChar('t');
   t.writeChars("hallo"); //$NON-NLS-1$
   t.writeDouble(23434.34343e34d);
   t.newLine();
   t.ensureNewLine();
   t.writeDouble(3242342344.4);
   t.ensureNewLine();
   t.writeInt(242482374);
   t.ensureNewLine();
   t.setLocalizeNumbers(false);
   t.formatOn();
   t.ensureNewLine();
   t.writeDouble(3242342344.4);
   t.ensureNewLine();
   t.writeInt(242482374);
   t.ensureNewLine();
   t.incIndent();
   t.writeTime(System.currentTimeMillis(), false);
   t.newLine();
   t.writeTime(100000000*(System.currentTimeMillis()-z+1), true);
   t.ensureNewLine();
   
   t.flush();
   s = w.toString();
   t.newLine();
   t.newLine();
   t.write("========== Formatted COPY ========="); //$NON-NLS-1$
   t.newLine();
   t.newLine();
   t.incIndent();
   t.write(s);
   
   t.formatOff();
   t.ensureNewLine();
   t.newLine();
   t.writeIsoTime(System.currentTimeMillis(),false);
   t.newLine();
   t.writeIsoTime(100000000*(System.currentTimeMillis()-z+1)+7, true);
   
    t.release();
    s = w.toString();
    Assert.assertNotNull(s);
    Assert.assertNull(t.getLastIOException());
  }

  /**
   * Perform all tests.
   */
  @Override
  public void allTests() {
    this.testCreate();
    this.testFunctionality();    
  }

  /**
   * Create a test suitable for a test suite.
   * 
   * @return A test suitable for a test suite.
   */
  public static final junit.framework.Test textWriterSuite() {
    return new JUnit4TestAdapter(TextWriterTest.class);
  }
}
