/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-31
 * Creator          : Thomas Weise
 * Original Filename: test.junit.org.sfc.io.SAXWriterTest.java
 * Last modification: 2006-12-31
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.junit.org.sfc.xml.sax;

import java.io.StringWriter;
import java.io.Writer;

import junit.framework.JUnit4TestAdapter;

import org.junit.Assert;
import org.junit.Test;
import org.sfc.io.TextWriter;
import org.sfc.xml.sax.SAXWriter;

import test.junit.org.sfc.io.TextWriterTest;

/**
 * A test for the sax writer class.
 * 
 * @author Thomas Weise
 */
public class SAXWriterTest extends TextWriterTest {

  /**
   * Create a new sax writer.
   * 
   * @param w
   *          the source writer
   * @return the textwriter
   */
  protected SAXWriter createSAXWriter(final Writer w) {
    return new SAXWriter(w);
  }

  /**
   * Create a new text writer.
   * 
   * @param w
   *          the source writer
   * @return the textwriter
   */
  @Override
  protected TextWriter createTextWriter(final Writer w) {
    return this.createSAXWriter(w);
  }

  /**
   * Check whether the sax writer creation works ok.
   */
  @Test
  public void testSAXCreate() {
    Assert.assertNotNull(this.createSAXWriter(new StringWriter()));
  }

  /**
   * build a document
   * 
   *          @return a string containing a document
   */
  private final String buildDocument2() {
    StringWriter w;
    SAXWriter t;
    
    w = new StringWriter();
    t = this.createSAXWriter(w);
    t.formatOn();
    t.startDocument();
    

    t.startElement("namespace", //$NON-NLS-1$
        "hallo"); //$NON-NLS-1$
    t.ensureNewLine();
    t.writeIsoTime(System.currentTimeMillis(), false);
    t.ensureNewLine();
    t.endElement();   
    t.release();
    return w.toString();
  }
  
  
/**
   * build a document
   * 
   * @param t
   *          the sax writer to use
   */
  private final void buildDocument(final SAXWriter t) {
    t.startDocument();

    t.startDTD("DocumentElement", //$NON-NLS-1$
        "pid", //$NON-NLS-1$
        "sysid"); //$NON-NLS-1$
    t.elementDecl("emptyElement", //$NON-NLS-1$
        "mymodel"); //$NON-NLS-1$
    t.attributeDecl("emptyElement", //$NON-NLS-1$
        "attributeName", //$NON-NLS-1$
        "type", //$NON-NLS-1$
        "mode", //$NON-NLS-1$
        "value"); //$NON-NLS-1$
    t.endDTD();

    t.processingInstruction("hallo", //$NON-NLS-1$
        "data"); //$NON-NLS-1$

    t.startElement("RootNamespace", //$NON-NLS-1$
        "DocumentElement", //$NON-NLS-1$
        "DocumentElement",null); //$NON-NLS-1$
    t.startElement("RootNamespace", //$NON-NLS-1$
        "DocumentElement2", //$NON-NLS-1$
        "DocumentElement2",null); //$NON-NLS-1$

    t.startElement("http://www.it-weise.de/documents/index.php#DGPFa", //$NON-NLS-1$
        "DocumentElement3", //$NON-NLS-1$
        "DocumentElement3",null); //$NON-NLS-1$
    
    t.startElement("emptyElement"); //$NON-NLS-1$
    t.endElement();

    t.startElement("elementMitWasDrin"); //$NON-NLS-1$
    t.startCDATA();
    t.writeTime(204324, true);
    t.endCDATA();
    t.write("element text: blabla"); //$NON-NLS-1$
    t.comment(
        "Hallo Welt. Ich bin ein Kommentar.".toCharArray(), 0, 50 - 16); //$NON-NLS-1$

    t.startElement("mynamespace", //$NON-NLS-1$
        "elementWithNamespace"); //$NON-NLS-1$
    t.attribute("attribut1", //$NON-NLS-1$
        "wert1"); //$NON-NLS-1$
    t.attribute("mynamespace", //$NON-NLS-1$
        "attributWithNamespace", //$NON-NLS-1$
        "valu���0#e"); //$NON-NLS-1$
    t.writeLocalizedDouble(2323.34);

    t.endElement();
    t.endElement();
    t.endElement();
    t.write("���"); //$NON-NLS-1$
    t.ensureNewLine();
    t.write("<>#&"); //$NON-NLS-1$
    
    t.startElement("AttrElem"); //$NON-NLS-1$
    t.attribute("document", this.buildDocument2()); //$NON-NLS-1$
    t.endElement();
  }

  /**
   * Check whether the sax writer functions work ok.
   */
  @Test
  public void testSAXFunctionality() {
    StringWriter w;
    SAXWriter t;
    String s;
    int i;

    for (i = 0; i <= 1; i++) {

      w = new StringWriter();
      t = this.createSAXWriter(w);

      if (i > 0)
        t.formatOn();

      this.buildDocument(t);

      t.release();
      s = w.toString();
      Assert.assertNotNull(s);
      Assert.assertNull(t.getLastIOException());
    }
  }

  /**
   * Perform all tests.
   */
  @Override
  public void allTests() {
    super.allTests();
    this.testSAXCreate();
    this.testSAXFunctionality();
  }

  /**
   * Create a test suitable for a test suite.
   * 
   * @return A test suitable for a test suite.
   */
  public static final junit.framework.Test saxWriterSuite() {
    return new JUnit4TestAdapter(SAXWriterTest.class);
  }
}
