/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-22
 * Creator          : Thomas Weise
 * Original Filename: test.gp.vm.prime.PrimeUtils.java
 * Last modification: 2006-12-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.gp.vm.prime;

import java.util.List;

import org.dgpf.machine.gp.objectives.MinimizeCallErrors;
import org.dgpf.machine.gp.objectives.MinimizeCodeSize;
import org.dgpf.machine.gp.objectives.MinimizeMemoryErrors;
import org.dgpf.machine.gp.objectives.MinimizeStackErrors;
import org.dgpf.machine.gp.objectives.MinimizeSteps;
import org.dgpf.machine.hl.DefaultLanguage;
import org.dgpf.machine.ll.vm.Program;
import org.dgpf.machine.ll.vm.VM;
import org.sfc.collections.CollectionUtils;
import org.sfc.utils.ErrorUtils;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeDeleteMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeInsertMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeLiftMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeReplaceMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeSinkMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.TreeCreator;
import org.sigoa.refimpl.go.comparators.TieredParetoComparator;
import org.sigoa.refimpl.go.reproduction.IterativeMultiMutator;
import org.sigoa.spec.go.IComparator;
import org.sigoa.spec.go.objectives.IObjectiveFunction;
import org.sigoa.spec.go.reproduction.IMutator;
import org.sigoa.spec.simulation.ISimulation;

/**
 * This class provides utils form primes.
 * 
 * @author Thomas Weise
 */
public final class PrimeUtils {

  /**
   * the simulation steps granted.
   */
  public static/* final */long SIMULATION_STEPS = 10000;

  /**
   * the count of tests performed
   */
  public static/* final */int TEST_COUNT = 600;

  /**
   * the highest possible integer prime
   */
  public static final int MAX_PRIME = 2147483629;// getMaxPrime();

  /**
   * The sqare root of the maximum integer.
   */
  private static final int SQRT_MAX_INT = ((int) (Math
      .sqrt(Integer.MAX_VALUE)));

  /**
   * The sqare root of the maximum integer threshold.
   */
  private static final int SQRT_MAX_INT_TH = (SQRT_MAX_INT * SQRT_MAX_INT);

  /**
   * the objectives
   */
  public static final List<IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>> TEST = CollectionUtils
      .createList();

  /**
   * the internally used sub-tree creator
   */
  private static final TreeCreator SUB_TREE_CREATOR = new TreeCreator(
      DefaultLanguage.DEFAULT_LANGUAGE, 3, 0.35d);

  /**
   * the default mutator
   */
  @SuppressWarnings("unchecked")
  public static final IMutator<org.dgpf.machine.hl.Program> MUTATOR = new IterativeMultiMutator<org.dgpf.machine.hl.Program>(
      new IMutator[] {// 
      SubTreeDeleteMutator.SUB_TREE_DELETE_MUTATOR,
          new SubTreeInsertMutator(SUB_TREE_CREATOR),
          new SubTreeReplaceMutator(SUB_TREE_CREATOR),
          SubTreeMutator.SUB_TREE_MUTATOR, 
          SubTreeLiftMutator.SUB_TREE_LIFT_MUTATOR,
          new SubTreeSinkMutator(DefaultLanguage.DEFAULT_LANGUAGE)},// 
      new double[] { 3, 1, 1, 1, 1, 1});

  /**
   * init
   */
  @SuppressWarnings("unchecked")
  private static final void init() {
    IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>> x;
    IObjectiveFunction<?, ?, ?, ?> y;

    // functional
    y = new DifferentPrimesObjectiveFunction();
    x = (IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>) (y);
    TEST.add(x);

    
    //non-f 1
    y = new DifferentNumbersObjectiveFunction();
    x = (IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>) (y);
    TEST.add(x);

    // non-functional 0
    //
    // y = new DifferentNumbersObjectiveFunction();
    // x = (IObjectiveFunction<Program<VM>, ?, ?,
    // ISimulation<Program<VM>>>) (y);
    // TEST.add(x);

    // non-functional 1

    y = MinimizeSteps.MINIMIZE_STEPS;
    x = (IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>) (y);
    TEST.add(x);

    y = MinimizeCodeSize.MINIMIZE_CODE_SIZE;
    x = (IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>) (y);
    TEST.add(x);

    // non-functional 2

    y = MinimizeMemoryErrors.MINIMIZE_MEMORY_ERRORS;
    x = (IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>) (y);
    TEST.add(x);

    y = MinimizeCallErrors.MINIMIZE_CALL_ERRORS;
    x = (IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>) (y);
    TEST.add(x);

    y = MinimizeStackErrors.MINIMIZE_STACK_ERRORS;
    x = (IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>) (y);
    TEST.add(x);

  }

  static {
    init();
  }

  /**
   * the shared comparator
   */
  public static final IComparator COMPARATOR = new TieredParetoComparator(
      new int[] { 1, 4, 100 });

  /**
   * the forbidden constructor
   */
  private PrimeUtils() {
    ErrorUtils.doNotCall();
  }

  /**
   * check whether a given number is prime or not
   * 
   * @param num
   *          the number to check
   * @return <code>true</code> if it is, <code>false</code> otherwise
   */
  public static final boolean isPrime(final int num) {
    int i, m;

    if (num <= 1)
      return false;
    if (num <= 3)
      return true;

    if ((num & 1) == 0)
      return false;

    if (num > MAX_PRIME)
      return false;

    i = 3;

    if (num < SQRT_MAX_INT_TH) {
      do {
        if ((num % i) <= 0)
          return false;
        i += 2;
      } while ((i * i) < num);
    } else {
      m = SQRT_MAX_INT;
      do {
        if ((num % i) <= 0)
          return false;
        i += 2;
      } while (i <= m);
    }

    return true;
  }

}
