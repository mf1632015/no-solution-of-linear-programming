/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-22
 * Creator          : Thomas Weise
 * Original Filename: test.gp.vm.prime.DifferentPrimesObjectiveFunction.java
 * Last modification: 2006-12-22
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.gp.vm.prime;

import java.io.Serializable;

import org.dgpf.machine.gp.simulation.VMSimulation;
import org.dgpf.machine.ll.vm.Program;
import org.dgpf.machine.ll.vm.VM;
import org.sigoa.refimpl.go.objectives.ObjectiveFunction;
import org.sigoa.refimpl.go.objectives.ObjectiveState;
import org.sigoa.spec.go.OptimizationUtils;

/**
 * Warning! this objective function only works with one single thread!!
 * This objective function measures how many different primes have been
 * found.
 * 
 * @author Thomas Weise
 */
public class DifferentHighPrimesObjectiveFunction
    extends
    ObjectiveFunction<Program<VM>, ObjectiveState, PrimeListStaticData, VMSimulation> {
  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * instantiate now!
   */
  public DifferentHighPrimesObjectiveFunction() {
    super();
  }

  /**
   * This method is called by the objective function in order to determine
   * the final objective value. The evaluator may perform multiple
   * simulations, where the objective function stores an objective value
   * into its state record for each single one. These values are now put
   * into an array of double, so the objective function may decide on a
   * final value based on these results of single simulations. The
   * <code>results</code>-array is sorted in ascending order.
   * 
   * @param results
   *          The results of the single simulations. (Sorted in ascending
   *          order)
   * @param pl
   *          the prime list
   * @return A final objective value based on the results passed in.
   */
  @Override
  public double computeObjectiveValue(final double[] results,
      final PrimeListStaticData pl) {
    long d;
    int[] data;
    int i;

    i = pl.getCount();
    if (i <= 0)
      return OptimizationUtils.WORST;
    data = pl.m_primes;

    d = 0;

    for (--i; i >= 0; i--) {
      d -= data[i];
    }

    return (d - pl.getLong());
  }

  /**
   * Obtain the count of simulation steps that will be needed in order to
   * evaluate the specified individual.
   * 
   * @param individual
   *          The individual to be evaluated.
   * @param state
   *          The state container.
   * @param pl
   *          the prime list
   * @return The count of simulation steps needed. This default
   *         implementation returns 0.
   * @throws NullPointerException
   *           if <code>individual==null</code> or
   *           <code>state==null</code>
   */
  @Override
  public long getRequiredSimulationSteps(final Program<VM> individual,
      final ObjectiveState state, final PrimeListStaticData pl) {
    return PrimeUtils.SIMULATION_STEPS;
  }

  /**
   * This method is called after any simulation/evaluation is performed.
   * After this method returns, an objective value must have been stored in
   * the state record.
   * 
   * @param individual
   *          The individual that should be evaluated next.
   * @param state
   *          The state record.
   * @param simulation
   *          The simulation (<code>null</code> if no simulation is
   *          required as indivicated by
   *          <code>getRequiredSimulationSteps</code>).
   * @param pl
   *          the prime list
   * @throws NullPointerException
   *           if <code>individual==null</code> or
   *           <code>state==null</code> or if
   *           <code>simulator==null</code> but a simulation is required.
   */
  @Override
  public void endEvaluation(final Program<VM> individual,
      final ObjectiveState state, final PrimeListStaticData pl,
      final VMSimulation simulation) {
    VM v;
    int i;

    v = simulation.getVM();
    i = v.readGlobal(0);
    if (i > 0) {
      if (pl.enter(i))
        return;
      v.writeGlobal(0, 0);
    } else if (i < 0)
      pl.add(i);
  }

  /**
   * Obtain the id of the required simulator. If <code>null</code> is
   * returned, no simulation will be needed/performed for objective
   * function.
   * 
   * @return The id of the simulator required for the evaluation of this
   *         objective function.
   */
  @Override
  public Serializable getRequiredSimulationId() {
    return VMSimulation.SINGLE_VM_SIMULATION_ID;
  }

  /**
   * Append this object's textual representation to a string builder.
   * 
   * @param sb
   *          The string builder to append to.
   * @see #toString()
   */
  @Override
  public void toStringBuilder(final StringBuilder sb) {
    sb.append("different_high_primes"); //$NON-NLS-1$
  }

  /**
   * Create a new static data record.
   * 
   * @return the new static data record
   */
  @Override
  public PrimeListStaticData createStaticState() {
    return new PrimeListStaticData();
  }
}
