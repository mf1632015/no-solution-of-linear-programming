/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-01-03
 * Creator          : Thomas Weise
 * Original Filename: test.gp.vm.prime.PrimeListStaticData.java
 * Last modification: 2007-01-03
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.gp.vm.prime;

import java.io.Serializable;

/**
 * The static prime list data.
 * 
 * @author Thomas Weise
 */
public class NumberListStaticData implements Serializable {
  /**
   * the serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * the primes found
   */
  private final int[] m_primes;

  /**
   * the count of primes found
   */
  private int m_count;


  /**
   * Create the static data.
   */
  public NumberListStaticData() {
    super();
    this.m_primes = new int[PrimeUtils.TEST_COUNT];
  }


  /**
   * Reset the list
   */
  public void reset() {
    this.m_count = 0;
  }


  /**
   * obtain the counter
   * 
   * @return the counter
   */
  final int getCount() {
    return this.m_count;
  }


  /**
   * Enter a new number into the number list
   * 
   * @param i
   *          the number
   */
  public void enter(final int i) {
    int[] x;
    int j;

    x = this.m_primes;
    for (j = (this.m_count - 1); j >= 0; j--) {
      if (x[j] == i) {
        return;
      }
    }
    x[this.m_count++] = i;
  }
}
