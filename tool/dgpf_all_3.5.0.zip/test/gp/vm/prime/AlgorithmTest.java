/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-10
 * Creator          : Thomas Weise
 * Original Filename: test.gp.vm.prime.AlgorithmTest.java
 * Last modification: 2006-12-10
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.gp.vm.prime;

import org.dgpf.machine.gp.simulation.VMSimulationProvider;
import org.dgpf.machine.hl.DefaultLanguage;
import org.dgpf.machine.hl.genetics.HLEmbryogeny;
import org.dgpf.machine.ll.vm.DefaultInstructionSet;
import org.dgpf.machine.ll.vm.Program;
import org.dgpf.machine.ll.vm.VM;
import org.dgpf.machine.ll.vm.VMParameters;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeExchangeCrossover;
import org.sigoa.refimpl.genomes.tree.reproduction.TreeCreator;
import org.sigoa.refimpl.go.OptimizationInfo;
import org.sigoa.refimpl.go.evaluation.Evaluator;
import org.sigoa.refimpl.jobsystem.multiprocessor.MultiProcessorJobSystem;
import org.sigoa.refimpl.simulation.SimulationManager;
import org.sigoa.spec.go.IOptimizationInfo;
import org.sigoa.spec.go.evaluation.IEvaluator;
import org.sigoa.spec.go.reproduction.ICreator;
import org.sigoa.spec.go.reproduction.ICrossover;
import org.sigoa.spec.jobsystem.IJobSystem;
import org.sigoa.spec.simulation.ISimulationManager;

/**
 * Here we try to evolve an algorithm which enumerates primes.
 * 
 * @author Thomas Weise
 */
public class AlgorithmTest {

  /**
   * the optimization info.
   */
  static IOptimizationInfo<org.dgpf.machine.hl.Program, Program<VM>> s_oi;

  /**
   * The simulation manager.
   */
  static ISimulationManager s_simMan;

  /**
   * the main program called at startup
   * 
   * @param args
   *          the command line arguments
   */
  @SuppressWarnings("unchecked")
  public static void main(String[] args) {

    VMParameters parameters;

    IEvaluator<Program<VM>> eval;
    IJobSystem s;

    parameters = new VMParameters(//
        100,// global size
        100,// lobal size
        30,// stack size
        20// call depth
    );

    
    s_simMan = new SimulationManager();
    s_simMan.addProvider(new VMSimulationProvider(parameters));
    
    eval = new Evaluator<Program<VM>>(PrimeUtils.TEST);


//    out = new Population<org.dgpf.machine.hl.Program, Program<VM>>();
//    opt.setOutputPipe(out);

    ICreator<?> ic = new TreeCreator(DefaultLanguage.DEFAULT_LANGUAGE, 7,
        0.45);
    ICrossover<?> icc = SubTreeExchangeCrossover.SUB_TREE_EXCHANGE_CROSSOVER;
    s_oi = new OptimizationInfo<org.dgpf.machine.hl.Program, Program<VM>>(
        eval, new HLEmbryogeny<VM>(DefaultInstructionSet.INSTRUCTION_SET),
        ((ICreator<org.dgpf.machine.hl.Program>) (ic)),
        PrimeUtils.MUTATOR,
        ((ICrossover<org.dgpf.machine.hl.Program>) (icc)));


    s = new MultiProcessorJobSystem(s_simMan);
//    s.executeOptimization(opt,
//        new JobInfo<org.dgpf.machine.hl.Program, Program<VM>>(s_oi));
    s.start();

    try {
      System.in.read();
    } catch (Throwable t) {
      //
    }

  }

}
