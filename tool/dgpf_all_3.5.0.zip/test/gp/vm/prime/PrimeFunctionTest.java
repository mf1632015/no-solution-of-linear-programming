/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-10
 * Creator          : Thomas Weise
 * Original Filename: test.gp.vm.prime.PrimeFunctionTest.java
 * Last modification: 2006-12-10
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.gp.vm.prime;

import org.sfc.io.TextWriter;

/**
 * Here we try to evolve an algorithm which enumerates primes.
 * 
 * @author Thomas Weise
 */
public class PrimeFunctionTest {

  /**
   * create a new prime
   * 
   * @param i
   *          the parameter
   * @return the prime number
   */
  private static final long generatePrime(final long i) {
    long l3, l2, l1, l0, g0;

    l1 = sub1(i);
    l0 = (i ^ l1);
    g0 = 18 + l0;
    l3 = (~18);
    l2 = (g0 + l3);
    l1 = (~l2);
    l3 = (g0 ^ (-1));
    l2 = (l3 - g0);
    l0 = (l1 * l2);
    l2 = (g0 + 18);
    l1 = (~l2);
    return (l0 + l1);
  }

  /**
   * the sub-procedure
   * 
   * @param g0
   *          the global value
   * @return the return value
   */
  private static final long sub1(final long g0) {
    long l6, l5, l4, l3, l2, l1, l0;

    l6 = 12;
    l5 = g0 + l6;
    l4 = (~l5);
    l6 = (~g0);
    l5 = -16;
    l3 = (l4 | l5);
    l2 = (~l3);
    l1 = (56 ^ l2);
    l0 = (-3 + l1);
    l2 = (l0 + l0);
    l1 = (l0 + l2);
    l0 = (l0 + l1);
    return l0;
  }

  /**
   * The sqare root of the maximum integer.
   */
  private static final long SQRT_MAX_INT = ((long) (Math
      .sqrt(Long.MAX_VALUE)));

  /**
   * The sqare root of the maximum integer threshold.
   */
  private static final long SQRT_MAX_INT_TH = (SQRT_MAX_INT * SQRT_MAX_INT);

  /**
   * check whether a given number is prime or not
   * 
   * @param num
   *          the number to check
   * @return <code>true</code> if it is, <code>false</code> otherwise
   */
  public static final boolean isPrime(final long num) {
    long i, m;

    if (num <= 1)
      return false;
    if (num <= 3)
      return true;

    if ((num & 1) == 0)
      return false;

    i = 3;

    if (num < SQRT_MAX_INT_TH) {
      do {
        if ((num % i) <= 0)
          return false;
        i += 2;
      } while ((i * i) < num);
    } else {
      m = SQRT_MAX_INT;
      do {
        if ((num % i) <= 0)
          return false;
        i += 2;
      } while (i <= m);
    }

    return true;
  }

  /**
   * the main program called at startup
   * 
   * @param args
   *          the command line arguments
   */
  @SuppressWarnings("unchecked")
  public static void main(String[] args) {
    long v;
    int i, c, d;
    TextWriter w1, w2, w3, w4;
    boolean b1, b2;

    w1 = new TextWriter("E:\\normal.txt"); //$NON-NLS-1$
    w2 = new TextWriter("E:\\algorithm.txt");//$NON-NLS-1$
    w3 = new TextWriter("E:\\normalP.txt");//$NON-NLS-1$
    w4 = new TextWriter("E:\\algorithmP.txt");//$NON-NLS-1$

    c = 0;
    d = 0;
    for (i = 0;; i++) {

      v = generatePrime(i);

      b1 = isPrime(i);
      if (b1)
        d++;
      b2 = isPrime(v);
      if (b2)
        c++;
      // System.out.println(i+": "+generatePrime(i) + //$NON-NLS-1$
      // " (" + isPrime((int)v) + ')'); //$NON-NLS-1$

      w1.writeInt(i);
      w1.writeCSVSeparator();
      w1.writeDouble(((double) d) / ((double) (i + 1)));
      w1.newLine();
      w1.flush();

      w2.writeInt(i);
      w2.writeCSVSeparator();
      w2.writeDouble(((double) c) / ((double) (i + 1)));
      w2.newLine();
      w2.flush();

      w3.writeInt(i);
      w3.writeCSVSeparator();
      w3.writeInt(b1 ? 1 : 0);
      w3.newLine();
      w3.flush();

      w4.writeInt(i);
      w4.writeCSVSeparator();
      w4.writeInt(b2 ? 1 : 0);
      w4.newLine();
      w4.flush();
    }

  }

}
