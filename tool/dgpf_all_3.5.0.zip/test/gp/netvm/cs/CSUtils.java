/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-16
 * Creator          : Thomas Weise
 * Original Filename: test.gp.netvm.cs.CSUtils.java
 * Last modification: 2007-03-16
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.gp.netvm.cs;

import java.util.List;

import org.dgpf.machine.gp.objectives.MinimizeCallErrors;
import org.dgpf.machine.gp.objectives.MinimizeCodeSize;
import org.dgpf.machine.gp.objectives.MinimizeMemoryErrors;
import org.dgpf.machine.gp.objectives.MinimizeStackErrors;
import org.dgpf.machine.ll.vm.Instruction;
import org.dgpf.machine.ll.vm.InstructionSet;
import org.dgpf.machine.ll.vm.InstructionSetBuilder;
import org.dgpf.machine.ll.vm.Program;
import org.dgpf.machine.ll.vm.VM;
import org.dgpf.netmachine.gp.objectives.MinimizeTransmissions;
import org.dgpf.netmachine.hl.DefaultNetLanguage;
import org.dgpf.netmachine.ll.vm.DefaultNetInstructionSet;
import org.sfc.collections.CollectionUtils;
import org.sfc.utils.ErrorUtils;
import org.sigoa.refimpl.genomes.tree.INodeFactory;
import org.sigoa.refimpl.genomes.tree.reproduction.NodeFactorySet;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeDeleteMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeInsertMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeLiftMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeReplaceMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeSinkMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.TreeCreator;
import org.sigoa.refimpl.go.comparators.TieredParetoComparator;
import org.sigoa.refimpl.go.objectives.ovcs.ProportionalNegativeOVC;
import org.sigoa.refimpl.go.reproduction.IterativeMultiMutator;
import org.sigoa.spec.go.IComparator;
import org.sigoa.spec.go.objectives.IObjectiveFunction;
import org.sigoa.spec.go.reproduction.IMutator;
import org.sigoa.spec.simulation.ISimulation;

/**
 * the cs utils
 * 
 * @author Thomas Weise
 */
public final class CSUtils {

  /**
   * the test count
   */
  public static final int TEST_COUNT = 40;//22;

  /**
   * the vm count
   */
  public static final int VM_COUNT = 20;//20;

  /**
   * the step count
   */
  public static final int STEP_COUNT = 12000;

  /**
   * the default count of message types
   */
  public static final int MSG_TYPE_CNT = 2;

  /**
   * the default networking instruction set
   */
  public static final InstructionSet<CSVM> INSTRUCTION_SET;

  /**
   * The default cs instruction
   */
  public static final Instruction<CSVM> CSLL;

  static {

    InstructionSetBuilder<CSVM> b = new InstructionSetBuilder<CSVM>(
        DefaultNetInstructionSet.INSTRUCTION_SET) {
      @Override
      protected InstructionSet<CSVM> createInstructionSet(
          final Instruction<? super CSVM>[] instructions) {
        return new InstructionSet<CSVM>(instructions) {
          private static final long serialVersionUID = 1;

          private final Object readResolve() {
            return INSTRUCTION_SET;
          }

          private final Object writeReplace() {
            return INSTRUCTION_SET;
          }
        };
      }
    };

    CSLL = new CSLL(b);

    INSTRUCTION_SET = b.build();
  }

  /**
   * The node factories
   */
  private static final INodeFactory[] FACTORIES = new INodeFactory[] {

  CSHLFactory.CS_FACTORY,//

  };

  /**
   * the weights
   */
  private static final double[] WEIGHTS = new double[] { 1.0d, // send
  };

  /**
   * the default language
   */
  public static final NodeFactorySet LANGUAGE;

  static {
    NodeFactorySet f;
    f = new DefaultNetLanguage(MSG_TYPE_CNT);

    LANGUAGE = new NodeFactorySet(f, FACTORIES, WEIGHTS, f
        .getRootFactory());
  }

  /**
   * the objectives
   */
  public static final List<IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>> TEST = CollectionUtils
      .createList();

  /**
   * the internally used sub-tree creator
   */
  private static final TreeCreator SUB_TREE_CREATOR = new TreeCreator(
      LANGUAGE, 3, 0.35d);

  /**
   * the default mutator
   */
  @SuppressWarnings("unchecked")
  public static final IMutator<org.dgpf.machine.hl.Program> MUTATOR = new IterativeMultiMutator<org.dgpf.machine.hl.Program>(
      new IMutator[] {// 
      SubTreeDeleteMutator.SUB_TREE_DELETE_MUTATOR,//
          new SubTreeInsertMutator(SUB_TREE_CREATOR),//
          new SubTreeReplaceMutator(SUB_TREE_CREATOR),//
          SubTreeMutator.SUB_TREE_MUTATOR,//
          SubTreeLiftMutator.SUB_TREE_LIFT_MUTATOR,//
          new SubTreeSinkMutator(LANGUAGE), // 
      },//
      new double[] { 3, 1, 1, 1, 1, 1 });

  /**
   * init
   */
  @SuppressWarnings("unchecked")
  private static final void init() {
    IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>> x;
    IObjectiveFunction<?, ?, ?, ?> y;

    // constraint
    y = CSFeasibilityObjectiveFunction.CS_FEASIBILITY_OBJECTIVE_FUNCTION;
    x = (IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>) (y);
    TEST.add(x);

    y = new CSErrorObjectiveFunction(
        ProportionalNegativeOVC.PROPORTIONAL_NEGATIVE_OVC, TEST_COUNT);
    x = (IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>) (y);
    TEST.add(x);

    // functional
    y = new CSCountObjectiveFunction(TEST_COUNT);
    x = (IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>) (y);
    TEST.add(x);

    // nf
    y = new CSCountObjectiveFunction2(TEST_COUNT);
    x = (IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>) (y);
    TEST.add(x);

    y = MinimizeCallErrors.MINIMIZE_CALL_ERRORS;
    x = (IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>) (y);
    TEST.add(x);

    y = MinimizeMemoryErrors.MINIMIZE_MEMORY_ERRORS;
    x = (IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>) (y);
    TEST.add(x);

    y = MinimizeStackErrors.MINIMIZE_STACK_ERRORS;
    x = (IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>) (y);
    TEST.add(x);

    // non-functional

    y = MinimizeTransmissions.MINIMIZE_TRANSMISSIONS;
    x = (IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>) (y);
    TEST.add(x);
    //
    // y = MinimizeSteps.MINIMIZE_STEPS;
    // x = (IObjectiveFunction<Program<VM>, ?, ?,
    // ISimulation<Program<VM>>>) (y);
    // TEST.add(x);

    y = MinimizeCodeSize.MINIMIZE_CODE_SIZE;
    x = (IObjectiveFunction<Program<VM>, ?, ?, ISimulation<Program<VM>>>) (y);
    TEST.add(x);

  }

  static {
    init();
  }

  /**
   * the shared comparator
   */
  public static final IComparator COMPARATOR = new TieredParetoComparator(
      new int[] { 2, 3, 100 });

  /**
   * the forbidden constructor
   */
  private CSUtils() {
    ErrorUtils.doNotCall();
  }
}
