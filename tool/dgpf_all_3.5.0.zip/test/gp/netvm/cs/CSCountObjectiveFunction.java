/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-16
 * Creator          : Thomas Weise
 * Original Filename: test.gp.netvm.cs.CSCountObjectiveFunction.java
 * Last modification: 2007-03-16
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.gp.netvm.cs;

import java.io.Serializable;

import org.dgpf.machine.ll.vm.Program;
import org.dgpf.netmachine.gp.objectives.NetObjectiveFunction;
import org.dgpf.netmachine.gp.objectives.NetObjectiveStaticState;
import org.dgpf.netmachine.ll.vm.NetVM;
import org.sigoa.refimpl.go.objectives.ObjectiveState;
import org.sigoa.refimpl.go.objectives.ovcs.TruncatingAverageOVC;
import org.sigoa.spec.simulation.ISimulation;

/**
 * The critical section count objective function
 * 
 * @author Thomas Weise
 */
public class CSCountObjectiveFunction extends NetObjectiveFunction {
  /**
   * The serial version uid.
   */
  private static final long serialVersionUID = 1;

  /**
   * Create a new net program objective function
   * 
   * @param simCnt
   *          the simulation count
   */
  public CSCountObjectiveFunction(final int simCnt) {
    super(new TruncatingAverageOVC(7), simCnt);
  }

  /**
   * Obtain the id of the required simulator. If <code>null</code> is
   * returned, no simulation will be needed/performed for objective
   * function.
   * 
   * @return The id of the simulator required for the evaluation of this
   *         objective function.
   */
  @Override
  public Serializable getRequiredSimulationId() {
    return CSSimulation.class;
  }

  /**
   * This method is called after any simulation/evaluation is performed.
   * After this method returns, an objective value must have been stored in
   * the state record.
   * 
   * @param individual
   *          The individual that should be evaluated next.
   * @param state
   *          The state record.
   * @param staticState
   *          the static state record
   * @param simulation
   *          The simulation (<code>null</code> if no simulation is
   *          required as indivicated by
   *          <code>getRequiredSimulationSteps</code>).
   * @throws NullPointerException
   *           if <code>individual==null</code> or
   *           <code>state==null</code> or if
   *           <code>simulator==null</code> but a simulation is required.
   */
  @Override
  public void endEvaluation(final Program<NetVM> individual,
      final ObjectiveState state,
      final NetObjectiveStaticState staticState,
      final ISimulation<Program<NetVM>> simulation) {

    CSSimulation n;
    int i, j, k, l, k2, k3;
    double d, r;

    n = ((CSSimulation) simulation);
    i = n.m_csCount;

    if (i > 0) {
      k3 = k2 = k = Integer.MAX_VALUE;
      for (j = (n.getVMCount() - 1); j >= 0; j--) {
        l = ((CSVM) (n.getVM(j))).m_csCount;
        if (l < k) {
          if (k < k2) {
            if (k2 < k3)
              k3 = k2;
            k2 = k;
          }
          k = l;
        }
      }
      r = (1.0d / i);
      d = k;
      r -= (d * d * d);
      d = k2;
      r -= (d * d);
      r -= k3;
      state.setObjectiveValue(r);
    }

    super.endEvaluation(individual, state, staticState, simulation);
  }

  /**
   * Append this object's textual representation to a string builder.
   * 
   * @param sb
   *          The string builder to append to.
   * @see #toString()
   */
  @Override
  public void toStringBuilder(final StringBuilder sb) {
    sb.append("cs_count"); //$NON-NLS-1$
  }

  /**
   * Obtain the count of simulation steps that will be needed in order to
   * evaluate the specified individual.
   * 
   * @param individual
   *          The individual to be evaluated.
   * @param state
   *          The state container.
   * @param pl
   *          the static state
   * @return The count of simulation steps needed. This default
   *         implementation returns 0.
   * @throws NullPointerException
   *           if <code>individual==null</code> or
   *           <code>state==null</code>
   */
  @Override
  public long getRequiredSimulationSteps(final Program<NetVM> individual,
      final ObjectiveState state, final NetObjectiveStaticState pl) {
    return CSUtils.STEP_COUNT;
  }
}
