/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-11-28
 * Creator          : Thomas Weise
 * Original Filename: test.gp.netvm.cs.CSTest.java
 * Last modification: 2006-11-28
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.gp.netvm.cs;

import java.io.Serializable;
import java.util.List;

import org.dgpf.machine.ll.vm.Program;
import org.dgpf.machine.ll.vm.VM;
import org.dgpf.netmachine.ll.vm.INetVMFactory;
import org.dgpf.netmachine.ll.vm.INetVMParameters;
import org.dgpf.netmachine.ll.vm.NetVMParameters;
import org.sigoa.refimpl.go.Individual;
import org.sigoa.refimpl.go.evaluation.Evaluator;
import org.sigoa.refimpl.simulation.SimulationManager;
import org.sigoa.refimpl.stoch.Randomizer;
import org.sigoa.spec.go.IIndividual;
import org.sigoa.spec.go.IOptimizationInfo;
import org.sigoa.spec.go.evaluation.IEvaluator;
import org.sigoa.spec.go.objectives.IObjectiveFunction;
import org.sigoa.spec.simulation.ISimulation;
import org.sigoa.spec.simulation.ISimulationManager;
import org.sigoa.spec.stoch.IRandomizer;

/**
 * With this class we test a network of virtual machines and everything
 * around.
 * 
 * @author Thomas Weise
 */
public class CSTest {

  /**
   * the optimization info.
   */
  static IOptimizationInfo<byte[], Program<VM>> s_oi;

  /**
   * The simulation manager.
   */
  static ISimulationManager s_simMan;

  /**
   * the randomizer
   */
  static final IRandomizer s_rnd = new Randomizer();

  /**
   * base dir
   */
  static String s_bd = "";// "E:\\temp\\"; //$NON-NLS-1$

  /**
   * the main program called at startup
   * 
   * @param args
   *          the command line arguments
   */
  @SuppressWarnings("unchecked")
  public static void main(String[] args) {

    NetVMParameters parameters;
    IEvaluator<Program<CSVM>> eval;
    IIndividual<Program<CSVM>, Program<CSVM>> ind;
    Program<CSVM> prog;
    List<IObjectiveFunction<Program<CSVM>, ?, ?, ISimulation<Program<CSVM>>>> l;

    parameters = new NetVMParameters(//
        100,// global size
        100,// lobal size
        30,// stack size
        20,// call depth
        CSUtils.VM_COUNT// the vm count
    );

    l = (List<IObjectiveFunction<Program<CSVM>, ?, ?, ISimulation<Program<CSVM>>>>) ((List<?>) (CSUtils.TEST));
    eval = new Evaluator<Program<CSVM>>(

    l, CSUtils.TEST_COUNT) {
      private static final long serialVersionUID = 1;

      @Override
      protected ISimulationManager getSimulationManager() {
        return s_simMan;
      }
    };

    prog = new org.dgpf.machine.ll.vm.Program<CSVM>(
        test.gp.netvm.cs.CSUtils.INSTRUCTION_SET, new int[][] {
            { 12, 0, 1073741827, 2, 9, 1073741827, -536870912, 0, 9,
                -536870912, 0, 0, 12, 0, 1073741828, 3, 9, 1073741828,
                -536870912, 0, 7, 1073741826, 1073741827, 1073741828, 9,
                -536870912, 1073741826, 0, 12, 0, 1073741825, 3, 9,
                1073741825, -536870912, 0, 9, -536870912, 1073741825, 0,
                15, 1073741830, 0, 0, 9, -536870912, 0, 0, 12, 0,
                1073741831, 3, 9, 1073741831, -536870912, 0, 5,
                1073741829, 1073741830, 1073741831, 8, 1073741828,
                1073741829, 0, 9, -536870912, 1073741828, 0, 12, 0,
                1073741827, 0, 9, 1073741827, -536870912, 0, 7,
                1073741826, 1073741825, 1073741827, 13, 16, 1073741826, 4,
                16, 0, 0, 0, 12, 0, 1073741826, 2, 9, 1073741826,
                -536870912, 0, 9, 0, -536870912, 1, 9, -536870912, 0, 0,
                12, 0, 1073741828, 3, 9, 1073741828, -536870912, 0, 5,
                1073741827, 1073741828, 1073741825, 7, 1073741826,
                1073741827, 1, 13, 16, 1073741826, 3, 14, 3, 0, 0, 13, 0,
                0, -8, 9, -536870912, 0, 0, 12, 0, 1073741826, 3, 9,
                1073741826, -536870912, 0, 9, -536870912, 1073741824, 0 },
            { 9, -536870912, 0, 0, 12, 0, 1073741827, 3, 9, 1073741827,
                -536870912, 0, 7, 1073741826, 1073741827, 1, 15,
                1073741827, 0, 0, 7, -536870912, 1073741826, 1073741827 },
            { 14, 3, 0, 0, 15, 1073741828, 0, 0, 6, 1073741827, 536870911,
                1073741828, 2, 1073741826, 1073741825, 1073741827, 2,
                1073741825, 1073741826, 1073741825, 9, -536870912,
                1073741824, 0 },
            { 15, 1073741829, 0, 0, 9, -536870912, 0, 0, 12, 0,
                1073741831, 3, 9, 1073741831, -536870912, 0, 4,
                1073741830, 536870912, 1073741831, 5, 1073741828,
                1073741829, 1073741830, 8, 1073741827, 1073741828, 0, 7,
                536870912, 1, 1073741827, 9, -536870912, 1073741824, 0 } });

    ind = new Individual<Program<CSVM>, Program<CSVM>>(eval
        .getObjectiveValueCount());
    ind.setGenotype(prog);
    ind.setPhenotype(prog);

    s_simMan = new SimulationManager();
    s_simMan.addProvider(new CSSimulationProvider(parameters) {
      private static final long serialVersionUID = 1;

      @Override
      @SuppressWarnings("unchecked")
      protected ISimulation<?> createNetwork(
          final INetVMParameters params, final INetVMFactory<?> factory) {
        return new CSSimulation(params,
            ((INetVMFactory<? extends CSVM>) factory)) {
          private static final long serialVersionUID = 1;

          @Override
          protected IRandomizer getRandomizer() {
            IRandomizer r;
            r = super.getRandomizer();
            return ((r == null) ? s_rnd : r);
          }

          @Override
          public Serializable getSimulationId() {
            return this.getClass().getSuperclass();
          }
        };
      }
    });

    eval.evaluate(ind);

    System.out.println(ind);
    eval.evaluate(ind);

    System.out.println();
    System.out.println();
    System.out.println();
    System.out.println(ind);
  }
}
