/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-16
 * Creator          : Thomas Weise
 * Original Filename: test.gp.netvm.cs.CSSimulation.java
 * Last modification: 2007-03-16
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.gp.netvm.cs;

import org.dgpf.machine.ll.vm.Program;
import org.dgpf.netmachine.gp.simulation.broadcast.BroadcastNetwork;
import org.dgpf.netmachine.ll.vm.INetVMFactory;
import org.dgpf.netmachine.ll.vm.INetVMParameters;
import org.dgpf.netmachine.ll.vm.NetVM;

/**
 * The critical section simulation
 * 
 * @author Thomas Weise
 */
public class CSSimulation extends BroadcastNetwork {
  /**
   * the serial version uid
   */
  private static final long serialVersionUID = 1;

  /**
   * the critical section entry count
   */
  int m_csCount;

  /**
   * the semaphore value
   */
  private int m_val;

  /**
   * the violation count
   */
  long m_violationCount;

  /**
   * Create a new simple network
   * 
   * @param parameters
   *          the networked vm parameters
   * @param vmFactory
   *          the VM factory or <code>null</code> for a reasonable
   *          default
   */
  public CSSimulation(final INetVMParameters parameters,
      final INetVMFactory<? extends CSVM> vmFactory) {
    super(parameters, ((vmFactory == null) ? CSVM.CS_VM_FACTORY
        : vmFactory));
  }

  /**
   * this method is called on cs entry
   */
  final void enterCS() {
    // this.m_csCount++;
    // if ((++this.m_val) > 1)
    // this.m_violationCount++;
    this.m_val++;
  }

  /**
   * leave the critical section
   */
  final void leaveCS() {
    this.m_val--;
  }

  /**
   * this method is called whenever a vm performs a step
   */
  @Override
  protected void onStep() {
    int i;
    i = this.m_val;
    if (i > 0) {
      this.m_csCount++;
      if (i > 1) {
        i--;
        this.m_violationCount += (i * i);
      }
    }
  }

  /**
   * This method is called right before the simulation begins.
   * 
   * @param what
   *          The item to be simulated.
   * @throws NullPointerException
   *           if <code>what</code> is <code>null</code>.
   */
  @Override
  public void beginSimulation(final Program<NetVM> what) {
    super.beginSimulation(what);
    this.m_csCount = 0;
    this.m_val = 0;
    this.m_violationCount = 0;
  }
}
