/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-16
 * Creator          : Thomas Weise
 * Original Filename: test.gp.netvm.cs.CSVM.java
 * Last modification: 2007-03-16
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.gp.netvm.cs;

import org.dgpf.machine.ll.vm.VMHost;
import org.dgpf.netmachine.ll.vm.INetVMFactory;
import org.dgpf.netmachine.ll.vm.INetwork;
import org.dgpf.netmachine.ll.vm.NetVM;

/**
 * The critical section virtual machine
 * 
 * @author Thomas Weise
 */
public class CSVM extends NetVM {
  /**
   * the serial version uid
   */
  private static final long serialVersionUID = 1;

  /**
   * The globally shared network vm factory.
   */
  public static final INetVMFactory<NetVM> CS_VM_FACTORY = new INetVMFactory<NetVM>() {
    private static final long serialVersionUID = 0;

    public NetVM createVM(final VMHost h, final INetwork network) {
      return new CSVM(h, network);
    }

    private final Object readResolve() {
      return CS_VM_FACTORY;
    }

    private final Object writeReplace() {
      return CS_VM_FACTORY;
    }
  };

  /**
   * are we in the cs?
   */
  private int m_incs;

  /**
   * the cs count
   */
  int m_csCount;

  /**
   * the cs simulation
   */
  private final CSSimulation m_cs;

  /**
   * Create a new network-enabled virtual machine
   * 
   * @param host
   *          the vm host
   * @param network
   *          the network this network-enabled vm should be part of
   */
  public CSVM(final VMHost host, final INetwork network) {
    super(host, network);
    this.m_cs = ((CSSimulation) network);
  }

  /**
   * the cs instruction
   */
  public void cs() {
    int i;
    i = (--this.m_incs);
    if (i == 0) {
      this.m_cs.leaveCS();
      return;
    }
    if (i < 0) {
      this.m_incs = 101;
      this.m_cs.enterCS();
      this.m_csCount++;
    }

    this.jumpRelative(0);
  }

  /**
   * reset the virtual machine<br/> all internal structures (except the
   * program) are cleared
   */
  @Override
  public void reset() {
    super.reset();
    this.m_csCount = 0;
    this.m_incs = 0;
  }

  /**
   * Obtain the cs counter
   * 
   * @return the cs counter
   */
  public int getCSCount() {
    return this.m_csCount;
  }
}
