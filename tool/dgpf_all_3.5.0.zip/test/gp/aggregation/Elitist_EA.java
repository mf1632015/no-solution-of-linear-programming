/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-10
 * Creator          : Thomas Weise
 * Original Filename: test.gp.aggregation.Elitist_EA.java
 * Last modification: 2006-12-10
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.gp.aggregation;

import java.io.File;

import org.dgpf.aggregation.constructs.Program;
import org.dgpf.aggregation.simulation.CalculationProvider;
import org.dgpf.aggregation.simulation.IAggregationFunction;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeExchangeCrossover;
import org.sigoa.refimpl.genomes.tree.reproduction.TreeCreator;
import org.sigoa.refimpl.go.OptimizationInfo;
import org.sigoa.refimpl.go.Population;
import org.sigoa.refimpl.go.algorithms.ea.EA;
import org.sigoa.refimpl.go.algorithms.ea.ElitistEA;
import org.sigoa.refimpl.go.embryogeny.Embryogeny;
import org.sigoa.refimpl.go.evaluation.Evaluator;
import org.sigoa.refimpl.jobsystem.JobInfo;
import org.sigoa.refimpl.jobsystem.multiprocessor.MultiProcessorJobSystem;
import org.sigoa.refimpl.pipe.Pipeline;
import org.sigoa.refimpl.pipe.stat.FileTextWriterProvider;
import org.sigoa.refimpl.pipe.stat.IndividualPrinterPipe;
import org.sigoa.refimpl.pipe.stat.ObjectivePrinterPipe;
import org.sigoa.refimpl.simulation.SimulationManager;
import org.sigoa.refimpl.stoch.StatisticInfo;
import org.sigoa.spec.go.IOptimizationInfo;
import org.sigoa.spec.go.IPopulation;
import org.sigoa.spec.go.evaluation.IEvaluator;
import org.sigoa.spec.go.reproduction.ICreator;
import org.sigoa.spec.go.reproduction.ICrossover;
import org.sigoa.spec.jobsystem.IJobSystem;
import org.sigoa.spec.simulation.ISimulationManager;

import test.gp.vm.prime.PrimeUtils;

/**
 * Here we try to evolve an algorithm which enumerates primes.
 * 
 * @author Thomas Weise
 */
public class Elitist_EA {

  /**
   * the function to track
   */
  public static final IAggregationFunction F = new IAggregationFunction() {
    private static final long serialVersionUID = 1;

    public double compute(final double[] values) {
      StatisticInfo s;
      int i;

      s = new StatisticInfo();
      for (i = (values.length - 1); i >= 0; i--) {
        s.append(values[i]);
      }

      return s.getVariance();
    }

  };

  /**
   * the function to track
   */
  public static final IAggregationFunction F2 = new IAggregationFunction() {
    private static final long serialVersionUID = 1;

    public double compute(final double[] values) {
      double s;
      int i;
      s = 0;
      for (i = (values.length - 1); i >= 0; i--) {
        s += values[i];
      }
      return (s / values.length);
    }

  };
  
  /**
   * the optimization info.
   */
  static IOptimizationInfo<Program, Program> s_oi;

  /**
   * The simulation manager.
   */
  static ISimulationManager s_simMan;

  /**
   * base dir
   */
  static String s_bd = "";// "E:\\temp\\"; //$NON-NLS-1$

  /**
   * the main program called at startup
   * 
   * @param args
   *          the command line arguments
   */
  @SuppressWarnings("unchecked")
  public static void main(String[] args) {

    IEvaluator<Program> eval;
    EA<Program, Program> opt;
    IPopulation<Program, Program> out;
    IOptimizationInfo<Program, Program> oi;
    IJobSystem s;
    int pp;

    eval = new Evaluator<Program>(AggregationUtils.TEST,
        AggregationUtils.PARAMS.getTestCount());

    pp = ((7 * 1024) + 1);// ((4 * 1024) + 1);
    while (!(PrimeUtils.isPrime(pp)))
      pp += 2;

    System.out.println("Population-Size: " + pp); //$NON-NLS-1$

    opt = new ElitistEA<Program, Program>(pp, 0.55, 0.55) {
      private static final long serialVersionUID = 1;

      @Override
      protected Pipeline<Program, Program> createArchivePipeline() {
        Pipeline<Program, Program> p;
        p = super.createArchivePipeline();
        p.add(new IndividualPrinterPipe<Program, Program>(
            new FileTextWriterProvider(new File(s_bd + "c"), //$NON-NLS-1$
                "c"), false)); //$NON-NLS-1$
        p.add(new ObjectivePrinterPipe<Program, Program>(
            new FileTextWriterProvider(new File(s_bd + "bo"), //$NON-NLS-1$
                "bo"), false)); //$NON-NLS-1$
        return p;
      }

      /**
       * Create the pipeline which should internally be used for the
       * individual creation and evaluation.
       * 
       * @return the reproduction pipeline
       */
      @Override
      protected Pipeline<Program, Program> createPipeline() {
        Pipeline<Program, Program> p;
        p = super.createPipeline();
        p.add(new ObjectivePrinterPipe<Program, Program>(
            new FileTextWriterProvider(new File(s_bd + "ao"), //$NON-NLS-1$
                "ao"), false)); //$NON-NLS-1$
        return p;
      }
    };

    out = new Population<Program, Program>();
    opt.setOutputPipe(out);

    ICreator<?> ic = new TreeCreator(AggregationUtils.LANGUAGE, 7, 0.45);
    ICrossover<?> icc = SubTreeExchangeCrossover.SUB_TREE_EXCHANGE_CROSSOVER;
    oi = new OptimizationInfo<Program, Program>(eval,//
        AggregationUtils.COMPARATOR,// 
        new Embryogeny<Program, Program>() {
          private static final long serialVersionUID = 1;
        },//
        ((ICreator<Program>) (ic)),// 
        AggregationUtils.MUTATOR,//
        ((ICrossover<Program>) (icc)),//
        null);

    s_simMan = new SimulationManager();
    s_simMan.addProvider(new CalculationProvider(AggregationUtils.PARAMS,
        F));

    s = new MultiProcessorJobSystem(s_simMan);
    s.executeOptimization(opt, new JobInfo<Program, Program>(oi));
    s.start();

    try {
      System.in.read();
    } catch (Throwable t) {
      //
    }

  }

}
