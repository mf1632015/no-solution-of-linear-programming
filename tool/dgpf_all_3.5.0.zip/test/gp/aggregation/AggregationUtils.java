/*
 * Copyright (c) 2007 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2007-03-16
 * Creator          : Thomas Weise
 * Original Filename: test.gp.aggregation.AggregationUtils.java
 * Last modification: 2007-03-16
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.gp.aggregation;

import java.util.List;

import org.dgpf.aggregation.constructs.DefaultAggregationLanguage;
import org.dgpf.aggregation.constructs.Program;
import org.dgpf.aggregation.simulation.Calculation;
import org.dgpf.aggregation.simulation.CalculationParameters;
import org.dgpf.aggregation.simulation.ErrorObjectiveFunction;
import org.dgpf.aggregation.simulation.SizeObjectiveFunction;
import org.dgpf.aggregation.simulation.SquareErrorObjectiveFunction;
import org.sfc.collections.CollectionUtils;
import org.sfc.utils.ErrorUtils;
import org.sigoa.refimpl.genomes.tree.reproduction.NodeFactorySet;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeDeleteMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeInsertMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeLiftMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeReplaceMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.SubTreeSinkMutator;
import org.sigoa.refimpl.genomes.tree.reproduction.TreeCreator;
import org.sigoa.refimpl.go.comparators.ParetoComparator;
import org.sigoa.refimpl.go.objectives.ovcs.ProportionalNegativeOVC;
import org.sigoa.refimpl.go.reproduction.IterativeMultiMutator;
import org.sigoa.spec.go.IComparator;
import org.sigoa.spec.go.objectives.IObjectiveFunction;
import org.sigoa.spec.go.reproduction.IMutator;
import org.sigoa.spec.simulation.ISimulation;

/**
 * the cs utils
 * 
 * @author Thomas Weise
 */
public final class AggregationUtils {

  /**
   * the default language
   */
  public static final NodeFactorySet LANGUAGE = DefaultAggregationLanguage.DEFAULT_LANGUAGE;

  /**
   * the objectives
   */
  public static final List<IObjectiveFunction<Program, ?, ?, ISimulation<Program>>> TEST = CollectionUtils
      .createList();

  /**
   * the internally used sub-tree creator
   */
  private static final TreeCreator SUB_TREE_CREATOR = new TreeCreator(
      LANGUAGE, 3, 0.35d);

  /**
   * the default mutator
   */
  @SuppressWarnings("unchecked")
  public static final IMutator<Program> MUTATOR = new IterativeMultiMutator<Program>(
      new IMutator[] {// 
      new SubTreeInsertMutator(SUB_TREE_CREATOR),
          new SubTreeReplaceMutator(SUB_TREE_CREATOR),
          SubTreeMutator.SUB_TREE_MUTATOR,
          SubTreeLiftMutator.SUB_TREE_LIFT_MUTATOR,
          new SubTreeSinkMutator(LANGUAGE) ,// 
          SubTreeDeleteMutator.SUB_TREE_DELETE_MUTATOR,//
          },
      new double[] { 1, 1, 1, 2, 1, 2 });

  /** the calculation parameters */
  public static final CalculationParameters PARAMS = new CalculationParameters(
      5,// varcnt
      16,// vm cnt
      Calculation.MIN_TESTS << 1,// test cnt
      300);// step cnt);

  /**
   * init
   */
  @SuppressWarnings("unchecked")
  private static final void init() {
    IObjectiveFunction<Program, ?, ?, ISimulation<Program>> x;
    IObjectiveFunction<?, ?, ?, ?> y;

    // functional
    y = new SquareErrorObjectiveFunction(PARAMS,
        ProportionalNegativeOVC.PROPORTIONAL_NEGATIVE_OVC);
    x = (IObjectiveFunction<Program, ?, ?, ISimulation<Program>>) (y);
    TEST.add(x);

    y = new ErrorObjectiveFunction(PARAMS,
        ProportionalNegativeOVC.PROPORTIONAL_NEGATIVE_OVC);
    x = (IObjectiveFunction<Program, ?, ?, ISimulation<Program>>) (y);
    TEST.add(x);

    //    
    // y = new HitObjectiveFunction(PARAMS);
    // x = (IObjectiveFunction<Program, ?, ?, ISimulation<Program>>) (y);
    // TEST.add(x);

    // nonfunctional

    y = SizeObjectiveFunction.SIZE_OBJECTIVE_FUNCTION;
    x = (IObjectiveFunction<Program, ?, ?, ISimulation<Program>>) (y);
    TEST.add(x);

    // y = MessageSizeObjectiveFunction.MSG_SIZE_OBJECTIVE_FUNCTION;
    // x = (IObjectiveFunction<Program, ?, ?, ISimulation<Program>>) (y);
    // TEST.add(x);
    //
    // y = new VarianceObjectiveFunction(PARAMS,
    // SquareNegativeOVC.SQUARE_NEGATIVE_OVC);
    // x = (IObjectiveFunction<Program, ?, ?, ISimulation<Program>>) (y);
    // TEST.add(x);

  }

  static {
    init();
  }

  /**
   * the shared comparator
   */
  public static final IComparator COMPARATOR = ParetoComparator.PARETO_COMPARATOR;

  // new TieredParetoComparator(new int[] { 2, 100 });

  /**
   * the forbidden constructor
   */
  private AggregationUtils() {
    ErrorUtils.doNotCall();
  }
}
