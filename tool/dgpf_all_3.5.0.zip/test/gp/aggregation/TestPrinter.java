/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-10
 * Creator          : Thomas Weise
 * Original Filename: test.gp.aggregation.TestPrinter.java
 * Last modification: 2006-12-10
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.gp.aggregation;

import java.io.File;
import java.io.Serializable;
import java.util.Arrays;

import org.dgpf.aggregation.constructs.Formula;
import org.dgpf.aggregation.constructs.Program;
import org.dgpf.aggregation.constructs.expressions.Add;
import org.dgpf.aggregation.constructs.expressions.Constant;
import org.dgpf.aggregation.constructs.expressions.Div;
import org.dgpf.aggregation.constructs.expressions.Variable;
import org.dgpf.aggregation.simulation.Calculation;
import org.dgpf.aggregation.simulation.IAggregationFunction;
import org.dgpf.aggregation.simulation.LoggingCalculation;
import org.sigoa.refimpl.genomes.tree.Node;
import org.sigoa.refimpl.pipe.stat.FileTextWriterProvider;
import org.sigoa.spec.go.IOptimizationInfo;
import org.sigoa.spec.go.objectives.IObjectiveFunction;
import org.sigoa.spec.go.objectives.IObjectiveState;

/**
 * Here we try to evolve an algorithm which enumerates primes.
 * 
 * @author Thomas Weise
 */
public class TestPrinter {

  /**
   * the function to track
   */
  public static final IAggregationFunction F = Elitist_EA.F;

  // new IAggregationFunction() {
  // private static final long serialVersionUID = 1;
  //
  // public double compute(final double[] values) {
  // double s;
  // int i;
  // s = 0;
  // for (i = (values.length - 1); i >= 0; i--) {
  // s += values[i];
  // }
  // return (s / values.length);
  // }
  //
  // };

  /**
   * the optimization info.
   */
  static IOptimizationInfo<Program, Program> s_oi;

  //
  //
  /**
   * the testee
   */
  static final Program P = new Program(new Node[] {//
      new Formula(1, new Node[] { new Div(new Node[] {
          new Add(new Node[] { new Variable(1), new Variable(2) }),
          new Constant(2) }) }) }, new int[] { 1 }, new int[] { 2 });

  /**
   * the second testee
   */
  static final Program P2 = new org.dgpf.aggregation.constructs.Program(
      new org.sigoa.refimpl.genomes.tree.Node[] {
          new org.dgpf.aggregation.constructs.Formula(
              2,
              new org.sigoa.refimpl.genomes.tree.Node[] { new org.dgpf.aggregation.constructs.expressions.Max(
                  new org.sigoa.refimpl.genomes.tree.Node[] {
                      new org.dgpf.aggregation.constructs.expressions.Power(
                          new org.sigoa.refimpl.genomes.tree.Node[] {
                              new org.dgpf.aggregation.constructs.expressions.Mul(
                                  new org.sigoa.refimpl.genomes.tree.Node[] {
                                      new org.dgpf.aggregation.constructs.expressions.Variable(
                                          2),
                                      new org.dgpf.aggregation.constructs.expressions.Variable(
                                          3) }),
                              new org.dgpf.aggregation.constructs.expressions.Constant(
                                  0.5000000808403379) }),
                      new org.dgpf.aggregation.constructs.expressions.Div(
                          new org.sigoa.refimpl.genomes.tree.Node[] {
                              new org.dgpf.aggregation.constructs.expressions.Variable(
                                  3),
                              new org.dgpf.aggregation.constructs.expressions.Constant(
                                  1.1756469679385733) }) }) }),
          new org.dgpf.aggregation.constructs.Formula(
              1,
              new org.sigoa.refimpl.genomes.tree.Node[] { new org.dgpf.aggregation.constructs.expressions.Constant(
                  1.0) }),
          new org.dgpf.aggregation.constructs.Formula(
              1,
              new org.sigoa.refimpl.genomes.tree.Node[] { new org.dgpf.aggregation.constructs.expressions.Constant(
                  0.5) }),
          new org.dgpf.aggregation.constructs.Formula(
              1,
              new org.sigoa.refimpl.genomes.tree.Node[] { new org.dgpf.aggregation.constructs.expressions.Variable(
                  1) }),
          new org.dgpf.aggregation.constructs.Formula(
              3,
              new org.sigoa.refimpl.genomes.tree.Node[] { new org.dgpf.aggregation.constructs.expressions.Power(
                  new org.sigoa.refimpl.genomes.tree.Node[] {
                      new org.dgpf.aggregation.constructs.expressions.Mul(
                          new org.sigoa.refimpl.genomes.tree.Node[] {
                              new org.dgpf.aggregation.constructs.expressions.Variable(
                                  2),
                              new org.dgpf.aggregation.constructs.expressions.Variable(
                                  3) }),
                      new org.dgpf.aggregation.constructs.expressions.Constant(
                          0.5) }) }),
          new org.dgpf.aggregation.constructs.Formula(
              1,
              new org.sigoa.refimpl.genomes.tree.Node[] { new org.dgpf.aggregation.constructs.expressions.Abs(
                  new org.sigoa.refimpl.genomes.tree.Node[] { new org.dgpf.aggregation.constructs.expressions.Mul(
                      new org.sigoa.refimpl.genomes.tree.Node[] {
                          new org.dgpf.aggregation.constructs.expressions.Variable(
                              2),
                          new org.dgpf.aggregation.constructs.expressions.Variable(
                              3) }) }) }) }, new int[] { 2 },
      new int[] { 3 });

  /**
   * the main program called at startup
   * 
   * @param args
   *          the command line arguments
   */
  @SuppressWarnings("unchecked")
  public static void main(String[] args) {
    Calculation c;
    int i;
    double[] v1, v2;
    IObjectiveState s1, s2;
    IObjectiveFunction<Program, IObjectiveState, Serializable, Calculation> f1, f2;

    System.out.println(P2);
    System.out.println(P2.getWeight());
    System.out.println(P.getWeight());

    // StringBuilder sb;
    // sb = new StringBuilder();
    // P.javaToStringBuilder(sb, 0);
    // System.out.println(sb);

    c = new LoggingCalculation(AggregationUtils.PARAMS, F,
        new FileTextWriterProvider(new File("E:\\a\\"), //$NON-NLS-1$
            "results"),//$NON-NLS-1$
        new FileTextWriterProvider(new File("E:\\a\\"), //$NON-NLS-1$
            "targets"),//$NON-NLS-1$
        new FileTextWriterProvider(new File("E:\\a\\"), //$NON-NLS-1$
            "sensors")//$NON-NLS-1$
    );

    v1 = new double[AggregationUtils.PARAMS.getTestCount()];
    v2 = new double[AggregationUtils.PARAMS.getTestCount()];
    f1 = ((IObjectiveFunction) (AggregationUtils.TEST.get(0)));
    f2 = ((IObjectiveFunction) (AggregationUtils.TEST.get(1)));
    s1 = f1.createState(null);
    s2 = f2.createState(null);

    for (i = (AggregationUtils.PARAMS.getTestCount() - 1); i >= 0; i--) {
      f1.beginEvaluation(P, s1, null, c);
      f2.beginEvaluation(P, s2, null, c);
      s1.clear();
      s2.clear();
      c.beginSimulation(P);
      c.simulate(AggregationUtils.PARAMS.getStepsPerTest());

      f1.endEvaluation(P, s1, null, c);
      v1[i] = s1.getObjectiveValue();
      f2.endEvaluation(P, s2, null, c);
      v2[i] = s2.getObjectiveValue();

      c.endSimulation();
      System.gc();
      System.gc();
    }
    System.gc();
    System.gc();
    System.gc();

    Arrays.sort(v1);
    Arrays.sort(v2);
    System.out.println("f1: " + f1.computeObjectiveValue(v1, null)); //$NON-NLS-1$
    System.out.println("f2: " + f2.computeObjectiveValue(v2, null)); //$NON-NLS-1$

    c = null;
    System.gc();
    System.gc();
    System.gc();
    System.gc();
    System.gc();

    c = new LoggingCalculation(AggregationUtils.PARAMS, F,
        new FileTextWriterProvider(new File("E:\\b\\"), //$NON-NLS-1$
            "results"),//$NON-NLS-1$
        new FileTextWriterProvider(new File("E:\\b\\"), //$NON-NLS-1$
            "targets"),//$NON-NLS-1$
        new FileTextWriterProvider(new File("E:\\b\\"), //$NON-NLS-1$
            "sensors")//$NON-NLS-1$
    );
    for (i = (AggregationUtils.PARAMS.getTestCount() - 1); i >= 0; i--) {
      f1.beginEvaluation(P2, s1, null, c);
      f2.beginEvaluation(P2, s2, null, c);
      s1.clear();
      s2.clear();
      c.beginSimulation(P2);
      c.simulate(AggregationUtils.PARAMS.getStepsPerTest());

      f1.endEvaluation(P2, s1, null, c);
      v1[i] = s1.getObjectiveValue();
      f2.endEvaluation(P2, s2, null, c);
      v2[i] = s2.getObjectiveValue();

      c.endSimulation();
      System.gc();
      System.gc();
    }
    System.gc();
    System.gc();
    System.gc();

    Arrays.sort(v1);
    Arrays.sort(v2);
    System.out.println("f1: " + f1.computeObjectiveValue(v1, null)); //$NON-NLS-1$
    System.out.println("f2: " + f2.computeObjectiveValue(v2, null)); //$NON-NLS-1$

  }

}
