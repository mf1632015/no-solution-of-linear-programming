/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-29
 * Creator          : Thomas Weise
 * Original Filename: test.data.DataConv.java
 * Last modification: 2006-12-29
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Arrays;

import org.sfc.io.IO;

/**
 * the dummy test class
 * 
 * @author Thomas Weise
 */
public class DataConv {

  /**
   * the main routine
   * 
   * @param args
   *          the arguments
   */
  public static void main(final String[] args) {

    
    join("Z:\\tests\\001_prime_hl\\04\\objectives",//$NON-NLS-1$
        "E:\\temp\\1.txt"); //$NON-NLS-1$
    
//    join("Z:\\tests\\002_prime_hl\\1\\ao",//$NON-NLS-1$
//        "E:\\temp\\1.txt"); //$NON-NLS-1$
//    
//    join("Z:\\tests\\002_prime_hl\\2\\ao",//$NON-NLS-1$
//        "E:\\temp\\2.txt"); //$NON-NLS-1$
//    
//    join("Z:\\tests\\002_prime_hl\\3\\ao",//$NON-NLS-1$
//        "E:\\temp\\3.txt"); //$NON-NLS-1$
//    
//    join("Z:\\tests\\003_prime_hl\\01\\ao",//$NON-NLS-1$
//        "E:\\temp\\4.txt"); //$NON-NLS-1$
//    
//    join("Z:\\tests\\003_prime_hl\\02\\ao",//$NON-NLS-1$
//        "E:\\temp\\5.txt"); //$NON-NLS-1$
//    
//    join("Z:\\tests\\003_prime_hl\\03\\ao",//$NON-NLS-1$
//        "E:\\temp\\6.txt"); //$NON-NLS-1$
//    
//    // "Z:\\tests\\001_prime_hl\\04\\objectives",
    //
//     join("Z:\\tests\\prime\\01\\objectives", //$NON-NLS-1$
//     "E:\\temp\\1.txt"); //$NON-NLS-1$
  }

  /**
   * join all the source files to another one.
   * 
   * @param sourceDir
   *          the source directory
   * @param destFile
   *          the dest file
   */
  private static final void join(final String sourceDir,
      final String destFile) {
    File sf, df;
    File[] sfs;
    int i;
    BufferedWriter dw;

    sf = IO.getFile(sourceDir);
    df = IO.getFile(destFile);

    sfs = sf.listFiles();
    Arrays.sort(sfs);

    try {
      dw = new BufferedWriter(new FileWriter(df));
      try {
        for (i = 0; (i < 5000) && (i < sfs.length); i++) {
          copy(sfs[i], dw, i);
        }
      } finally {
        dw.close();
      }
    } catch (Throwable ttt) {
      ttt.printStackTrace();
    }
  }

  /**
   * copy the data
   * 
   * @param in
   *          the input
   * @param out
   *          the output stream
   * @param z
   *          the z value
   */
  private static final void copy(final File in, final BufferedWriter out,
      final int z) {
    BufferedReader r;
    String l;
    String[] v;
    double d;
    boolean b;
    try {
      r = new BufferedReader(new FileReader(in));

      try {
        l = r.readLine();
        b = (z > 0);
        while ((l = r.readLine()) != null) {
          if (b)
            out.newLine();
          else
            b = true;
          v = l.split("\\s"); //$NON-NLS-1$

          if (v[0].equalsIgnoreCase("infinity")) //$NON-NLS-1$
            d = -610;
          else
            try {
              d = (600 - Math.round(Double.parseDouble(v[0])));
              if (Double.isNaN(d) || Double.isInfinite(d))
                d = -610;
            } catch (Throwable xx) {
              d = -610;
            }
          out.write(String.valueOf(d) + "\t"); //$NON-NLS-1$

          if (v[1].equalsIgnoreCase("infinity")) //$NON-NLS-1$
            d = 0;
          else
          try {
            d = (Math.log(-Math.rint(Double.parseDouble(v[1]))) / Math
                .log(10));
            if (Double.isNaN(d) || Double.isInfinite(d))
              d = 0;
          } catch (Throwable xx) {
            d = 0;
          }
          out.write(d + "\t" + z);//$NON-NLS-1$          
        }

      } finally {
        r.close();
      }

    } catch (Throwable ttt) {
      ttt.printStackTrace();
    }
  }
}
