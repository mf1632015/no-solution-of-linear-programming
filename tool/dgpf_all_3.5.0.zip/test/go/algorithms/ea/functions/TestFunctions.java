/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-15
 * Creator          : Thomas Weise
 * Original Filename: test.go.algorithms.ea.functions.TestFunctions.java
 * Last modification: 2006-12-15
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.go.algorithms.ea.functions;

import java.util.List;

import org.sfc.collections.CollectionUtils;
import org.sfc.utils.ErrorUtils;
import org.sigoa.refimpl.genomes.doubleArray.DoubleArrayObjectiveFunction;
import org.sigoa.refimpl.genomes.doubleArray.IDoubleArrayFunction;
import org.sigoa.spec.go.objectives.IObjectiveFunction;
import org.sigoa.spec.simulation.ISimulation;

/**
 * this class provides some simple test functions
 * 
 * @author Thomas Weise
 */
public final class TestFunctions {

  /**
   * one of the functions.
   */
  private static final IDoubleArrayFunction F1 = new IDoubleArrayFunction() {
    public double compute(final double[] x) {
      double s;
      int i;

      s = 0.0d;

      for (i = 12; i >= 4; i--) {
        s -= x[i];
      }
      for (; i >= 0; i--) {
        s += ((5 * x[i]) - (5 * x[i] * x[i]));
      }

      if (s < -1e5)
        return Double.MAX_VALUE;
      return s;
    }
  };

  /**
   * one of the functions.
   */
  private static final IDoubleArrayFunction F2 = new IDoubleArrayFunction() {
    public double compute(final double[] x) {
      double s;

      s = (2.0 * x[0]) + (2.0 * x[1]) + (x[9]) + (x[10]) - 10;

      if (s < -1e5)
        return Double.MAX_VALUE;
      if (s <= 0.0d)
        return 0.0d;
      return s;
    }
  };

  /**
   * one of the functions.
   */
  private static final IDoubleArrayFunction F3 = new IDoubleArrayFunction() {
    public double compute(final double[] x) {
      double s;

      s = (2.0 * x[0]) + (2.0 * x[2]) + (x[9]) + (x[11]) - 10;

      if (s < -1e5)
        return Double.MAX_VALUE;
      if (s <= 0.0d)
        return 0.0d;
      return s;
    }
  };

  /**
   * one of the functions.
   */
  private static final IDoubleArrayFunction F4 = new IDoubleArrayFunction() {
    public double compute(final double[] x) {
      double s;

      s = (2.0 * x[2]) + (2.0 * x[1]) + (x[9]) + (x[11]) - 10;

      if (s < -1e5)
        return Double.MAX_VALUE;
      if (s <= 0.0d)
        return 0.0d;
      return s;
    }
  };

  /**
   * one of the functions.
   */
  private static final IDoubleArrayFunction F5 = new IDoubleArrayFunction() {
    public double compute(final double[] x) {
      double s;

      s = ((-8.0 * x[0]) + x[9]);

      if (s < -1e5)
        return Double.MAX_VALUE;
      if (s <= 0.0d)
        return 0.0d;
      return s;
    }
  };

  /**
   * one of the functions.
   */
  private static final IDoubleArrayFunction F6 = new IDoubleArrayFunction() {
    public double compute(final double[] x) {
      double s;

      s = ((-8.0 * x[1]) + x[10]);

      if (s < -1e5)
        return Double.MAX_VALUE;
      if (s <= 0.0d)
        return 0.0d;
      return s;
    }
  };

  /**
   * one of the functions.
   */
  private static final IDoubleArrayFunction F7 = new IDoubleArrayFunction() {
    public double compute(final double[] x) {
      double s;

      s = ((-8.0 * x[2]) + x[11]);

      if (s < -1e5)
        return Double.MAX_VALUE;
      if (s <= 0.0d)
        return 0.0d;
      return s;
    }
  };

  /**
   * one of the functions.
   */
  private static final IDoubleArrayFunction F8 = new IDoubleArrayFunction() {
    public double compute(final double[] x) {
      double s;

      s = ((-2.0 * x[3]) - x[4] + x[9]);

      if (s < -1e5)
        return Double.MAX_VALUE;
      if (s <= 0.0d)
        return 0.0d;
      return s;
    }
  };

  /**
   * one of the functions.
   */
  private static final IDoubleArrayFunction F9 = new IDoubleArrayFunction() {
    public double compute(final double[] x) {
      double s;

      s = ((-2.0 * x[5]) - x[6] + x[10]);

      if (s < -1e5)
        return Double.MAX_VALUE;
      if (s <= 0.0d)
        return 0.0d;
      return s;
    }
  };

  /**
   * one of the functions.
   */
  private static final IDoubleArrayFunction F10 = new IDoubleArrayFunction() {
    public double compute(final double[] x) {
      double s;

      s = ((-2.0 * x[7]) - x[8] + x[11]);

      if (s < -1e5)
        return Double.MAX_VALUE;
      if (s <= 0.0d)
        return 0.0d;
      return s;
    }
  };

  /**
   * the objectives
   */
  public static final List<IObjectiveFunction<double[], ?, ?, ISimulation<double[]>>> TEST_1;

  /**
   * the test functions
   */
  public static final IDoubleArrayFunction[] TEST_1_FUNCTIONS = new IDoubleArrayFunction[] {
      F1, F2, F3, F4, F5, F6, F7, F8, F9, F10 };

  static {
    int i;
    TEST_1 = CollectionUtils.createList();

    for (i = (TEST_1_FUNCTIONS.length - 1); i >= 0; i--) {
      TEST_1.add(new DoubleArrayObjectiveFunction(TEST_1_FUNCTIONS[i]));
    }
  }

  /**
   * the minima
   */
  public static final double[] TEST_1_MIN = new double[] { 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0 };

  /**
   * the maxima
   */
  public static final double[] TEST_1_MAX = new double[] { 1, 1, 1, 1, 1,
      1, 1, 1, 1, 100, 100, 100, 1 };

  /**
   * the forbidden constructor
   */
  private TestFunctions() {
    ErrorUtils.doNotCall();
  }

}
