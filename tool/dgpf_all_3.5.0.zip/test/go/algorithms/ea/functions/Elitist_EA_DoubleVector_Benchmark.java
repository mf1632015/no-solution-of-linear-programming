/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-10
 * Creator          : Thomas Weise
 * Original Filename: test.go.algorithms.ea.functions.Elitist_EA_DoubleVector_Benchmark.java
 * Last modification: 2006-12-10
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.go.algorithms.ea.functions;

import org.sigoa.refimpl.genomes.doubleArray.reproduction.DoubleArrayCreator;
import org.sigoa.refimpl.genomes.doubleArray.reproduction.DoubleArrayCrossover;
import org.sigoa.refimpl.genomes.doubleArray.reproduction.DoubleArrayMutator;
import org.sigoa.refimpl.go.OptimizationInfo;
import org.sigoa.refimpl.go.Population;
import org.sigoa.refimpl.go.algorithms.ea.EA;
import org.sigoa.refimpl.go.algorithms.ea.ElitistEA;
import org.sigoa.refimpl.go.embryogeny.Embryogeny;
import org.sigoa.refimpl.go.evaluation.Evaluator;
import org.sigoa.refimpl.jobsystem.JobInfo;
import org.sigoa.refimpl.jobsystem.multiprocessor.MultiProcessorJobSystem;
import org.sigoa.spec.go.IIndividual;
import org.sigoa.spec.go.IOptimizationInfo;
import org.sigoa.spec.go.IPopulation;
import org.sigoa.spec.go.evaluation.IEvaluator;
import org.sigoa.spec.jobsystem.IJobSystem;

/**
 * A simple test for the evolutionary algorithm base implementation.
 * 
 * @author Thomas Weise
 */
public class Elitist_EA_DoubleVector_Benchmark {
  /**
   * the main program called at startup
   * 
   * @param args
   *          the command line arguments
   */
  public static void main(String[] args) {
    IEvaluator<double[]> eval;
    EA<double[], double[]> opt;
    IPopulation<double[], double[]> out;
    IOptimizationInfo<double[], double[]> oi;
    double[] data;
    int i;
    IJobSystem s;

    eval = new Evaluator<double[]>(TestFunctions.TEST_1);
    opt = new ElitistEA<double[], double[]>(1024, 0.35, 0.8);
    out = new Population<double[], double[]>();
    opt.setOutputPipe(out);

    // opt.getRules().add(
    // new CompoundRule<IOptimizer<double[], double[]>>(
    // new TimeCondition<IOptimizer<double[], double[]>>(20000),
    // new AbortAction<IOptimizer<double[], double[]>>()));

    oi = new OptimizationInfo<double[], double[]>(eval,
        new Embryogeny<double[], double[]>() {
          private static final long serialVersionUID = 1;
        }, new DoubleArrayCreator(TestFunctions.TEST_1_MIN,
            TestFunctions.TEST_1_MAX), new DoubleArrayMutator(
            TestFunctions.TEST_1_MIN, TestFunctions.TEST_1_MAX),
        new DoubleArrayCrossover(TestFunctions.TEST_1_MIN,
            TestFunctions.TEST_1_MAX));

    s = new MultiProcessorJobSystem(null);
    s.executeOptimization(opt, new JobInfo<double[], double[]>(oi));
    s.start();

    // /
    try {
      System.in.read();
    } catch (Throwable t) {
      // //
    }
    opt.abort();
    // /

    opt.waitFor(false);
    s.abort();
    s.waitFor(false);

    System.out.println();
    System.out.println("Generation " + opt.getIteration());//$NON-NLS-1$
    System.out.println("Solutions  " + out.size());//$NON-NLS-1$
    System.out.println();

    for (IIndividual<double[], double[]> ind : out) {
      data = ind.getGenotype();
      for (i = 0; i < data.length; i++) {
        System.out.print(data[i]);
        if (i < (data.length - 1))
          System.out.print('\t');
        else
          System.out.println();
      }
    }
  }

}
