/*
 * Copyright (c) 2006 Thomas Weise for sigoa
 * Standard Interface for Global Optimization Algorithms
 * http://www.sigoa.org/
 * 
 * E-Mail           : info@sigoa.org
 * Creation Date    : 2006-12-10
 * Creator          : Thomas Weise
 * Original Filename: test.go.algorithms.ea.functions.Elitist_EA_BitString_Benchmark.java
 * Last modification: 2006-12-10
 *                by: Thomas Weise
 * 
 * License          : GNU LESSER GENERAL PUBLIC LICENSE
 *                    Version 2.1, February 1999
 *                    You should have received a copy of this license along
 *                    with this library; if not, write to theFree Software
 *                    Foundation, Inc. 51 Franklin Street, Fifth Floor,
 *                    Boston, MA 02110-1301, USA or download the license
 *                    under http://www.gnu.org/licenses/lgpl.html or
 *                    http://www.gnu.org/copyleft/lesser.html.
 *                    
 * Warranty         : This software is provided "as is" without any
 *                    warranty; without even the implied warranty of
 *                    merchantability or fitness for a particular purpose.
 *                    See the Gnu Lesser General Public License for more
 *                    details.
 */

package test.go.algorithms.ea.functions;

import java.io.File;

import org.sigoa.refimpl.genomes.bitString.BitStringOutputStream;
import org.sigoa.refimpl.genomes.bitString.GrayCodedBitStringOutputStream;
import org.sigoa.refimpl.genomes.bitString.embryogeny.BitStringToDoubleArrayEmbryogeny;
import org.sigoa.refimpl.genomes.bitString.reproduction.BitStringToggleNConsecutiveBitsMutator;
import org.sigoa.refimpl.genomes.bitString.reproduction.fixedLength.FixedLengthBitStringNPointCrossover;
import org.sigoa.refimpl.genomes.doubleArray.reproduction.DoubleArrayCreator;
import org.sigoa.refimpl.go.OptimizationInfo;
import org.sigoa.refimpl.go.Population;
import org.sigoa.refimpl.go.algorithms.ea.EA;
import org.sigoa.refimpl.go.algorithms.ea.ElitistEA;
import org.sigoa.refimpl.go.evaluation.Evaluator;
import org.sigoa.refimpl.go.reproduction.Creator;
import org.sigoa.refimpl.jobsystem.JobInfo;
import org.sigoa.refimpl.jobsystem.multiprocessor.MultiProcessorJobSystem;
import org.sigoa.refimpl.pipe.Pipeline;
import org.sigoa.refimpl.pipe.stat.FileTextWriterProvider;
import org.sigoa.refimpl.pipe.stat.IndividualPrinterPipe;
import org.sigoa.spec.go.IIndividual;
import org.sigoa.spec.go.IOptimizationInfo;
import org.sigoa.spec.go.IPopulation;
import org.sigoa.spec.go.evaluation.IEvaluator;
import org.sigoa.spec.jobsystem.IJobSystem;
import org.sigoa.spec.stoch.IRandomizer;

/**
 * A simple test for the evolutionary algorithm base implementation.
 * 
 * @author Thomas Weise
 */
public class Elitist_EA_BitString_Benchmark {
  /**
   * the main program called at startup
   * 
   * @param args
   *          the command line arguments
   */
  @SuppressWarnings("unchecked")
  public static void main(String[] args) {
    IEvaluator<double[]> eval;
    EA<byte[], double[]> opt;
    IPopulation<byte[], double[]> out;
    IOptimizationInfo<byte[], double[]> oi;
    double[] data;
    int i;
    IJobSystem s;

    eval = new Evaluator<double[]>(TestFunctions.TEST_1);
    opt = new ElitistEA<byte[], double[]>(1024, 0.35, 0.8) {
      private static final long serialVersionUID = 1;

      @Override
      protected Pipeline<byte[], double[]> createArchivePipeline() {
        Pipeline<byte[], double[]> p;
        p = super.createArchivePipeline();
        p.add(new IndividualPrinterPipe<byte[], double[]>(
            new FileTextWriterProvider(new File("E:\\test"), //$NON-NLS-1$
                "out"))); //$NON-NLS-1$
        return p;
      }
    };

    out = new Population<byte[], double[]>();
    opt.setOutputPipe(out);

    // opt.getRules().add(
    // new CompoundRule<IOptimizer<byte[], double[]>>(
    // new TimeCondition<IOptimizer<byte[], double[]>>(20000),
    // new AbortAction<IOptimizer<byte[], double[]>>()));

    oi = new OptimizationInfo<byte[], double[]>(
        eval,
        new BitStringToDoubleArrayEmbryogeny(true),
        new ConvinedBitStringCreator(TestFunctions.TEST_1_MIN,
            TestFunctions.TEST_1_MAX),
        BitStringToggleNConsecutiveBitsMutator.BIT_STRING_TOGGLE_N_CONSECUTIVE_BITS_MUTATOR,
        new FixedLengthBitStringNPointCrossover());

    s = new MultiProcessorJobSystem(null);
    s.executeOptimization(opt, new JobInfo<byte[], double[]>(oi));
    s.start();

    try {
      System.in.read();
    } catch (Throwable t) {
      //
    }

    opt.abort();

    opt.waitFor(false);
    s.abort();
    s.waitFor(false);

    System.out.println();
    System.out.println("Generation " + opt.getIteration());//$NON-NLS-1$
    System.out.println("Solutions  " + out.size());//$NON-NLS-1$
    System.out.println();

    for (IIndividual<byte[], double[]> ind : out) {
      data = ind.getPhenotype();
      for (i = 0; i < data.length; i++) {
        System.out.print(data[i]);
        if (i < (data.length - 1))
          System.out.print('\t');
        else
          System.out.println();
      }
    }
  }

  /**
   * the convined bitstring creator
   * 
   * @author Thomas Weise
   */
  private static final class ConvinedBitStringCreator extends
      Creator<byte[]> {
    /**
     * The serial version uid.
     */
    private static final long serialVersionUID = 1;

    /**
     * the internal double vector creator
     */
    private final DoubleArrayCreator m_internal;

    /**
     * the bit string output stream
     */
    private transient BitStringOutputStream m_bos;

    /**
     * Create a new convined bit string creator.
     * 
     * @param min
     *          the minima for the single dimensions
     * @param max
     *          the maxima for the single dimensions
     * @throws IllegalArgumentException
     *           if
     *           <code>(min == null) || (max == null) || (min.length != max.length)</code>
     *           or if the extend in one dimension is smaller or equal to
     *           zero
     */
    public ConvinedBitStringCreator(final double[] min, final double[] max) {
      super();
      this.m_internal = new DoubleArrayCreator(min, max);
      this.m_bos = new GrayCodedBitStringOutputStream();
    }

    /**
     * Create a single new random genotype
     * 
     * @param random
     *          The randomizer to be used.
     * @return The resulting genotype.
     * @throws NullPointerException
     *           if <code>random==null</code>.
     */
    public byte[] create(final IRandomizer random) {
      double[] d;
      int i;
      byte[] x;
      BitStringOutputStream bos;

      d = this.m_internal.create(random);
      bos = this.m_bos;
      for (i = (d.length - 1); i >= 0; i--) {
        bos.writeDouble(d[i]);
      }

      x = bos.getOutput();
      bos.clear();
      return x;
    }
  }

}
